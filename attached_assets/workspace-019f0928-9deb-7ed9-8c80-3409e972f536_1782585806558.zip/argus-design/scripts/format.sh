#!/usr/bin/env bash
# scripts/format.sh — auto-fix and format
set -euo pipefail
cd "$(dirname "$0")/.."
source .venv/bin/activate

uv run ruff check --fix .
uv run ruff format .
