#!/usr/bin/env bash
# scripts/wait-for.sh — poll until URL responds 200
# Usage: wait-for.sh <url> [timeout-seconds]
set -euo pipefail

URL="${1:?usage: wait-for.sh <url> [timeout]}"
TIMEOUT="${2:-60}"

start=$(date +%s)
while true; do
    if curl -fsS -m 2 "$URL" >/dev/null 2>&1; then
        echo "✅ $URL is up"
        exit 0
    fi
    now=$(date +%s)
    if [ $((now - start)) -gt "$TIMEOUT" ]; then
        echo "❌ $URL not up after ${TIMEOUT}s" >&2
        exit 1
    fi
    sleep 1
done
