#!/usr/bin/env bash
# scripts/migrate.sh — Alembic wrapper
set -euo pipefail
cd "$(dirname "$0")/.."
source .venv/bin/activate

CMD="${1:-help}"; shift || true

case "$CMD" in
    upgrade)
        TARGET="${1:-head}"
        exec alembic -c libs/argus_db/migrations/alembic.ini upgrade "$TARGET"
        ;;
    downgrade)
        TARGET="${1:- -1}"
        exec alembic -c libs/argus_db/migrations/alembic.ini downgrade "$TARGET"
        ;;
    current)
        exec alembic -c libs/argus_db/migrations/alembic.ini current
        ;;
    heads)
        exec alembic -c libs/argus_db/migrations/alembic.ini heads
        ;;
    revision)
        MSG="${1:-}"
        [ -n "$MSG" ] || { echo "Usage: $0 revision <message>"; exit 1; }
        exec alembic -c libs/argus_db/migrations/alembic.ini revision --autogenerate -m "$MSG"
        ;;
    history)
        exec alembic -c libs/argus_db/migrations/alembic.ini history --verbose
        ;;
    help|--help|-h)
        cat <<EOF
Usage: migrate.sh <command> [args]

Commands:
  upgrade [target]      Upgrade to target (default: head)
  downgrade [target]    Downgrade (default: -1)
  current               Show current revision
  heads                 Show head revisions
  revision <msg>        Autogenerate a new revision
  history               Show full migration history
EOF
        ;;
    *)
        echo "Unknown: $CMD" >&2; exit 1 ;;
esac
