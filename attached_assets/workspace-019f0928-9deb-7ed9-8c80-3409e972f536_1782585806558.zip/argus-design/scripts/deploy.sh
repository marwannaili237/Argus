#!/usr/bin/env bash
# scripts/deploy.sh — deploy to staging/production
set -euo pipefail
cd "$(dirname "$0")/.."

ENV="${1:-staging}"

case "$ENV" in
    staging)
        echo "==> Deploying to staging"
        railway up --service argus-api --environment staging || true
        railway up --service argus-bot --environment staging || true
        railway up --service argus-worker --environment staging || true
        ;;
    production)
        echo "==> Deploying to production"
        railway up --service argus-api --environment production || true
        railway up --service argus-bot --environment production || true
        railway up --service argus-worker --environment production || true
        ;;
    koyeb)
        echo "==> Deploying to Koyeb"
        koyeb deploy -a argus-api ghcr.io/argus-saas/argus:latest \
            --build-arg SERVICE=api || true
        ;;
    northflank)
        echo "==> Deploying to Northflank"
        northflank deploy --project argus --service argus-api-bot || true
        northflank deploy --project argus --service argus-worker || true
        ;;
    *)
        echo "Usage: $0 {staging|production|koyeb|northflank}" >&2
        exit 1
        ;;
esac
