#!/usr/bin/env bash
# scripts/dev.sh — central dev command router (executable reference)
set -euo pipefail
cd "$(dirname "$0")/.."

CMD="${1:-help}"; shift || true

ensure_venv() {
    [ -d .venv ] || uv venv --python 3.12 .venv
}

ensure_env() {
    [ -f .env ] || cp .env.example .env
}

case "$CMD" in
    bootstrap)
        ensure_venv
        ensure_env
        source .venv/bin/activate
        uv sync --all-extras
        uv run pre-commit install
        echo "✅ Bootstrap complete. Run: ./scripts/tmux-dev.sh start"
        ;;
    api)        exec scripts/serve.sh "$@" ;;
    bot)        exec scripts/bot.sh "$@" ;;
    worker)     exec scripts/worker.sh "$@" ;;
    beat)       exec scripts/beat.sh "$@" ;;
    migrate)    exec scripts/migrate.sh "$@" ;;
    test)       exec scripts/test.sh "$@" ;;
    lint)       exec scripts/lint.sh "$@" ;;
    format)     exec scripts/format.sh "$@" ;;
    typecheck)  exec scripts/typecheck.sh "$@" ;;
    seed)       exec scripts/seed.sh "$@" ;;
    shell)      source .venv/bin/activate && exec uv run python ;;
    ipython)    source .venv/bin/activate && exec uv run ipython ;;
    help|-h|--help)
        cat <<EOF
Argus dev script.

Usage: scripts/dev.sh <command> [args]

Commands:
  bootstrap    Install deps, generate .env, set up pre-commit
  api          Run API (uvicorn --reload)
  bot          Run bot
  worker       Run Celery worker
  beat         Run Celery beat
  migrate      Alembic (upgrade|downgrade|current|heads|revision)
  test         pytest with sane defaults
  lint         ruff + mypy
  format       ruff format (auto-fix)
  typecheck    mypy only
  seed         Insert plans + plugin catalog
  shell        Python REPL
  ipython      IPython REPL
EOF
        ;;
    *)
        echo "Unknown command: $CMD" >&2
        exit 1
        ;;
esac
