#!/usr/bin/env bash
# scripts/tmux-dev.sh — start/attach/stop the dev tmux session
set -euo pipefail
cd "$(dirname "$0")/.."

SESSION="${ARGUS_TMUX_SESSION:-argus}"
ROOT="$(pwd)"
LOG_DIR="$ROOT/logs"
mkdir -p "$LOG_DIR"

ensure_log() { : > "$LOG_DIR/$1.log"; }

start_or_attach() {
    if tmux has-session -t "$SESSION" 2>/dev/null; then
        tmux attach -t "$SESSION"
        return
    fi

    tmux new-session -d -s "$SESSION" -x 200 -y 50 -n api -c "$ROOT"

    # Window 1: api
    ensure_log api
    tmux send-keys -t "$SESSION:1" \
        "source .venv/bin/activate && exec uvicorn argus_api.main:app --reload --port 8080 2>&1 | tee logs/api.log" C-m
    tmux split-window -h -t "$SESSION:1" -c "$ROOT"
    tmux send-keys -t "$SESSION:1.right" \
        "tail -F logs/api.log | jq -C -R 'fromjson? // .'" C-m

    # Window 2: bot
    ensure_log bot
    tmux new-window -t "$SESSION" -n bot -c "$ROOT"
    tmux send-keys -t "$SESSION:2" \
        "source .venv/bin/activate && exec python -m argus_bot 2>&1 | tee logs/bot.log" C-m
    tmux split-window -h -t "$SESSION:2" -c "$ROOT"
    tmux send-keys -t "$SESSION:2.right" \
        "tail -F logs/bot.log | jq -C -R 'fromjson? // .'" C-m

    # Window 3: worker
    ensure_log worker
    tmux new-window -t "$SESSION" -n worker -c "$ROOT"
    tmux send-keys -t "$SESSION:3" \
        "source .venv/bin/activate && exec celery -A argus_worker.celery_app worker -l INFO -c 4 -Q ctrl,plugins,evidence,entity,relationship,export,billing,maintenance 2>&1 | tee logs/worker.log" C-m
    tmux split-window -h -t "$SESSION:3" -c "$ROOT"
    tmux send-keys -t "$SESSION:3.right" \
        "tail -F logs/worker.log | jq -C -R 'fromjson? // .'" C-m

    # Window 4: beat
    ensure_log beat
    tmux new-window -t "$SESSION" -n beat -c "$ROOT"
    tmux send-keys -t "$SESSION:4" \
        "source .venv/bin/activate && exec celery -A argus_worker.celery_app beat -l INFO 2>&1 | tee logs/beat.log" C-m
    tmux split-window -h -t "$SESSION:4" -c "$ROOT"
    tmux send-keys -t "$SESSION:4.right" \
        "tail -F logs/beat.log | jq -C -R 'fromjson? // .'" C-m

    # Window 5: shell + tests
    tmux new-window -t "$SESSION" -n shell -c "$ROOT"
    tmux send-keys -t "$SESSION:5" "source .venv/bin/activate && clear" C-m
    tmux split-window -h -t "$SESSION:5" -c "$ROOT"
    tmux send-keys -t "$SESSION:5.right" "source .venv/bin/activate && clear" C-m

    # Window 6: edit
    tmux new-window -t "$SESSION" -n edit -c "$ROOT"
    tmux send-keys -t "$SESSION:6" "source .venv/bin/activate && nvim ." C-m

    tmux select-window -t "$SESSION:1"
    tmux attach -t "$SESSION"
}

case "${1:-start}" in
    start)  start_or_attach ;;
    stop)   tmux kill-session -t "$SESSION" 2>/dev/null || true ;;
    status) tmux list-sessions 2>/dev/null | grep "^$SESSION:" || echo "not running" ;;
    *)
        echo "Usage: $0 {start|stop|status}"
        exit 1
        ;;
esac
