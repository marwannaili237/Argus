#!/usr/bin/env bash
# scripts/termux-bootstrap.sh — one-time Termux + proot setup
set -euo pipefail

REPO="${1:-$HOME/argus}"

echo "==> Updating Termux packages"
pkg update -y
pkg upgrade -y

echo "==> Installing core tools"
pkg install -y python git tmux curl wget jq neovim graphviz \
    postgresql-client redis-tools ripgrep fd fzf \
    build-essential libffi libssl openssl proot-distro

echo "==> Installing proot-distro Debian"
proot-distro install debian

echo "==> Bootstrapping Argus in proot"
proot-distro login debian -- bash <<EOF
set -euo pipefail
apt-get update -y
apt-get install -y --no-install-recommends \
    python3.12 python3.12-venv python3-pip \
    git tmux curl wget jq graphviz \
    postgresql-15 redis-server \
    build-essential libffi-dev libssl-dev pkg-config

pip install --break-system-packages uv==0.5.0

if [ ! -d "$REPO" ]; then
    git clone https://github.com/argus-saas/argus.git "$REPO"
fi
cd "$REPO"
uv venv --python 3.12 .venv
source .venv/bin/activate
uv sync --all-extras
uv run pre-commit install
[ -f .env ] || cp .env.example .env

mkdir -p logs run
chmod +x scripts/*.sh

echo "==> Done"
echo "Next steps:"
echo "  proot-distro login debian"
echo "  cd $REPO && source .venv/bin/activate"
echo "  ./scripts/tmux-dev.sh start"
EOF

echo "✅ Termux bootstrap complete"
