#!/usr/bin/env bash
# scripts/serve.sh — run API
set -euo pipefail
cd "$(dirname "$0")/.."
source .venv/bin/activate

PORT="${PORT:-8080}"
HOST="${HOST:-0.0.0.0}"
WORKERS="${WORKERS:-1}"

if [ "$WORKERS" -gt 1 ]; then
    exec uvicorn argus_api.main:app \
        --host "$HOST" --port "$PORT" \
        --workers "$WORKERS" \
        --no-access-log
else
    exec uvicorn argus_api.main:app \
        --host "$HOST" --port "$PORT" \
        --reload
fi
