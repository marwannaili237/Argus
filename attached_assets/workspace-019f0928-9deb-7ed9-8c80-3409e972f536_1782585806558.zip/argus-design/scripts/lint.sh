#!/usr/bin/env bash
# scripts/lint.sh
set -euo pipefail
cd "$(dirname "$0")/.."
source .venv/bin/activate

echo "==> ruff"
uv run ruff check .

echo "==> ruff format (check only)"
uv run ruff format --check .

echo "==> mypy (strict)"
uv run mypy --strict libs/argus_common libs/argus_db domain

echo "==> mypy (default)"
uv run mypy services/api/src services/bot/src services/worker/src

echo "==> import-linter"
uv run lint-imports

echo "==> bot-boundary"
./scripts/check-bot-boundaries.sh

echo "✅ lint clean"
