#!/usr/bin/env bash
# scripts/notify.sh — Termux:API notification
# Usage: notify.sh "title" "content"
TITLE="${1:-Argus}"
CONTENT="${2:-}"

if command -v termux-notification >/dev/null 2>&1; then
    termux-notification --title "$TITLE" --content "$CONTENT" --id argus
else
    echo "[notify] $TITLE: $CONTENT"
fi
