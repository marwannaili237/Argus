#!/usr/bin/env bash
# scripts/test.sh — pytest wrapper
set -euo pipefail
cd "$(dirname "$0")/.."
source .venv/bin/activate

ARGS=()

if [ $# -eq 0 ]; then
    ARGS=(
        --strict-markers
        --strict-config
        -ra
        -q
        tests/ services/api/tests services/bot/tests services/worker/tests
        -m "not load"
        --cov=argus_api --cov=argus_bot --cov=argus_worker
        --cov=libs --cov=domain
        --cov-report=term-missing
        --cov-fail-under=70
    )
fi

exec pytest "${ARGS[@]}" "$@"
