#!/usr/bin/env bash
# scripts/bot.sh — run aiogram bot
set -euo pipefail
cd "$(dirname "$0")/.."
source .venv/bin/activate

MODE="${1:-polling}"

case "$MODE" in
    polling)
        exec python -m argus_bot
        ;;
    webhook)
        PORT="${PORT:-8081}"
        exec python -m argus_bot --webhook "$PORT"
        ;;
    *)
        echo "Usage: $0 {polling|webhook}" >&2
        exit 1
        ;;
esac
