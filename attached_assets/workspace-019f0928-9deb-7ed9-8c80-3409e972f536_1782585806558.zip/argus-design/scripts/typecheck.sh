#!/usr/bin/env bash
# scripts/typecheck.sh — mypy only
set -euo pipefail
cd "$(dirname "$0")/.."
source .venv/bin/activate

uv run mypy --strict libs/argus_common libs/argus_db domain
uv run mypy services/api/src services/bot/src services/worker/src
