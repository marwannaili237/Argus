#!/usr/bin/env bash
# scripts/tmux-health.sh — service health dots for tmux status-right
probe() {
    local name="$1" url="$2"
    if curl -fsS -m 1 "$url" >/dev/null 2>&1; then
        printf "#[fg=green]●%s" "$name"
    else
        printf "#[fg=red]○%s" "$name"
    fi
}

out=""
out+="$(probe api http://localhost:8080/health) "
out+="$(probe bot tcp://localhost:8081) "
out+="$(probe worker tcp://localhost:8082) "
out+="$(probe beat tcp://localhost:8083) "
echo "$out"
