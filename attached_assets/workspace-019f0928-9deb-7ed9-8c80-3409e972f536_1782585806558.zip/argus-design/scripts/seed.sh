#!/usr/bin/env bash
# scripts/seed.sh — seed plans and plugin catalog
set -euo pipefail
cd "$(dirname "$0")/.."
source .venv/bin/activate

exec python -m argus_db.seed
