#!/usr/bin/env bash
# scripts/tail-logs.sh — tail a service log
set -euo pipefail
cd "$(dirname "$0")/.."

SERVICE="${1:-api}"
LOG="logs/${SERVICE}.log"

[ -f "$LOG" ] || { echo "no log: $LOG" >&2; exit 1; }

exec tail -F "$LOG" | jq -C -R 'fromjson? // .'
