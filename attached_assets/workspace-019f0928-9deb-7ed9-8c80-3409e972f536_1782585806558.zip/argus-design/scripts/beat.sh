#!/usr/bin/env bash
# scripts/beat.sh — run Celery beat
set -euo pipefail
cd "$(dirname "$0")/.."
source .venv/bin/activate

exec celery -A argus_worker.celery_app beat \
    --loglevel="${LOG_LEVEL:-INFO}" \
    --schedule=/tmp/celerybeat-schedule
