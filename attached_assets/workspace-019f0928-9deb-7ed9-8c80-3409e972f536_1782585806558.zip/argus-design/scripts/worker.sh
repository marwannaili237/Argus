#!/usr/bin/env bash
# scripts/worker.sh — run Celery worker
set -euo pipefail
cd "$(dirname "$0")/.."
source .venv/bin/activate

CONCURRENCY="${WORKER_CONCURRENCY:-4}"
QUEUES="${WORKER_QUEUES:-ctrl,plugins,evidence,entity,relationship,export,billing,maintenance}"

exec celery -A argus_worker.celery_app worker \
    --loglevel="${LOG_LEVEL:-INFO}" \
    --concurrency="$CONCURRENCY" \
    -Q "$QUEUES" \
    --max-tasks-per-child=200 \
    --max-memory-per-child=512000
