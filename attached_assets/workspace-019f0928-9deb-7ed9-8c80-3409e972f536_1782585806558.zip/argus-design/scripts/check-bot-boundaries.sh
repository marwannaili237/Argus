#!/usr/bin/env bash
# scripts/check-bot-boundaries.sh
# Enforce: bot MUST NOT import SQLAlchemy / asyncpg / celery / redis / plugins / domain.
set -euo pipefail
cd "$(dirname "$0")/.."

FORBIDDEN_INFRA_REGEX='^(from|import)\s+(sqlalchemy|asyncpg|psycopg|aiosqlite|celery|redis|aiomcache|kafka|nats|pika|kombu|amqp)'
FORBIDDEN_PLUGIN_REGEX='^(from|import)\s+argus_(whois|dns|http_crawl|social_x|email_hunt|shodan|censys)'
FORBIDDEN_DOMAIN_REGEX='^(from|import)\s+argus_domain'

fail=0

if grep -RnE "$FORBIDDEN_INFRA_REGEX" services/bot/src 2>/dev/null; then
    echo "❌ Bot imports infrastructure module — forbidden"
    fail=1
fi

if grep -RnE "$FORBIDDEN_PLUGIN_REGEX" services/bot/src 2>/dev/null; then
    echo "❌ Bot imports plugin code — forbidden"
    fail=1
fi

if grep -RnE "$FORBIDDEN_DOMAIN_REGEX" services/bot/src 2>/dev/null; then
    echo "❌ Bot imports domain — use API client instead"
    fail=1
fi

if [ "$fail" -ne 0 ]; then
    exit 1
fi

echo "✅ Bot boundary OK"
