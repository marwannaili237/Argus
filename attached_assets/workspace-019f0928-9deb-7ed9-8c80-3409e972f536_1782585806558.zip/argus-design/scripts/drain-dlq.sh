#!/usr/bin/env bash
# scripts/drain-dlq.sh — manually drain Celery DLQ
set -euo pipefail
cd "$(dirname "$0")/.."
source .venv/bin/activate

exec python -m argus_worker.maintenance.drain_dlq --interactive
