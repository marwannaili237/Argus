#!/usr/bin/env bash
# scripts/rotate-logs.sh — rotate logs > 10MB
set -euo pipefail
cd "$(dirname "$0")/.."

MAX_SIZE_MB=10
KEEP=10

for f in logs/*.log; do
    [ -f "$f" ] || continue
    size_mb=$(( $(stat -c %s "$f") / 1024 / 1024 ))
    if [ "$size_mb" -gt "$MAX_SIZE_MB" ]; then
        ts=$(date +%Y%m%d-%H%M%S)
        mv "$f" "$f.$ts"
        gzip "$f.$ts"
        ls -1t "$f".*.gz 2>/dev/null | tail -n +$((KEEP+1)) | xargs -r rm --
    fi
done
