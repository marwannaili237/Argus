# 05 — Telegram Bot (aiogram 3.x)

## 0. The contract

The bot is a **thin UI layer**. It:

- Authenticates users (via Telegram Login Widget through the API).
- Sends API requests to the FastAPI backend.
- Renders investigation progress by **editing the same message**.
- Renders results (lists, graphs, exports).
- Downloads exports (≤ 50 MB) via signed URL → Telegram.
- Uploads user files (≤ 20 MB) → API.

It does **not**:

- Import SQLAlchemy, asyncpg, redis.asyncio, celery, or any plugin.
- Run OSINT lookups directly.
- Hold business state beyond FSM (which lives in Redis).
- Make business decisions (e.g. "should we run this plugin?").

This contract is enforced by `scripts/check-bot-boundaries.sh` (see
[16-BASH-SCRIPTS.md](16-BASH-SCRIPTS.md)) and CI.

## 1. Module layout

```
services/bot/src/argus_bot/
├── main.py                     # dispatcher + webhook / polling
├── api_client.py               # thin wrapper around backend HTTP
├── middlewares/
│   ├── auth.py                 # attaches user from FSM storage
│   ├── logging.py              # logs every update with request_id
│   └── throttling.py           # per-user soft throttle
├── handlers/
│   ├── start.py                # /start, /help, /cancel
│   ├── menu.py                 # main menu, callbacks
│   ├── investigation_new.py    # FSM: target → plugins → confirm
│   ├── investigation_running.py
│   ├── investigation_completed.py
│   ├── evidence.py             # paginated evidence view
│   ├── export.py               # trigger + download
│   ├── profile.py              # user info, plan
│   ├── settings.py             # locale, plugins enabled
│   └── admin.py                # only for role=admin
├── keyboards/
│   ├── inline.py               # main menu, investigation screen
│   └── reply.py                # cancel, skip
├── fsm/
│   ├── states.py               # InvestigationNew, SettingsEdit, ...
│   └── storage.py              # Redis FSM storage, encrypted tokens
├── renderers/
│   ├── investigation.py        # screen formatting
│   ├── evidence.py             # list item formatting
│   ├── entities.py
│   ├── export.py
│   └── graph.py                # SVG → PNG via headless dot
├── progress.py                 # subscribes to SSE, edits messages
├── callbacks.py                # callback_data packing
├── i18n/
│   ├── en.json
│   ├── ru.json
│   └── loader.py
└── errors.py                   # user-friendly error mapping
```

## 2. Routing

```python
# services/bot/src/argus_bot/main.py
from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.fsm.storage.redis import RedisStorage

from argus_bot.handlers import (
    start, menu, investigation_new, investigation_running,
    investigation_completed, evidence, export, profile, settings,
)
from argus_bot.middlewares import auth, logging as bot_logging, throttling

def build_dispatcher(settings) -> Dispatcher:
    storage = RedisStorage(redis=build_redis(settings), key_builder=...)
    dp = Dispatcher(storage=storage, settings=settings)

    # Outer middlewares — every update
    dp.update.outer_middleware(bot_logging.CorrelationMiddleware())
    dp.update.outer_middleware(auth.AuthMiddleware(api=api_client))
    dp.update.outer_middleware(throttling.UserThrottleMiddleware())

    # Routers — registration order matters
    dp.include_router(start.router)
    dp.include_router(menu.router)
    dp.include_router(investigation_new.router)
    dp.include_router(investigation_running.router)
    dp.include_router(investigation_completed.router)
    dp.include_router(evidence.router)
    dp.include_router(export.router)
    dp.include_router(profile.router)
    dp.include_router(settings.router)
    dp.include_router(admin.router)

    return dp
```

Polling vs webhook:

- **Polling** for free-tier deploys. `bot.delete_webhook()` then
  `dp.start_polling(bot, allowed_updates=...)`.
- **Webhook** only when behind a known HTTPS endpoint (Northflank, or
  a VPS).

## 3. State machine

We use aiogram FSM. States are enum-based:

```python
# services/bot/src/argus_bot/fsm/states.py
from aiogram.fsm.state import State, StatesGroup

class InvestigationNew(StatesGroup):
    choosing_kind   = State()
    entering_target = State()
    choosing_plugins = State()
    confirming      = State()

class SettingsEdit(StatesGroup):
    choosing_field  = State()
    entering_value  = State()

class ExportFlow(StatesGroup):
    choosing_format = State()
    waiting_ready   = State()
```

FSM data holds only ephemeral user input (target value, plugin list).
**Auth tokens are NOT in FSM data** — they live in `fsm/storage.py`
encrypted at rest (Fernet, key from env).

## 4. The api_client

```python
# services/bot/src/argus_bot/api_client.py
from typing import Any
import httpx

class ArgusApiClient:
    """Thin wrapper. No business logic. """

    def __init__(self, base_url: str, bot_token: str):
        self._client = httpx.AsyncClient(
            base_url=base_url,
            timeout=httpx.Timeout(30.0, connect=5.0),
            limits=httpx.Limits(max_keepalive_connections=20, max_connections=50),
            headers={"User-Agent": "ArgusBot/1.0"},
        )

    async def exchange_telegram_login(self, init_data: str) -> AuthResult: ...
    async def refresh(self, refresh_token: str) -> AuthResult: ...
    async def me(self, access_token: str) -> UserDTO: ...
    async def create_investigation(self, access_token: str, body: dict) -> InvestigationDTO: ...
    async def get_investigation(self, access_token: str, id: str) -> InvestigationDTO: ...
    async def pause(self, access_token: str, id: str) -> None: ...
    async def resume(self, access_token: str, id: str) -> None: ...
    async def cancel(self, access_token: str, id: str) -> None: ...
    async def stream_events(self, access_token: str, id: str) -> AsyncIterator[EventDTO]: ...
    async def list_evidence(self, access_token: str, id: str, **params) -> Page[EvidenceDTO]: ...
    async def list_entities(self, access_token: str, id: str, **params) -> Page[EntityDTO]: ...
    async def create_export(self, access_token: str, id: str, fmt: str) -> ExportDTO: ...
    async def download(self, access_token: str, export_id: str) -> bytes: ...

    async def aclose(self) -> None:
        await self._client.aclose()
```

All methods return DTOs (Pydantic models defined in
`services/bot/src/argus_bot/dto.py`). DTOs mirror API schemas but the
bot owns its own copies — no shared import of API schemas. If API
schema changes, bot breaks loudly.

## 5. The main menu

Single message that we **edit** forever:

```python
# services/bot/src/argus_bot/handlers/menu.py
from aiogram import Router, F
from aiogram.types import CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton
from argus_bot.callbacks import MenuAction, CB

router = Router(name="menu")

@router.callback_query(MenuAction.filter())
async def on_menu(cb: CallbackQuery, callback_data: MenuAction):
    user = await get_user(cb.from_user.id)
    text, kb = await render_main_menu(user)
    await cb.message.edit_text(text, reply_markup=kb)
    await cb.answer()
```

Keyboard is rebuilt on every edit. To preserve scroll position we
use `edit_message_text` (not `edit_message_reply_markup` separately).

```python
async def render_main_menu(user: UserDTO) -> tuple[str, InlineKeyboardMarkup]:
    text = await i18n.get(user.locale, "main_menu.title",
                          name=user.full_name or user.username)
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=await i18n.get(user.locale, "main_menu.new"),
                              callback_data=CB.menu_new())],
        [InlineKeyboardButton(text=await i18n.get(user.locale, "main_menu.running"),
                              callback_data=CB.menu_running())],
        [InlineKeyboardButton(text=await i18n.get(user.locale, "main_menu.completed"),
                              callback_data=CB.menu_completed())],
        [InlineKeyboardButton(text=await i18n.get(user.locale, "main_menu.evidence"),
                              callback_data=CB.menu_evidence())],
        [InlineKeyboardButton(text=await i18n.get(user.locale, "main_menu.exports"),
                              callback_data=CB.menu_exports())],
        [InlineKeyboardButton(text=await i18n.get(user.locale, "main_menu.profile"),
                              callback_data=CB.menu_profile()),
         InlineKeyboardButton(text=await i18n.get(user.locale, "main_menu.settings"),
                              callback_data=CB.menu_settings())],
    ])
    return text, kb
```

## 6. New investigation FSM

```python
# services/bot/src/argus_bot/handlers/investigation_new.py
@router.callback_query(MenuAction.filter(F.action == "new"))
async def on_new(cb: CallbackQuery, state: FSMContext):
    await state.set_state(InvestigationNew.choosing_kind)
    await cb.message.edit_text(
        await i18n.get(...,"investigation.new.choose_kind"),
        reply_markup=kind_keyboard(),
    )
    await cb.answer()

@router.callback_query(InvestigationNew.choosing_kind, KindCB.filter())
async def on_kind(cb, state, callback_data: KindCB):
    await state.update_data(kind=callback_data.kind)
    await state.set_state(InvestigationNew.entering_target)
    await cb.message.edit_text(
        await i18n.get(...,"investigation.new.enter_target", kind=callback_data.kind),
    )
    await cb.answer()

@router.message(InvestigationNew.entering_target)
async def on_target(message: Message, state: FSMContext):
    data = await state.get_data()
    value = message.text.strip()
    # Send to API to validate. Don't validate locally.
    try:
        normalized = await api.validate_target(message.from_user.id, data["kind"], value)
    except ArgusApiError as e:
        await message.answer(format_error(e))
        return
    await state.update_data(value=normalized)
    await state.set_state(InvestigationNew.choosing_plugins)
    await message.answer(
        await i18n.get(...,"investigation.new.choose_plugins"),
        reply_markup=plugins_keyboard(),
    )
```

When the user is in `choosing_plugins`, plugins are loaded from
`/v1/plugins` and offered as a multi-select grid. After confirmation,
`POST /v1/investigations` is called. The bot **edits** the original
message to the investigation screen.

## 7. Investigation screen — the live progress

The single most important pattern in the bot: **edit the same message**
instead of sending a new one.

```python
# services/bot/src/argus_bot/handlers/investigation_running.py
async def render_investigation_screen(inv: InvestigationDTO, user: UserDTO):
    text = await i18n.get(
        user.locale, "investigation.screen",
        id=inv.id[:8],
        target=inv.target.value,
        status=inv.status,
        progress=inv.progress_pct,
        current_step=inv.current_step or "—",
        evidence_count=inv.evidence_count,
        entity_count=inv.entity_count,
        relationship_count=inv.relationship_count,
        errors=inv.error_count,
        started=format_dt(inv.started_at, user.locale),
        eta=format_eta(inv, user.locale),
    )
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="🔄 Refresh", callback_data=CB.inv_refresh(inv.id)),
            InlineKeyboardButton(text="⏸ Pause" if inv.status == "running" else "▶ Resume",
                                 callback_data=CB.inv_pause(inv.id) if inv.status == "running"
                                               else CB.inv_resume(inv.id)),
            InlineKeyboardButton(text="⛔ Cancel", callback_data=CB.inv_cancel(inv.id)),
        ],
        [
            InlineKeyboardButton(text="📂 Evidence", callback_data=CB.inv_evidence(inv.id, 0)),
            InlineKeyboardButton(text="🕒 Timeline", callback_data=CB.inv_timeline(inv.id)),
            InlineKeyboardButton(text="🕸 Graph", callback_data=CB.inv_graph(inv.id)),
        ],
        [
            InlineKeyboardButton(text="📤 JSON", callback_data=CB.inv_export(inv.id, "json")),
            InlineKeyboardButton(text="📊 CSV",  callback_data=CB.inv_export(inv.id, "csv")),
            InlineKeyboardButton(text="📄 PDF",  callback_data=CB.inv_export(inv.id, "pdf")),
        ],
        [InlineKeyboardButton(text="⬅ Back", callback_data=CB.menu_running())],
    ])
    return text, kb
```

Progress updates come from SSE (`/v1/investigations/{id}/events`):

```python
# services/bot/src/argus_bot/progress.py
async def watch_investigation(user_id: int, chat_id: int, message_id: int,
                              investigation_id: str, bot: Bot):
    """Long-running task: SSE → edit message until investigation completes."""
    backoff = 1.0
    while True:
        try:
            async for event in api.stream_events(user_id, investigation_id):
                if event.type == "status.changed":
                    inv = await api.get_investigation(user_id, investigation_id)
                    text, kb = await render_investigation_screen(inv, user)
                    await bot.edit_message_text(
                        text, chat_id=chat_id, message_id=message_id, reply_markup=kb,
                    )
                    if inv.status in ("completed","failed","cancelled"):
                        return
                elif event.type in ("evidence.found","entity.found","relationship.found"):
                    # light refresh, no full render
                    await refresh_counts_only(...)
            backoff = 1.0
        except (httpx.RemoteProtocolError, httpx.ReadTimeout):
            await asyncio.sleep(backoff)
            backoff = min(backoff * 2, 30.0)
        except asyncio.CancelledError:
            return
```

The `watch_investigation` task is registered as a `asyncio.Task` on
the message object (using `bot.dispatcher.workflow_data` keyed by
`message_id`). When the user clicks "Cancel" or moves away, we cancel
the task.

## 8. Callback data packing

Telegram limits callback_data to **64 bytes**. We pack IDs:

```python
# services/bot/src/argus_bot/callbacks.py
from aiogram.filters.callback_data import CallbackData
from base64 import urlsafe_b64encode, urlsafe_b64decode

class MenuAction(CallbackData, prefix="m"):
    action: str  # 'new','running','completed','evidence','exports','profile','settings'

class InvAction(CallbackData, prefix="i"):
    id: str
    action: str  # 'refresh','pause','resume','cancel','timeline','graph','export','back'
    extra: str = ""

class EvPage(CallbackData, prefix="e"):
    inv_id: str
    cursor: str  # base64 of cursor
    page: int

class CB:
    """Static helpers for callback_data construction."""
    @staticmethod
    def menu_new() -> str:
        return MenuAction(action="new").pack()
    # ...

def encode_cursor(c: str) -> str:
    return urlsafe_b64encode(c.encode()).decode().rstrip("=")

def decode_cursor(c: str) -> str:
    pad = "=" * (-len(c) % 4)
    return urlsafe_b64decode(c + pad).decode()
```

Verify size budget in tests:

```python
def test_callback_data_size():
    for cb in [MenuAction(action="new").pack(),
               InvAction(id="x"*32, action="refresh").pack()]:
        assert len(cb) <= 64, cb
```

## 9. Middlewares

### Auth

```python
# services/bot/src/argus_bot/middlewares/auth.py
class AuthMiddleware(BaseMiddleware):
    def __init__(self, api: ArgusApiClient): self.api = api

    async def __call__(self, handler, event, data):
        user_id = event.from_user.id
        record = await self.storage.get_token(user_id)  # from fsm/storage.py
        if record is None:
            # Not registered → show /start
            raise UnauthenticatedError()
        # Auto-refresh if expiring soon
        if record.expires_in < 60:
            record = await self.api.refresh(record.refresh_token)
            await self.storage.put_token(user_id, record)
        data["user"] = record.user
        data["token"] = record.access_token
        return await handler(event, data)
```

### Throttling

```python
# services/bot/src/argus_bot/middlewares/throttling.py
class UserThrottleMiddleware(BaseMiddleware):
    """5 messages/sec per user, 30 callback queries/sec per user."""
    def __init__(self):
        self._message_bucket = TokenBucket(rate=5, capacity=10)
        self._callback_bucket = TokenBucket(rate=30, capacity=60)
        ...
```

### Logging

```python
# services/bot/src/argus_bot/middlewares/logging.py
class CorrelationMiddleware(BaseMiddleware):
    async def __call__(self, handler, event, data):
        request_id = str(uuid.uuid4())
        structlog.contextvars.bind_contextvars(
            request_id=request_id,
            update_id=event.update_id,
            user_id=event.from_user.id if event.from_user else None,
        )
        try:
            return await handler(event, data)
        finally:
            structlog.contextvars.clear_contextvars()
```

## 10. State cleanup

When the bot restarts, FSM state in Redis survives (good). When a user
completes a flow, state is cleared:

```python
@router.callback_query(InvestigationNew.confirming, F.data == "confirm")
async def on_confirm(cb, state):
    data = await state.get_data()
    inv = await api.create_investigation(...)
    await state.clear()
    # Edit the message into investigation screen
    text, kb = await render_investigation_screen(inv, ...)
    await cb.message.edit_text(text, reply_markup=kb)
    # Start progress watcher
    asyncio.create_task(watch_investigation(...))
```

## 11. i18n

```python
# services/bot/src/argus_bot/i18n/loader.py
import json
from pathlib import Path

class I18n:
    def __init__(self, base: Path):
        self._cache = {}
        for path in base.glob("*.json"):
            self._cache[path.stem] = json.loads(path.read_text("utf-8"))

    async def get(self, locale: str, key: str, /, **params) -> str:
        bundle = self._cache.get(locale, self._cache["en"])
        try:
            tmpl = key.split(".").__reduce__(...)  # actually use a tiny parser
            # We'll use a flat dict with dotted keys
            tmpl = bundle
            for part in key.split("."):
                tmpl = tmpl[part]
        except KeyError:
            tmpl = self._cache["en"].get(key, key)
        return tmpl.format(**params)
```

Strings live in `i18n/en.json`, `i18n/ru.json`. Keys are dotted paths:
`"investigation.new.enter_target"`. Translations added by editing both
files; missing keys fall back to English.

## 12. Error mapping

```python
# services/bot/src/argus_bot/errors.py
ERROR_MAP = {
    "invalid_input":         "errors.invalid_input",
    "unauthenticated":       "errors.please_restart",
    "forbidden":             "errors.no_access",
    "not_found":             "errors.not_found",
    "quota_exceeded":        "errors.quota_exceeded",
    "rate_limited":          "errors.slow_down",
    "upstream_unavailable":  "errors.upstream_failed",
    "service_unavailable":   "errors.service_degraded",
}

def format_error(err: ArgusApiError, locale: str) -> str:
    key = ERROR_MAP.get(err.code, "errors.generic")
    return i18n.get(locale, key, **err.detail_params)
```

## 13. Graph rendering

Investigation graph is computed server-side as Graphviz `dot`. Bot
renders PNG using the `graphviz` Python package (vendored binary in
docker image; on Termux use `apt install graphviz` inside proot).

```python
import graphviz

def render_graph(dot_source: str) -> bytes:
    src = graphviz.Source(dot_source)
    # Returns PNG bytes
    return src.pipe(format="png")
```

Bot sends as `BufferedInputFile(png_bytes, filename="graph.png")`.

For very large graphs we send as `Document` instead of `Photo`.

## 14. Downloading exports

```python
@router.callback_query(InvAction.filter(F.action == "export"))
async def on_export(cb, callback_data: InvAction, user: UserDTO):
    fmt = callback_data.extra
    # Ask backend to render
    export = await api.create_export(user.id, callback_data.id, fmt)
    await cb.message.edit_text(await i18n.get(user.locale, "export.preparing", fmt=fmt))
    # Poll until ready (≤ 60s usually)
    for _ in range(60):
        if export.status == "ready": break
        await asyncio.sleep(2)
        export = await api.get_export(user.id, export.id)
        if export.status == "failed":
            await cb.message.edit_text(await i18n.get(user.locale, "export.failed"))
            return
    if export.status != "ready":
        await cb.message.edit_text(await i18n.get(user.locale, "export.timeout"))
        return
    blob = await api.download(user.id, export.id)
    if len(blob) <= 49 * 1024 * 1024:  # 49 MB safety
        await cb.message.delete()
        await cb.message.answer_document(
            BufferedInputFile(blob, filename=f"argus-{callback_data.id[:8]}.{fmt}"),
        )
    else:
        # Send as multiple parts
        ...
```

## 15. Polling vs webhook

Polling path:

```python
async def main():
    settings = Settings()
    bot = Bot(token=settings.bot_token,
              default=DefaultBotProperties(parse_mode=ParseMode.HTML))
    dp = build_dispatcher(settings)
    await dp.start_polling(bot, allowed_updates=dp.resolve_used_update_types())
```

Webhook path (only for HTTPS-capable deploys):

```python
async def main_webhook():
    bot = Bot(token=settings.bot_token, ...)
    dp = build_dispatcher(settings)
    app = web.Application()
    webhook_requests_handler = SimpleRequestHandler(dispatcher=dp, bot=bot)
    webhook_requests_handler.register(app, path="/webhook")
    setup_application(app, dp, bot=bot)
    await bot.set_webhook(f"{settings.public_url}/webhook",
                          allowed_updates=dp.resolve_used_update_types())
    return app
```

## 16. Boundary enforcement (CI)

`scripts/check-bot-boundaries.sh` greps bot source for forbidden
imports:

```bash
#!/usr/bin/env bash
set -euo pipefail

FORBIDDEN=(sqlalchemy asyncpg psycopg aiosqlite celery redis aiomcache)

PATTERN=$(printf '%s|' "${FORBIDDEN[@]}")
PATTERN="${PATTERN%|}"

if grep -RnE "^(from|import)\s+($PATTERN)" services/bot/src; then
    echo "❌ Bot imports infrastructure module — forbidden"
    exit 1
fi
echo "✅ Bot boundary OK"
```

Run in CI on every PR.

## 17. Local Termux dev notes

- Install `graphviz` inside proot: `apt install -y graphviz`.
- Use polling (not webhook) — Telegram rejects self-signed certs.
- Network from Android can be unreliable. SSE reconnect logic is
  essential.
- If Telegram is blocked, the bot cannot function. Document this for
  the user.

## 18. Observability

- Every update logged with `update_id`, `user_id`, `chat_id`,
  `request_id`, latency.
- Counter: `bot_updates_total{handler,result}`.
- Histogram: `bot_handler_duration_seconds{handler}`.
- Sentry: capture uncaught exceptions in handlers; filter out
  `TelegramNetworkError` and `CallbackAnswerTimeout`.
