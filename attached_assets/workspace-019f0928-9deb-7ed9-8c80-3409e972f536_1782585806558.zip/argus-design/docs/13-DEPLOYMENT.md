# 13 — Deployment Architecture

## 0. Goal

Free-tier deploy on Railway / Koyeb / Northflank. No persistent card
billing required (Koyeb free, Northflank free). Optional upgrade to
Railway's $5 trial or a $5/mo VPS for production.

## 1. Free-tier comparison

| Provider | Free tier | Verdict |
|----------|-----------|---------|
| **Railway** | $5 trial credit, no card needed; then $5/mo hobby plan | **Default** for staging + low-volume prod |
| **Koyeb** | 1 free nano service, 256 MB RAM, 0.1 vCPU | **Cheapest** for always-free prod (api+bot single service) |
| **Northflank** | 2 free services, 512 MB each | **Best** for multi-service free deploy |
| **Fly.io** | Free allowance, requires card | Avoid |
| **Render** | Free spins down after 15 min idle | Avoid for API |

We document Railway as the primary path because it's most popular
and has a $5 trial with no card; Koyeb as the truly-free path for
low traffic; Northflank as the always-free multi-service path.

## 2. Component → provider mapping

| Component | Provider (Railway) | Provider (Koyeb free) | Provider (Northflank free) |
|-----------|--------------------|-------------------------|------------------------------|
| API | Web service | Service 1 | Service 1 |
| Bot | Worker service | Service 2 (long-lived) | Service 2 |
| Worker | Worker service | (run in API service as subprocess) | Service 3 |
| Beat | Worker service | (cron trigger on API service) | Service 4 |
| Postgres | Railway Postgres | Neon free tier | Neon free tier |
| Redis | Upstash free | Upstash free | Upstash free |
| Object store | Cloudflare R2 | Cloudflare R2 | Cloudflare R2 |
| Stripe webhooks | API service | API service | API service |

**Northflank free** is the recommended path for production on a
shoestring because it gives **2 services free forever** (no card,
no trial countdown). We run API+Bot in one service, Worker+Beat in
another, with a managed Postgres + Redis.

## 3. Architecture diagrams

### Railway

```
                         ┌───────────────────────┐
                         │  Cloudflare (free)    │
                         │  - DDoS shield        │
                         │  - TLS termination   │
                         └───────────┬───────────┘
                                     │
                ┌────────────────────┼────────────────────┐
                │                    │                    │
        ┌───────▼───────┐    ┌───────▼───────┐    ┌───────▼───────┐
        │ argus-api     │    │ argus-bot     │    │ argus-worker  │
        │ (web)         │    │ (worker)      │    │ (worker)      │
        │ 2 replicas    │    │ 1 replica     │    │ 1 replica     │
        │ 512 MB / 1vCPU│    │ 512 MB / 1vCPU│    │ 1 GB / 2 vCPU │
        └───────┬───────┘    └───────┬───────┘    └───────┬───────┘
                │                    │                    │
                └─────────┬──────────┴──────────┬─────────┘
                          │                     │
                  ┌───────▼───────┐     ┌───────▼───────┐
                  │ Postgres      │     │ Redis         │
                  │ (Railway      │     │ (Upstash      │
                  │  plugin)      │     │  free)        │
                  └───────────────┘     └───────────────┘

        ┌───────────────────┐    ┌───────────────────┐
        │ R2 (evidence      │    │ Stripe (billing)  │
        │  blobs)           │    │                   │
        └───────────────────┘    └───────────────────┘
```

### Koyeb free

```
                       ┌───────────────────────┐
                       │  Cloudflare (free)    │
                       └───────────┬───────────┘
                                   │
                           ┌───────▼───────┐
                           │ argus-api     │  single nano service
                           │ (api+bot      │  256 MB / 0.1 vCPU
                           │  +worker      │  (worker as subprocess)
                           │  +beat)       │
                           └───────┬───────┘
                                   │
                          ┌────────┴────────┐
                          │                 │
                  ┌───────▼───────┐  ┌───────▼───────┐
                  │ Neon Postgres │  │ Upstash Redis │
                  │ (free)        │  │ (free)        │
                  └───────────────┘  └───────────────┘
```

Koyeb is **single-service**, so all four processes run as one. This
is fine for low traffic. We document it for the "absolutely free"
case but recommend Northflank for production.

### Northflank free

```
   argus-api+bot (Service 1, free)       argus-worker+beat (Service 2, free)
        │                                          │
        └─────────┬────────────────────────┬───────┘
                  │                        │
            ┌─────▼─────┐           ┌──────▼──────┐
            │ Neon      │           │ Upstash     │
            │ Postgres  │           │ Redis       │
            └───────────┘           └─────────────┘
```

## 4. Dockerfile (single, multi-target)

We use a single Dockerfile with build args, **not** four separate
files. Railway/Koyeb/Northflank all support `docker build` with
target args.

```dockerfile
# ops/docker/Dockerfile
ARG PYTHON_VERSION=3.12

FROM python:${PYTHON_VERSION}-slim AS base

ENV PYTHONDONTWRITEBYTECODE=1 \
    PYTHONUNBUFFERED=1 \
    PIP_NO_CACHE_DIR=1 \
    PIP_DISABLE_PIP_VERSION_CHECK=1 \
    UV_LINK_MODE=copy

# Install uv (fast package manager) — works without Docker cache
RUN pip install uv==0.5.0

WORKDIR /app

# Layer cache: deps first
COPY pyproject.toml uv.lock ./
COPY libs/argus_common/pyproject.toml libs/argus_common/
COPY libs/argus_db/pyproject.toml libs/argus_db/
COPY domain/pyproject.toml domain/
COPY services/api/pyproject.toml services/api/
COPY services/bot/pyproject.toml services/bot/
COPY services/worker/pyproject.toml services/worker/
COPY plugins/ plugins/

RUN --mount=type=cache,target=/root/.cache/uv \
    uv sync --frozen --all-extras --group prod

# Then source
COPY . .

ARG SERVICE=api
ENV SERVICE=${SERVICE}

# Healthcheck per service
HEALTHCHECK --interval=30s --timeout=5s --start-period=20s --retries=3 \
    CMD python -c "import urllib.request,sys; \
        sys.exit(0 if urllib.request.urlopen('http://localhost:${PORT}/health').getcode()==200 else 1)"

# Runtime
ENV PORT=8080
EXPOSE 8080

# Service-specific command
CMD ["sh", "-c", "uv run argus-${SERVICE}"]
```

The entry-point scripts (`argus-api`, `argus-bot`, `argus-worker`)
are thin Python wrappers in each service's `src/argus_*/__main__.py`.

## 5. Railway (`ops/railway/railway.toml`)

```toml
[build]
builder = "DOCKERFILE"
dockerfilePath = "ops/docker/Dockerfile"

[deploy]
startCommand = "uv run argus-api"
healthcheckPath = "/health"
healthcheckTimeout = 10
restartPolicyType = "ON_FAILURE"
restartPolicyMaxRetries = 5
numReplicas = 1

[[deploy.ports]]
port = 8080

[[deploy.variables]]
name = "ARGUS_SERVICE"
value = "api"

[env]
PYTHON_VERSION = "3.12"
LOG_FORMAT = "json"
```

Railway project layout (via `railway init`):

```
argus/
├── api        # service
├── bot        # service
├── worker     # service
└── postgres   # plugin
```

Each service has its own `railway.toml` (or shared one with build
args).

## 6. Koyeb (`ops/koyeb/koyeb.yaml`)

```yaml
apps:
  - name: argus-api
    type: web
    docker:
      image: ghcr.io/argus-saas/argus:latest
      build:
        dockerfile: ops/docker/Dockerfile
        build_args:
          SERVICE: api
    env:
      ARGUS_SERVICE: api
      ARGUS_API_PORT: 8080
      DATABASE_URL: { from_secret: true }
      ARGUS_REDIS_URL: { from_secret: true }
    health_check:
      path: /health
      port: 8080
    regions:
      - fra
    scalings:
      min: 1
      max: 1
```

For free tier, we collapse to one app with all services started via
supervisord. We document the multi-app variant as the upgrade path
when the user adds card billing.

## 7. Northflank (`ops/northflank/northflank.yml`)

Two services on free tier:

```yaml
apiVersion: northflank.com/v1
kind: Service
metadata:
  name: argus-api-bot
spec:
  deployment:
    image:
      dockerfilePath: ops/docker/Dockerfile
      buildArgs: { SERVICE: api }
  ports:
    - port: 8080
      protocol: HTTP
  healthChecks:
    - type: HTTP
      port: 8080
      path: /health
  resources:
    memory: 512Mi
    cpu: 0.5
---
apiVersion: northflank.com/v1
kind: Service
metadata:
  name: argus-worker
spec:
  deployment:
    image:
      dockerfilePath: ops/docker/Dockerfile
      buildArgs: { SERVICE: worker }
  healthChecks:
    - type: exec
      command: ["celery", "-A", "argus_worker.celery_app", "inspect", "ping"]
  resources:
    memory: 1024Mi
    cpu: 1.0
```

## 8. Object store

Cloudflare R2 (S3-compatible) — free 10 GB / 10M reads / 1M writes
per month.

```python
# libs/argus_common/storage.py
import boto3
from botocore.config import Config

def make_s3_client(settings):
    return boto3.client(
        "s3",
        endpoint_url=settings.r2.endpoint,
        aws_access_key_id=settings.r2.access_key,
        aws_secret_access_key=settings.r2.secret_key,
        region_name="auto",
        config=Config(retries={"max_attempts": 3, "mode": "adaptive"}),
    )

def put_blob(client, key: str, body: bytes, content_type: str) -> str:
    client.put_object(Bucket=settings.r2.bucket, Key=key,
                      Body=body, ContentType=content_type)
    return key

def signed_url(client, key: str, expires_in: int = 300) -> str:
    return client.generate_presigned_url(
        "get_object",
        Params={"Bucket": settings.r2.bucket, "Key": key},
        ExpiresIn=expires_in,
    )
```

## 9. Postgres

| Provider | Free tier | Notes |
|----------|-----------|-------|
| Railway | 500 MB, $5 trial | Easiest on Railway |
| Neon | 512 MB always free | Best for Koyeb/Northflank |
| Supabase | 500 MB | Has free tier |

We connect via `asyncpg` + SQLAlchemy 2. SSL mode required.

```python
# libs/argus_db/session.py
from sqlalchemy.ext.asyncio import create_async_engine, async_sessionmaker

def make_engine(url: str):
    return create_async_engine(
        url,
        pool_size=10,
        max_overflow=20,
        pool_pre_ping=True,
        pool_recycle=1800,
        connect_args={
            "ssl": "require",
            "server_settings": {"jit": "off", "application_name": "argus"},
        },
    )

SessionLocal = async_sessionmaker(
    bind=make_engine(os.environ["DATABASE_URL"]),
    expire_on_commit=False,
    class_=AsyncSession,
)
```

## 10. Redis

Upstash free: 256 MB, 10k commands/day. Sufficient for early
traffic. Add card billing when exceeding.

```python
# libs/argus_common/redis.py
import redis.asyncio as redis_async

def make_redis(url: str) -> redis_async.Redis:
    return redis_async.from_url(
        url, encoding="utf-8", decode_responses=False,
        max_connections=50, retry_on_timeout=True,
        health_check_interval=30,
    )
```

## 11. Migrations at startup

The **worker** is the migration runner. The **API** asserts head.

```python
# services/api/src/argus_api/lifespan.py
@asynccontextmanager
async def lifespan(app: FastAPI):
    configure_logging("api")
    init_sentry("api", settings)
    # Check DB is at head
    alembic_current = await run_alembic(["current"])
    alembic_head = await run_alembic(["heads"])
    if alembic_current != alembic_head:
        raise MigrationDriftError(current=alembic_current, head=alembic_head)
    # Startup probes
    await wait_db()
    await wait_redis()
    await wait_object_store()
    yield
    await close_redis()
    await close_engine()
```

```python
# services/worker/cmd/migrate.py
async def main():
    configure_logging("worker")
    await run_alembic(["upgrade", "head"])
```

## 12. Environment variables

`.env.example` (checked into repo) plus `Settings` validates at
boot. Critical ones:

```bash
# ── core ─────────────────────────────────────────────────────────
ARGUS_ENV=production
ARGUS_RELEASE=v1.0.0
LOG_LEVEL=INFO
LOG_FORMAT=json

# ── service ──────────────────────────────────────────────────────
ARGUS_SERVICE=api                    # api|bot|worker|beat
ARGUS_API_PORT=8080
ARGUS_PUBLIC_URL=https://api.argus.saas
ARGUS_BOT_TOKEN=...                  # from @BotFather
ARGUS_BOT_TOKEN_ENCRYPTION_KEY=...   # Fernet base64

# ── db ───────────────────────────────────────────────────────────
DATABASE_URL=postgresql+asyncpg://user:pass@host:5432/argus

# ── redis ────────────────────────────────────────────────────────
ARGUS_REDIS_URL=rediss://default:pass@host:6379

# ── storage ──────────────────────────────────────────────────────
ARGUS_R2_ENDPOINT=https://<account>.r2.cloudflarestorage.com
ARGUS_R2_BUCKET=argus-evidence
ARGUS_R2_ACCESS_KEY=...
ARGUS_R2_SECRET_KEY=...

# ── auth ─────────────────────────────────────────────────────────
ARGUS_JWT_PRIVATE_KEY=...
ARGUS_JWT_PUBLIC_KEY=...
ARGUS_JWT_KEY_ID=2026-04-01
ARGUS_JWT_ACCESS_TTL=900
ARGUS_JWT_REFRESH_TTL=2592000

# ── billing ──────────────────────────────────────────────────────
ARGUS_STRIPE_SECRET=sk_live_...
ARGUS_STRIPE_WEBHOOK_SECRET=whsec_...

# ── observability ────────────────────────────────────────────────
ARGUS_SENTRY_DSN=https://...@sentry.io/...
ARGUS_OTEL_EXPORTER_OTLP_ENDPOINT=https://...
ARGUS_OTEL_SAMPLING_RATIO=0.1

# ── plugin registry ──────────────────────────────────────────────
ARGUS_PLUGIN_REGISTRY_PUBLIC_KEY=...
ARGUS_PLUGIN_STORAGE_DIR=/var/lib/argus/plugins
```

## 13. Secrets handling

- All secrets via env. Never in code or images.
- `.env.example` is committed; `.env` is `.gitignore`d.
- On Railway: env vars set per service in dashboard.
- On Koyeb: secrets via `koyeb secrets create`.
- On Northflank: secrets via `northflank secrets create`.
- Local Termux: secrets via `~/.config/argus/secrets.env`.

## 14. Boot sequence on a fresh deploy

```bash
# 1. Deploy infra (Postgres, Redis, R2)
# Provider-specific CLI or web UI.

# 2. Push code
git push railway main   # or koyeb/northflank equivalent

# 3. Run migrations (via worker service on first boot)
# Worker runs `alembic upgrade head` automatically on cold start.

# 4. Seed plans + plugin catalog (one-time)
railway run uv run python -m argus_db.seed

# 5. Set webhook URL for bot (if webhook mode)
curl -X POST https://api.telegram.org/bot<TOKEN>/setWebhook \
     -d "url=https://api.argus.saas/bot/webhook"

# 6. Smoke test
curl https://api.argus.saas/health
# {"status":"ok",...}

# 7. Send /start to bot
# Confirm main menu appears.
```

## 15. Capacity & cost projections

### Free tier (steady state)

| Component | Cost |
|-----------|------|
| Railway trial / Northflank free | $0 |
| Neon Postgres free | $0 |
| Upstash Redis free | $0 |
| R2 free | $0 (under 10 GB) |
| Telegram | $0 |
| Total | **$0** |

Sustains ~50 investigations/day, ~500 events/sec.

### $5/mo Railway (early traction)

- 3 services on $5 plan: API + Bot + Worker, shared Postgres.
- Sustains ~500 investigations/day, ~5k events/sec.

### $20/mo (10k investigations/day)

- 2× API, 2× Bot, 2× Worker.
- Postgres $10/mo (4 GB).
- Upstash $5/mo.
- R2 $1/mo.

## 16. Database migration runbook

```bash
# Local
./scripts/migrate.sh upgrade

# Production (manual, safer)
railway run --service worker \
    bash -c 'alembic upgrade head'

# Auto on cold start
# (worker process runs `alembic upgrade head` if MIGRATE_ON_START=1)
```

## 17. Rollback

- **App rollback**: Railway reverts to previous deploy on
  `railway up --rollback`. Koyeb keeps last 5 deployments.
- **DB rollback**: `alembic downgrade -1`. **Only** if a destructive
  migration hasn't run yet. We never auto-rollback DB.
- **Plugin rollback**: bump `plugin.plugin.latest_version` back; new
  investigations use old version.

## 18. Multi-region (V3)

We pin a single region in V1 (cheapest). V3 adds:

- One region per tenant home.
- NATS JetStream for cross-region events.
- Read replicas in EU and US for latency.

## 19. Backup strategy

- `pg_dump` nightly, encrypted, uploaded to R2.
- WAL archiving via managed provider.
- Object store versioning enabled.
- 30-day retention; monthly restore drill.

## 20. Disaster recovery

- DB total loss → restore from latest dump + WAL, ≤ 30 min RPO.
- Redis loss → rebuild from scratch, no data loss (cache only).
- Object store loss → restore from R2 versioning or rebuild from
  evidence rows that still have inline `raw`.
- RPO: 24h (DB), RTO: 1h.

## 21. Why we avoid Docker for local dev

Termux on Android **can** run Docker (via `dockerd` in proot), but:

- Slow.
- Unreliable networking.
- Eats battery.
- Many features (cgroups, namespaces) are no-ops.

Our local dev uses native Termux + proot. Docker is **only** for
PaaS build. This matches the "no Docker as a development dependency"
requirement.
