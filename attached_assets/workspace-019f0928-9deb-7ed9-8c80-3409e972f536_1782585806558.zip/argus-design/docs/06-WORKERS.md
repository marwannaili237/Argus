# 06 — Worker Architecture

## 0. Why Celery (and not Dramatiq)

We pick **Celery 5.4** because:

- `celery-beat` is the most mature cron scheduler in Python.
- `Flower` gives us a UI for free (great for solo dev from Termux).
- Plays cleanly with Redis as both broker and result backend.
- Largest hiring pool when we add engineers.
- Existing knowledge base when debugging.

Dramatiq is excellent but:

- `dramatiq-cron` is younger.
- No built-in monitoring UI.
- Less compatible with our Redis Streams event bus.

We could swap later — task definitions are isolated in one package.

## 1. Process model

```
                  ┌──────────────────────────────────────────┐
                  │           celery beat                     │
                  │   schedules:                              │
                  │     - quota_reset_daily @ 00:00 UTC      │
                  │     - dashboard_refresh @ :15             │
                  │     - export_cleanup @ 03:00              │
                  │     - gdpr_purge_check  @ hourly          │
                  └─────────────┬─────────────────────────────┘
                                │ enqueues
                                ▼
   ┌──────────────────────────────────────────────────────────┐
   │                  Redis broker                            │
   │                                                          │
   │  Queues (priority high → low):                           │
   │    - ctrl              (cancel, pause, resume)           │
   │    - plugin:{name}     (per-plugin isolation)            │
   │    - evidence          (post-process)                    │
   │    - entity            (extraction)                      │
   │    - relationship      (graph build)                     │
   │    - export            (rendering)                       │
   │    - billing           (webhooks, reconciliation)        │
   │    - maintenance       (cleanup, backups)                │
   └─────────────┬────────────────────────────────────────────┘
                 │ pulled by
                 ▼
   ┌──────────────────────────────────────────────────────────┐
   │  celery worker (concurrency=4)                           │
   │                                                          │
   │  Q listener config:                                      │
   │    - ctrl       concurrency=2                             │
   │    - plugin:*   concurrency=2 (round-robin)               │
   │    - evidence,entity,relationship,export 1 each           │
   │                                                          │
   │  Plugins run as subprocesses inside the worker            │
   │  (one subprocess per task, terminated on timeout)        │
   └──────────────────────────────────────────────────────────┘
```

## 2. Celery configuration

```python
# services/worker/src/argus_worker/celery_app.py
from celery import Celery
from celery.schedules import crontab
from kombu import Queue, Exchange

from argus_common.settings import Settings

settings = Settings()

app = Celery(
    "argus",
    broker=settings.redis.url,
    backend=settings.redis.url,
    include=[
        "argus_worker.tasks.investigation",
        "argus_worker.tasks.evidence",
        "argus_worker.tasks.plugin_runner",
        "argus_worker.tasks.export",
        "argus_worker.tasks.billing",
    ],
)

# ── Queues ─────────────────────────────────────────────────────
default_exchange = Exchange("argus", type="direct")
priority_exchange = Exchange("argus.priority", type="direct")

app.conf.task_queues = (
    Queue("ctrl",        priority_exchange, routing_key="ctrl",     priority=10),
    Queue("plugins",     default_exchange,  routing_key="plugins",  priority=5),
    Queue("evidence",    default_exchange,  routing_key="evidence", priority=3),
    Queue("entity",      default_exchange,  routing_key="entity",   priority=3),
    Queue("relationship",default_exchange,  routing_key="rel",      priority=3),
    Queue("export",      default_exchange,  routing_key="export",   priority=2),
    Queue("billing",     default_exchange,  routing_key="billing",  priority=5),
    Queue("maintenance", default_exchange,  routing_key="maint",    priority=1),
)

# ── Routing ────────────────────────────────────────────────────
app.conf.task_routes = {
    "argus.investigation.*":     {"queue": "ctrl"},
    "argus.plugin.*":            {"queue": "plugins"},
    "argus.evidence.*":          {"queue": "evidence"},
    "argus.entity.*":            {"queue": "entity"},
    "argus.relationship.*":      {"queue": "relationship"},
    "argus.export.*":            {"queue": "export"},
    "argus.billing.*":           {"queue": "billing"},
    "argus.maintenance.*":       {"queue": "maintenance"},
}

# ── Execution ──────────────────────────────────────────────────
app.conf.worker_prefetch_multiplier = 1
app.conf.task_acks_late = True
app.conf.worker_max_tasks_per_child = 200      # recycle to bound memory
app.conf.worker_max_memory_per_child = 512_000 # KB
app.conf.task_reject_on_worker_lost = True
app.conf.broker_transport_options = {
    "visibility_timeout": 1800,   # 30 min hard cap per task
    "queue_order_strategy": "priority",
}
app.conf.result_expires = 3600
app.conf.task_serializer = "json"
app.conf.result_serializer = "json"
app.conf.accept_content = ["json"]
app.conf.timezone = "UTC"
app.conf.enable_utc = True

# ── Beat schedule ──────────────────────────────────────────────
app.conf.beat_schedule = {
    "quota-reset-daily": {
        "task": "argus.billing.reset_daily_quotas",
        "schedule": crontab(hour=0, minute=5),
    },
    "dashboard-refresh": {
        "task": "argus.maintenance.refresh_dashboard_mv",
        "schedule": crontab(minute=15),  # every hour at :15
    },
    "export-cleanup": {
        "task": "argus.maintenance.cleanup_expired_exports",
        "schedule": crontab(hour=3, minute=0),
    },
    "gdpr-purge-check": {
        "task": "argus.maintenance.run_pending_purges",
        "schedule": crontab(minute=0),  # every hour at :00
    },
    "session-cleanup": {
        "task": "argus.maintenance.cleanup_idempotency",
        "schedule": crontab(hour=2, minute=0),
    },
}
```

## 3. Task anatomy

```python
# services/worker/src/argus_worker/tasks/investigation.py
from celery import shared_task
from argus_common.logging import configure_logging
from argus_common.events.bus import event_bus
from argus_common.errors import ArgusError
from argus_db.session import session_scope
from argus_db.repositories.investigation import InvestigationRepo
from argus_domain.investigations.planner import plan

logger = configure_logging("worker")

@shared_task(
    name="argus.investigation.plan",
    bind=True,
    max_retries=2,
    default_retry_delay=10,
    autoretry_for=(ArgusError,),
    retry_backoff=True,
    retry_backoff_max=60,
    retry_jitter=True,
    acks_late=True,
)
def plan_investigation(self, investigation_id: str) -> dict:
    """Compute plugin DAG and enqueue leaf tasks."""
    request_id = self.request.id
    structlog.contextvars.bind_contextvars(
        request_id=request_id, investigation_id=investigation_id,
        task="plan_investigation",
    )
    try:
        with session_scope() as session:
            repo = InvestigationRepo(session)
            inv = repo.get_by_id(investigation_id)
            if inv.status != "pending":
                logger.info("plan.skipped", status=inv.status)
                return {"skipped": True, "status": inv.status}
            dag = plan(target=inv.target, installed_plugins=inv.installed_plugins)
            repo.attach_plan(inv.id, dag)
            inv.start()
            session.commit()

        # Fan-out
        from argus_worker.tasks.plugin_runner import run_plugin
        chord(
            group(run_plugin.s(investigation_id, step.plugin, step.input)
                  for step in dag.leaf_steps),
            reduce_investigation.s(investigation_id),
        ).apply_async()

        await_event_bus.publish("investigation.planned",
                                {"investigation_id": investigation_id})
        return {"planned_steps": len(dag.leaf_steps)}
    except ArgusError as e:
        logger.error("plan.failed", error=str(e))
        raise
    finally:
        structlog.contextvars.clear_contextvars()
```

## 4. Retry strategy

| Task | max_retries | backoff | autoretry_for |
|------|-------------|---------|---------------|
| `argus.investigation.plan` | 2 | exp, max 60s | DB connection, transient |
| `argus.plugin.run` | 3 | exp, max 300s | network, timeout |
| `argus.evidence.persist` | 5 | exp, max 60s | S3 transient |
| `argus.entity.extract` | 2 | exp, max 30s | model load |
| `argus.export.render` | 2 | exp, max 60s | template load |
| `argus.billing.*` | 5 | exp, max 300s | Stripe transient |

`max_retries` is per-execution attempt. After that, the task is sent
to **dead-letter queue** (`argus.dlq`). A Celery beat job drains DLQ
to `audit.event` for ops review.

```python
@shared_task(name="argus.maintenance.drain_dlq")
def drain_dlq():
    """Inspect failed tasks and emit audit events."""
    with session_scope() as s:
        for failed in s.query(InvestigationORM).filter(
            InvestigationORM.status == "failed").all():
            audit.write(s, action="investigation.failed",
                        target_id=failed.id,
                        payload={"attempts": failed.attempts})
```

## 5. Plugin runner

Plugins run in **subprocesses** for hard isolation. The worker
serializes input to JSON, spawns the plugin, reads JSONL output until
EOF, kills if timeout.

```python
# services/worker/src/argus_worker/tasks/plugin_runner.py
import asyncio
import json
import os
import resource
import signal
import tempfile
from pathlib import Path

from celery import shared_task

from argus_worker.plugin_runtime.loader import load_plugin
from argus_worker.plugin_runtime.api import PluginContext
from argus_common.events.bus import event_bus

@shared_task(
    name="argus.plugin.run",
    bind=True,
    max_retries=3,
    default_retry_delay=30,
    autoretry_for=(PluginTransientError,),
    acks_late=True,
    time_limit=300,
    soft_time_limit=240,
)
def run_plugin(self, investigation_id: str, plugin_name: str,
               plugin_version: str, input: dict, plugin_run_id: str):
    plugin = load_plugin(plugin_name, plugin_version)
    with tempfile.TemporaryDirectory() as tmp:
        in_path  = Path(tmp) / "in.json"
        out_path = Path(tmp) / "out.jsonl"
        log_path = Path(tmp) / "log.txt"
        in_path.write_text(json.dumps(input))

        ctx = PluginContext(
            investigation_id=investigation_id,
            plugin_run_id=plugin_run_id,
            workdir=tmp,
            capabilities=plugin.manifest.capabilities,
        )

        # Build argv
        argv = [
            plugin.python,
            str(plugin.entrypoint),
            "--in", str(in_path),
            "--out", str(out_path),
            "--log", str(log_path),
            "--ctx", json.dumps(ctx.to_dict()),
        ]

        proc = subprocess.Popen(
            argv,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            preexec_fn=_preexec_limits,
        )
        try:
            stdout, _ = proc.communicate(timeout=300)
        except subprocess.TimeoutExpired:
            proc.kill()
            proc.wait()
            raise PluginTransientError("plugin timeout")

        # Apply rlimits retroactively (best-effort on Termux where
        # `resource` may be a no-op for RLIMIT_AS).
        if proc.returncode != 0:
            log_tail = log_path.read_text()[-2000:]
            raise PluginExecutionError(
                f"exit={proc.returncode}",
                log_tail=log_tail,
            )

        # Stream evidence events
        for line in out_path.read_text().splitlines():
            record = json.loads(line)
            if record["type"] == "evidence":
                asyncio.run(persist_evidence(record))
                event_bus.publish("evidence.found", record["payload"])
            elif record["type"] == "log":
                logger.info("plugin.log", **record["payload"])
```

`pre_exec` sets resource limits:

```python
def _preexec_limits():
    # CPU seconds
    resource.setrlimit(resource.RLIMIT_CPU, (240, 240))
    # Address space (1 GB)
    resource.setrlimit(resource.RLIMIT_AS, (1 << 30, 1 << 30))
    # File size (200 MB)
    resource.setrlimit(resource.RLIMIT_FSIZE, (200 * 1024 * 1024,) * 2)
    # File descriptors
    resource.setrlimit(resource.RLIMIT_NOFILE, (256, 256))
    # Children (no fork bombs)
    resource.setrlimit(resource.RLIMIT_NPROC, (4, 4))
    # New process group so we can kill the whole tree
    os.setsid()
```

## 6. Plugin runtime API

```python
# services/worker/src/argus_worker/plugin_runtime/api.py
from dataclasses import dataclass
from typing import Any

@dataclass(slots=True)
class PluginContext:
    investigation_id: str
    plugin_run_id: str
    workdir: str
    capabilities: tuple[str, ...]

    def to_dict(self) -> dict: ...
```

Plugins import only `argus_plugin_sdk` which is a tiny frozen stdlib
plus a Pydantic-validated facade:

```python
# plugins/plugin_whois/src/argus_whois/__init__.py
from argus_plugin_sdk import http, db, log, emit, ctx

def setup():
    log.info("whois.setup", target=ctx.target)

def run():
    rdap = http.get(f"https://rdap.org/{ctx.target.kind}/{ctx.target.value}")
    db.write_evidence(kind="whois_record", summary=rdap.summary, raw=rdap.raw)
    emit.evidence(summary={"registrar": rdap.registrar})
```

Plugin SDK is vendored in `plugins/_sdk/` and is the **only** Python
plugin authors see. Plugins cannot `import os`, `subprocess`, `socket`,
`asyncio`, `urllib`, `httpx`, etc. — those modules are deleted from
`sys.modules` at startup. The SDK exposes only safe helpers.

## 7. Evidence persistence

```python
# services/worker/src/argus_worker/tasks/evidence.py
@shared_task(name="argus.evidence.persist")
def persist_evidence(record: dict):
    with session_scope() as session:
        repo = EvidenceRepo(session)
        evidence = repo.create(
            investigation_id=record["investigation_id"],
            plugin_run_id=record["plugin_run_id"],
            kind=record["kind"],
            summary=record["summary"],
            raw=record.get("raw"),
            confidence=record.get("confidence", 1.0),
            source_url=record.get("source_url"),
        )
        if blob := record.get("blob"):
            key = object_store.put(
                BytesIO(base64.b64decode(blob["content_b64"])),
                content_type=blob["content_type"],
                key_prefix=f"evidence/{evidence.investigation_id}",
            )
            evidence.storage_key = key
        session.commit()
    # Trigger entity extraction async
    extract_entities_for_evidence.delay(record["evidence_id"])
```

## 8. Entity extraction

```python
# services/worker/src/argus_worker/tasks/entity.py
@shared_task(name="argus.entity.extract")
def extract_entities_for_evidence(evidence_id: str):
    with session_scope() as s:
        ev = EvidenceRepo(s).get(evidence_id)
        if not ev.raw and not ev.summary:
            return
        entities = entity_extractor.extract(ev)
        for ent in entities:
            EntityRepo(s).upsert(
                investigation_id=ev.investigation_id,
                type=ent.type, value=ent.value,
                aliases=ent.aliases, attributes=ent.attributes,
            )
        s.commit()
        # Trigger relationship discovery
        discover_relationships.delay(ev.investigation_id)
```

`entity_extractor.extract` is a domain-level service that combines:

- Regex matchers (emails, phones, URLs, domains, BTC addresses).
- Optional spaCy NER (if `spacy` extras installed).
- Heuristic normalization (lowercase domains, +E.164 phones).

We deliberately keep V1 simple. ML-based resolution is post-launch.

## 9. Relationship engine

```python
@shared_task(name="argus.relationship.discover")
def discover_relationships(investigation_id: str):
    with session_scope() as s:
        entities = EntityRepo(s).list(investigation_id)
        evidence = EvidenceRepo(s).list(investigation_id)

        graph = build_cooccurrence_graph(entities, evidence)

        RelationshipRepo(s).replace_for_investigation(
            investigation_id, graph.edges,
        )
        s.commit()
```

`build_cooccurrence_graph` is pure domain: any two entities that
appear in the same evidence are connected with weight = shared
evidence count. Domain-specific rules add typed edges
("email → username", "domain → registrar", etc.).

## 10. Export rendering

```python
@shared_task(name="argus.export.render", bind=True, max_retries=2)
def render_export(self, export_id: str):
    with session_scope() as s:
        exp = ExportRepo(s).get(export_id)
        if exp.status == "ready":
            return {"skipped": True}
        exp.status = "running"
        s.commit()

    try:
        investigation = load_investigation_full(exp.investigation_id)
        if exp.format == "json":
            blob = render_json(investigation)
        elif exp.format == "csv":
            blob = render_csv(investigation)
        elif exp.format == "pdf":
            blob = render_pdf(investigation)
        else:
            raise ValueError(f"unknown format {exp.format}")

        if len(blob) > MAX_EXPORT_BYTES:
            raise ExportTooLargeError()

        key = object_store.put(
            BytesIO(blob),
            content_type=CONTENT_TYPES[exp.format],
            key_prefix=f"exports/{exp.investigation_id}",
        )
        signed_url = object_store.signed_url(key, expires_in=7 * 24 * 3600)

        with session_scope() as s:
            exp = ExportRepo(s).get(export_id)
            exp.status = "ready"
            exp.size_bytes = len(blob)
            exp.storage_key = key
            exp.download_url = signed_url
            exp.finished_at = datetime.now(UTC)
            s.commit()

        event_bus.publish("export.ready", {"export_id": export_id})
        return {"size": len(blob)}
    except ExportTooLargeError:
        with session_scope() as s:
            exp = ExportRepo(s).get(export_id)
            exp.status = "failed"
            exp.error = "too_large"
            s.commit()
        raise
```

## 11. Investigation lifecycle

```
POST /v1/investigations
        │
        ▼
[API]  argus.investigation.plan            (queue: ctrl)
        │
        ▼
[WRK]  argus.plugin.run  ×N                (queue: plugins)
        │
        ├──▶ [WRK] argus.evidence.persist   (chord callback)
        │             │
        │             └──▶ argus.entity.extract
        │                            │
        │                            └──▶ argus.relationship.discover
        ▼
[WRK]  argus.investigation.reduce          (chord body)
        │
        ├── update progress, status → completed
        └── publish investigation.completed
```

We use Celery `chord` to coordinate. The chord body runs once all
leaves succeed; on leaf failure we retry, and after max retries the
chord body runs anyway with `body_error_handler` so we always get a
terminal status.

## 12. Worker process startup

```python
# services/worker/src/argus_worker/main.py
from celery.signals import worker_process_init, worker_process_shutdown
from argus_common.logging import configure_logging
from argus_common.settings import Settings
from argus_db.session import close_engine

@worker_process_init.connect
def on_init(**_):
    configure_logging("worker")
    # Warm-up: load spaCy model, plugin index
    from argus_worker.plugin_runtime.loader import warm_plugin_cache
    warm_plugin_cache()

@worker_process_shutdown.connect
def on_shutdown(**_):
    close_engine()
```

## 13. Run command

```bash
# Concurrency 4, all queues
celery -A argus_worker.celery_app worker \
      --loglevel=INFO \
      --concurrency=4 \
      -Q ctrl,plugins,evidence,entity,relationship,export,billing,maintenance

# Beat only
celery -A argus_worker.celery_app beat --loglevel=INFO
```

For Termux dev, `scripts/worker.sh` handles this.

## 14. Cancellation

When user clicks **Cancel** in the bot:

1. Bot calls `POST /v1/investigations/{id}/cancel`.
2. API updates DB status to `cancelling`, enqueues
   `argus.investigation.cancel_cleanup` task (priority queue `ctrl`).
3. Celery task aborts all running plugin tasks by calling
   `celery.app.control.revoke(task_id, terminate=True, signal="SIGTERM")`.
4. Plugin subprocesses receive SIGTERM, exit cleanly within 5 s, else
   SIGKILL.
5. Investigation status moves to `cancelled`.

This guarantees no zombie subprocesses.

## 15. Health and metrics

- Each worker exposes a Prometheus `/metrics` via `prometheus_client`
  started in `worker_process_init`.
- Custom metrics:
  - `argus_tasks_total{name,status}` counter
  - `argus_task_duration_seconds{name}` histogram
  - `argus_plugins_running{name}` gauge
  - `argus_dlq_size` gauge (poll Redis)

## 16. Failure modes — the table

| Failure | Behavior | Recovery |
|---------|----------|----------|
| Plugin OOM | rlimit kills it | Plugin runner sees non-zero exit, retries up to 3 |
| Plugin infinite loop | `soft_time_limit=240` sends SIGTERM | Same as OOM |
| Plugin bad code | Crash before output | Same |
| Plugin exfiltrates data | Capability whitelist blocks | Audit log; admin review |
| Postgres down mid-task | SA raises, task retries | Backoff; if persistent, DLQ |
| Redis down mid-task | broker reconnection | Tasks wait; eventually time out and retry |
| Worker OOM | `worker_max_tasks_per_child=200` recycle | Process restart |
| Beat process crashes | Restart manually | Investigation still runs, only periodic jobs missing |

## 17. Why `acks_late=True` everywhere

We use **late ack** so tasks are only acknowledged after they finish.
If the worker dies mid-task, Celery re-queues the task. The trade-off
is duplicate execution; we mitigate with **idempotency tokens** on
plugin_run rows.

## 18. Plugin version pinning

Each `plugin_run` row records the exact `plugin_version`. If the
plugin is upgraded mid-investigation, the running plugin finishes on
the old version. New investigations get the new version. We never
half-mix.

## 19. Sandbox escapes — what we do in V1

Subprocess + rlimits + capability whitelist is the V1 sandbox. We do
**not** claim it is bulletproof. We:

- Run plugins with the lowest-possible UID (a dedicated `argus_plugin`
  user in production).
- Network namespace isolation: outbound only to allowlisted DNS and
  HTTPS endpoints per plugin manifest.
- Strip env (only `PATH`, `LANG`, `HOME` minimal, `PYTHONPATH` to
  plugin site-packages).
- No `LD_PRELOAD`.

This is enough for V1. For V2 we plan seccomp + Landlock or firejail.
