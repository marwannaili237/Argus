# 00 — Architecture

## 0. Goals

1. Survive a single developer shipping from an Android phone.
2. Scale to thousands of concurrent investigations without rewrites.
3. Keep the Telegram bot dumb and replaceable.
4. Allow plugin authors to ship capabilities without touching core.

## 1. Layered model

```
┌────────────────────────────────────────────────────────────┐
│ Presentation / Edge                                        │
│  ├─ aiogram bot workers (one or many)                      │
│  └─ (optional) future web admin — FastAPI only             │
└────────────────────────────────────────────────────────────┘
                          │
                          ▼
┌────────────────────────────────────────────────────────────┐
│ Interface / Application (use cases)                        │
│  ├─ Routers (FastAPI) — auth, investigations, evidence,    │
│  │   exports, plugins, billing, health                     │
│  └─ Services (Celery tasks) — investigation.lifecycle,    │
│       evidence.ingest, plugin.run, export.render           │
└────────────────────────────────────────────────────────────┘
                          │
                          ▼
┌────────────────────────────────────────────────────────────┐
│ Domain Core (pure Python, framework-free)                  │
│  ├─ Entities (Investigation, Evidence, Entity, Relation)   │
│  ├─ Value objects (Target, PluginId, TenantId, Money)      │
│  ├─ Domain services (Planner, RelationshipEngine)          │
│  └─ Domain events (InvestigationCreated, EvidenceFound)    │
└────────────────────────────────────────────────────────────┘
                          │
                          ▼
┌────────────────────────────────────────────────────────────┐
│ Infrastructure                                             │
│  ├─ Postgres (SQLAlchemy 2 async)                          │
│  ├─ Redis (broker, cache, rate limit, event bus)           │
│  ├─ S3-compatible object store (evidence blobs)            │
│  └─ Plugin loader (subprocess workers via Celery)          │
└────────────────────────────────────────────────────────────┘
```

### Dependency direction

- Domain depends on **nothing** outside `stdlib` and `pydantic` (for VO
  validation only).
- Application depends on Domain + `Protocol`s declared in Domain.
- Infrastructure implements Domain protocols.
- Presentation depends on Application.

This is enforced with [import-linter](https://import-linter.readthedocs.io)
config in `configs/import-linter.toml`.

## 2. The five bounded contexts

We deliberately split the monolith along these seams. They are deployed
as **one repo, multiple processes**, not as microservices — but the
boundaries are strict so we can split later.

| Context | Process | Database | Notes |
|---------|---------|----------|-------|
| **Identity** | API | `argus` (shared) | Users, tenants, JWT keys |
| **Investigation** | API + Worker | `argus` (shared) | Investigations, planner, evidence |
| **Plugin Runtime** | Worker only | `argus` (shared) | Sandboxed plugin code |
| **Evidence** | Worker only | `argus` + object store | Large blobs off-row |
| **Billing** | API + Beat | `argus` (shared) | Quotas, Stripe webhooks |

A single Postgres for V1 is intentional — multi-DB is a premature
split. Logical isolation via schema namespacing (`identity.*`,
`investigation.*`, `billing.*`) gives us an easy future split.

## 3. Request lifecycle — example: "Start an investigation"

1. User taps **New Investigation** in Telegram.
2. Bot FSM collects target. Bot calls `POST /v1/investigations` with JWT.
3. API Auth dependency validates JWT → `user_id`, `tenant_id`, scopes.
4. Rate limiter middleware checks token bucket for `investigation:create`.
5. Use case `StartInvestigation.handle()` is invoked.
6. Domain method `Investigation.start()` validates target against plugin
   manifest contract. Emits `InvestigationCreated` event.
7. Event handler schedules Celery chord:
   `plan → fan-out plugin tasks → reduce → extract entities`.
8. Returns `202 Accepted` with `Location: /v1/investigations/{id}`.
9. Worker picks up tasks, fetches plugins, executes, writes evidence.
10. Each task emits events. Bot's long-poll task subscribes to event bus
    and edits the same Telegram message with progress.

## 4. Process topology

```
┌─────────────────────────────────────────────────────────────┐
│ Postgres 16 (managed)         Redis 7 (managed)             │
└──────────────▲────────────────────────▲─────────────────────┘
               │ asyncpg                │ redis.asyncio
   ┌───────────┴───────────┐   ┌────────┴────────┐
   │  API (uvicorn)        │   │ Bot (aiogram)  │
   │  gunicorn -w 2        │   │ 1 worker OK     │
   │  --worker-class       │   │ scales to N     │
   │  uvicorn.workers.     │   └─────────────────┘
   │  UvicornWorker        │
   └───────────┬───────────┘
               │ enqueues
               ▼
       ┌──────────────────┐    ┌──────────────────┐
       │ Celery Worker    │    │ Celery Beat      │
       │ concurrency=4    │    │ cron jobs only   │
       │ -Q plugins       │    └──────────────────┘
       │ -Q exports       │
       │ -Q evidence      │
       └──────────────────┘
               │
               ▼
       ┌──────────────────┐
       │ Flower (monitor) │
       └──────────────────┘
```

For free-tier deploys, you can collapse to:

- 1 API process
- 1 Bot process
- 1 Celery worker process with 2 concurrency
- 1 Beat process (only if you have free memory)

## 5. Concurrency and isolation

- Per-tenant queue: `investigation:t{tenant_id}` so a noisy tenant
  cannot starve others.
- Per-plugin queue: `plugin:{plugin_name}` so a slow plugin cannot
  block the rest.
- Soft concurrency limit per tenant (configurable).
- Hard concurrency limit per worker (Celery `worker_prefetch_multiplier=1`).
- Object-store writes are streamed via `aiofiles` so large evidence
  doesn't pin memory.

## 6. Failure model

| Failure | Detection | Recovery |
|---------|-----------|----------|
| Postgres down | API raises on connect | API returns 503; bot shows "service degraded" |
| Redis down | API falls back to local token bucket | Logs ERROR; alert via webhook |
| Worker crash mid-task | Celery requeues after visibility timeout | Up to 5 retries, exponential backoff |
| Plugin bad code | Plugin sandbox kills process | DLQ + admin notification |
| Bot rate-limited by Telegram | aiogram auto-handles via `RetryAfter` | Same |
| User spam | Per-user token bucket | 429 → bot edits message "slow down" |

## 7. Multi-tenancy

Single-tier, multi-tenant from day one. Every domain entity carries
`tenant_id`. Cross-tenant queries are forbidden by SA event hooks.
Tenant resolution: JWT `tenant_id` claim, validated against the row's
`tenant_id`. Indexes are prefixed with `tenant_id` for locality.

## 8. Quotas and billing

| Quota | Stored in | Default | Pro tier |
|-------|-----------|---------|----------|
| Investigations / month | `billing.quotas` | 20 | 500 |
| Concurrent running | Redis ZSET | 1 | 5 |
| Evidence / investigation | DB column | 1000 | 10000 |
| Plugin calls / minute | Redis | 30 | 300 |
| Export size MB | API check | 25 | 250 |

Stripe is the source of truth for subscription state. The API mirrors
it in `billing.subscriptions`. Quota enforcement is on the way in, not
on the way out — we soft-fail with `429 quota_exceeded` and surface
"upgrade" CTA in the bot.

## 9. Data retention and GDPR

- Evidence rows: configurable retention (default 90 days, configurable
  per tenant).
- Personal data minimization: bots receive minimal user info.
- Right-to-delete: `DELETE /v1/users/me` schedules a tombstone and a
  Celery task purges all rows + S3 keys for that user.
- Audit log: append-only `audit.events` table, never deleted.

## 10. Observability

Three pillars, all cheap:

1. **Logs** — `structlog` JSON to stdout; Loki on Railway / Logtail on
   others. See [12-LOGGING.md](12-LOGGING.md).
2. **Metrics** — Prometheus `/metrics` on API. Minimal set: request
   latency histogram, queue depth gauge, plugin success counter.
3. **Traces** — OpenTelemetry, OTLP HTTP exporter. Sampling 1 in 10 by
   default. Toggle via `OTEL_SAMPLING_RATIO`.

## 11. Security posture

- TLS 1.3 everywhere. No plaintext HTTP.
- Postgres TLS required.
- Redis with `requirepass` + ACLs.
- JWT signed with RS256, public key in env. Refresh tokens are
  one-time-use, stored hashed.
- Telegram login widget for bot-initiated JWT exchange (avoids bot
  knowing Telegram bot token for HMAC).
- All file uploads to bot flow: bot → API (multipart) → S3. Bot never
  holds large files.
- Plugin code is loaded from a curated registry; default policy is
  **deny**. Approval flow described in [07-PLUGIN-SDK.md](07-PLUGIN-SDK.md).
- Rate limit per IP and per user. Cloudflare in front of API (free
  tier) for DDoS.

## 12. Deployment topology

See [13-DEPLOYMENT.md](13-DEPLOYMENT.md) for full runbook.

```
   Cloudflare (free)
        │
        ▼
   Railway / Koyeb / Northflank
        │
   ┌────┴────┬────────┬─────────┐
   ▼         ▼        ▼         ▼
  API       Bot     Worker    Beat
  (1)       (1)     (1, c=2)  (1)
```

External services (all free-tier eligible):

| Service | Provider | Purpose |
|---------|----------|---------|
| Postgres | Railway / Neon / Supabase | Primary DB |
| Redis | Upstash / Redis Cloud | Cache, broker, bus |
| Object store | Backblaze B2 / R2 / Cloudflare R2 | Evidence blobs |
| Stripe | Stripe | Billing |
| Telegram | Telegram | Bot platform |
| Loki | Grafana Cloud | Logs (free 50GB/mo) |
| Sentry | Sentry.io | Errors (free 5k events/mo) |
