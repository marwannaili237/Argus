# 01 — Project Structure

## 0. Monorepo layout

Single repo. Single Python package layout per process. Shared `libs/`
for cross-process utilities (auth, http client, logging, settings).

```
argus/
├── README.md
├── pyproject.toml                 # Poetry / uv compatible
├── uv.lock                        # uv-resolved lock
├── .python-version                # 3.12.x
├── .gitignore
├── .editorconfig
├── .pre-commit-config.yaml
├── ruff.toml
├── mypy.ini
├── import-linter.toml             # boundary enforcement
├── .env.example
├── Makefile                       # thin wrappers around scripts/
│
├── libs/                          # cross-process shared code
│   ├── argus_common/
│   │   ├── __init__.py
│   │   ├── settings.py
│   │   ├── logging.py
│   │   ├── http.py
│   │   ├── auth/
│   │   │   ├── jwt.py
│   │   │   ├── password.py
│   │   │   └── telegram.py
│   │   ├── events/
│   │   │   ├── bus.py
│   │   │   ├── schemas.py
│   │   │   └── consumer.py
│   │   ├── ratelimit/
│   │   │   └── token_bucket.py
│   │   ├── errors.py
│   │   ├── time.py
│   │   ├── ids.py
│   │   └── pagination.py
│   └── argus_db/                  # shared models and repos
│       ├── __init__.py
│       ├── base.py                # DeclarativeBase, naming convention
│       ├── session.py             # async engine, sessionmaker
│       ├── migrations/            # alembic env
│       ├── models/
│       │   ├── __init__.py
│       │   ├── user.py
│       │   ├── tenant.py
│       │   ├── investigation.py
│       │   ├── evidence.py
│       │   ├── entity.py
│       │   ├── relationship.py
│       │   ├── plugin.py
│       │   ├── billing.py
│       │   ├── audit.py
│       │   └── api_key.py
│       └── repositories/
│           ├── __init__.py
│           ├── user.py
│           ├── investigation.py
│           ├── evidence.py
│           ├── plugin.py
│           └── billing.py
│
├── services/
│   ├── api/                       # FastAPI service
│   │   ├── pyproject.toml         # OR root pyproject is fine
│   │   ├── README.md
│   │   ├── src/argus_api/
│   │   │   ├── __init__.py
│   │   │   ├── main.py            # FastAPI app factory
│   │   │   ├── lifespan.py
│   │   │   ├── deps.py            # FastAPI dependencies
│   │   │   ├── middleware/
│   │   │   │   ├── correlation.py
│   │   │   │   ├── ratelimit.py
│   │   │   │   ├── errors.py
│   │   │   │   └── security_headers.py
│   │   │   ├── routers/
│   │   │   │   ├── __init__.py
│   │   │   │   ├── auth.py        # /v1/auth/*
│   │   │   │   ├── users.py       # /v1/users/*
│   │   │   │   ├── investigations.py
│   │   │   │   ├── evidence.py
│   │   │   │   ├── entities.py
│   │   │   │   ├── relationships.py
│   │   │   │   ├── plugins.py
│   │   │   │   ├── exports.py
│   │   │   │   ├── billing.py
│   │   │   │   ├── webhooks.py
│   │   │   │   └── health.py
│   │   │   ├── schemas/           # Pydantic request/response
│   │   │   │   ├── __init__.py
│   │   │   │   ├── auth.py
│   │   │   │   ├── investigation.py
│   │   │   │   ├── evidence.py
│   │   │   │   ├── entity.py
│   │   │   │   ├── plugin.py
│   │   │   │   ├── export.py
│   │   │   │   └── common.py
│   │   │   └── use_cases/         # application services
│   │   │       ├── __init__.py
│   │   │       ├── start_investigation.py
│   │   │       ├── cancel_investigation.py
│   │   │       ├── ingest_evidence.py
│   │   │       ├── extract_entities.py
│   │   │       ├── render_export.py
│   │   │       └── charge_quota.py
│   │   ├── tests/
│   │   │   ├── conftest.py
│   │   │   ├── test_auth.py
│   │   │   ├── test_investigations.py
│   │   │   ├── test_evidence.py
│   │   │   ├── test_plugins.py
│   │   │   ├── test_exports.py
│   │   │   └── contract/
│   │   │       └── test_openapi.py
│   │   └── alembic.ini            # symlinked to libs/argus_db/migrations
│   │
│   ├── bot/                       # aiogram service
│   │   ├── README.md
│   │   ├── src/argus_bot/
│   │   │   ├── __init__.py
│   │   │   ├── main.py            # aiogram Dispatcher entrypoint
│   │   │   ├── api_client.py      # thin wrapper around backend HTTP
│   │   │   ├── middlewares/
│   │   │   │   ├── auth.py
│   │   │   │   ├── logging.py
│   │   │   │   └── throttling.py
│   │   │   ├── handlers/
│   │   │   │   ├── __init__.py
│   │   │   │   ├── start.py
│   │   │   │   ├── menu.py
│   │   │   │   ├── investigation_new.py
│   │   │   │   ├── investigation_running.py
│   │   │   │   ├── investigation_completed.py
│   │   │   │   ├── evidence.py
│   │   │   │   ├── export.py
│   │   │   │   ├── profile.py
│   │   │   │   └── settings.py
│   │   │   ├── keyboards/
│   │   │   │   ├── inline.py
│   │   │   │   └── reply.py
│   │   │   ├── fsm/
│   │   │   │   ├── states.py
│   │   │   │   └── storage.py     # Redis FSM storage
│   │   │   ├── renderers/
│   │   │   │   ├── investigation.py
│   │   │   │   ├── evidence.py
│   │   │   │   ├── entities.py
│   │   │   │   └── export.py
│   │   │   ├── progress.py        # long-poll event subscription
│   │   │   └── callbacks.py       # callback data packing
│   │   └── tests/
│   │       ├── conftest.py
│   │       ├── test_handlers.py
│   │       └── test_renderers.py
│   │
│   └── worker/                    # Celery service
│       ├── README.md
│       ├── src/argus_worker/
│       │   ├── __init__.py
│       │   ├── celery_app.py
│       │   ├── tasks/
│       │   │   ├── __init__.py
│       │   │   ├── investigation.py
│       │   │   ├── evidence.py
│       │   │   ├── plugin_runner.py
│       │   │   ├── export.py
│       │   │   └── billing.py
│       │   ├── plugin_runtime/
│       │   │   ├── __init__.py
│       │   │   ├── loader.py
│       │   │   ├── sandbox.py     # subprocess / RestrictedPython
│       │   │   └── api.py         # what plugins are allowed to call
│       │   └── beat_schedule.py
│       └── tests/
│           ├── test_tasks.py
│           └── test_plugin_runtime.py
│
├── domain/                        # pure Python — NO infra deps
│   ├── pyproject.toml
│   └── src/argus_domain/
│       ├── __init__.py
│       ├── investigations/
│       │   ├── __init__.py
│       │   ├── aggregate.py      # Investigation
│       │   ├── status.py         # enum
│       │   ├── target.py         # VO
│       │   ├── planner.py        # domain service
│       │   └── events.py
│       ├── evidence/
│       │   ├── aggregate.py
│       │   ├── kind.py
│       │   └── events.py
│       ├── entities/
│       │   ├── aggregate.py
│       │   ├── type.py
│       │   └── events.py
│       ├── relationships/
│       │   ├── aggregate.py
│       │   └── graph.py
│       ├── plugins/
│       │   ├── manifest.py
│       │   ├── contract.py
│       │   └── registry.py
│       └── shared/
│           ├── ids.py
│           ├── money.py
│           └── time.py
│
├── plugins/                       # first-party plugins (optional)
│   ├── README.md
│   ├── plugin_whois/
│   ├── plugin_dns/
│   ├── plugin_social_x/
│   └── plugin_email_hunt/
│
├── ops/
│   ├── docker/                    # NOT FOR DEV — for PaaS only
│   │   ├── Dockerfile.api
│   │   ├── Dockerfile.bot
│   │   ├── Dockerfile.worker
│   │   └── Dockerfile.beat
│   ├── railway/
│   │   ├── railway.toml
│   │   └── Procfile
│   ├── koyeb/
│   │   └── koyeb.yaml
│   └── northflank/
│       └── northflank.yml
│
├── scripts/                       # bash helpers — replaces Makefile
│   ├── dev.sh
│   ├── serve.sh
│   ├── bot.sh
│   ├── worker.sh
│   ├── beat.sh
│   ├── migrate.sh
│   ├── test.sh
│   ├── lint.sh
│   ├── format.sh
│   ├── tmux-dev.sh
│   ├── termux-bootstrap.sh
│   ├── check-bot-boundaries.sh
│   ├── seed.sh
│   └── tail-logs.sh
│
├── tests/
│   ├── e2e/
│   ├── load/
│   │   └── locustfile.py
│   └── fixtures/
│       └── plugins/
│
└── docs/
    ├── 00-ARCHITECTURE.md
    ├── 01-PROJECT-STRUCTURE.md
    ├── ... (all 18)
    └── runbooks/
        ├── incident_postgres.md
        ├── incident_redis.md
        └── incident_bot_flood.md
```

## 1. Why this layout

- **Hexagonal in a flat repo.** Domain is a separate top-level package
  with no infra imports. API and Worker depend on it. Bot depends only
  on `argus_common` + API client, **never** on Domain directly.
- **`libs/argus_db` is the only place SQLAlchemy models live.** Both
  API and Worker import from it. This keeps DB-aware code out of the
  domain.
- **`libs/argus_common` is the only place `httpx`, `redis-py`, and
  `structlog` are imported.** Bot, API, Worker all share this. No
  divergence.
- **`ops/docker/` exists only for PaaS build.** Never required for
  local Termux development.
- **`plugins/` are first-party plugins shipped in-tree.** Third-party
  plugins are loaded from a registry (see 07-PLUGIN-SDK.md).

## 2. Naming conventions

| Item | Convention | Example |
|------|------------|---------|
| Package | snake_case | `argus_api`, `argus_db` |
| Module | snake_case | `investigation.py` |
| Class | PascalCase | `InvestigationAggregate` |
| Function | snake_case | `start_investigation` |
| Async function | prefix `await_` only when ambiguous | `await_load()` |
| Constant | UPPER_SNAKE | `MAX_EVIDENCE_PER_INVESTIGATION` |
| Type alias | PascalCase | `InvestigationId` |
| Pydantic model | PascalCase + suffix | `InvestigationCreate`, `InvestigationOut` |
| SQLAlchemy model | PascalCase | `InvestigationORM` |
| Alembic revision | 12-char hex | `a1b2c3d4e5f6` |
| Celery task name | dotted | `argus.investigation.plan` |
| Event topic | kebab-case | `investigation.created` |
| Env var | SCREAMING_SNAKE | `ARGUS_API_JWT_PRIVATE_KEY` |

## 3. File-level rules

- **No file over 400 lines.** If it grows, split.
- **One class per file** for aggregates; multiple per file for DTOs.
- **All `__init__.py` re-export the public API only.** Internal helpers
  are private (`_leading_underscore`).
- **Type hints everywhere.** `mypy --strict` on `libs/` and `domain/`.
- **Docstrings only on public API.** Google style.
- **No `from X import *`.** Period.

## 4. What each process owns

### API (`services/api`)

- Auth (JWT issue, refresh, Telegram login verification)
- Investigation CRUD (start, list, get, cancel, pause, resume)
- Evidence read endpoints
- Entity / relationship read endpoints
- Plugin manifest catalog (read-only)
- Export render triggers and download links
- Billing webhooks (Stripe)
- Health and metrics

### Worker (`services/worker`)

- Plan and dispatch plugin runs
- Run plugin code in sandbox
- Persist evidence rows + upload blobs
- Entity extraction (NER)
- Relationship graph construction
- Export rendering (PDF, CSV, JSON)
- Daily quota reset
- Tombstone purges (GDPR)

### Bot (`services/bot`)

- Render menus, FSM, keyboards
- Edit Telegram messages on progress updates
- Translate API responses to user-facing strings
- Throttle user input

## 5. Shared library contents

### `libs/argus_common/settings.py`

Pydantic Settings v2, single `Settings` class. Reads from env and
`.env`. Nested: `Settings.db`, `Settings.redis`, `Settings.api`,
`Settings.bot`, `Settings.billing`. Validated at process start.

### `libs/argus_common/logging.py`

`configure_logging(service_name)` — sets up structlog with JSON
renderer, correlation ID processor, env, level. Called once in
`lifespan` / `celery_worker_process_init` / bot `main.py`.

### `libs/argus_common/http.py`

Singleton HTTPX client with:

- Connection pooling (200 keepalive, 20 per host)
- HTTP/2
- Default timeout 30s, configurable per call
- Auto-retry with exponential backoff on 502/503/504 and connection
  errors
- Structured logging on each request
- Optional Tor / proxy rotation (for OSINT plugin traffic)

### `libs/argus_common/events/`

Event bus interface (`EventBus` Protocol) and Redis Streams
implementation. See [09-EVENT-SYSTEM.md](09-EVENT-SYSTEM.md).

### `libs/argus_common/ratelimit/`

Token bucket backed by Redis Lua script. Used by middleware.

## 6. Alembic layout

Single Alembic config rooted at `libs/argus_db/migrations/`. All
models live in `libs/argus_db/models/`. Migrations are **shared** across
services — API and Worker run migrations at startup (idempotent check,
only Worker runs `alembic upgrade head`; API runs `alembic current`
and asserts head).

Two migration branches in V1:

- `main` — schema
- `data` — seed data (only Stripe plans, plugin catalog)

Branches are merged before each release.

## 7. Configuration layering

Order of precedence (highest wins):

1. CLI flag (e.g. `--port`)
2. Env var (`ARGUS_API_PORT`)
3. `.env` file (gitignored)
4. `pyproject.toml` `[tool.argus]` defaults

Loaded by `pydantic-settings`. Validation errors are fatal at
startup — no silent fallbacks.

## 8. Where new code goes — decision tree

```
Is it pure logic with no framework imports?
  └─ yes → domain/

Does it coordinate domain objects and side effects?
  └─ yes → services/<process>/use_cases/

Is it FastAPI-specific (request/response shapes, deps, middleware)?
  └─ yes → services/api/

Is it Celery-specific (task definition, beat schedule)?
  └─ yes → services/worker/

Is it aiogram-specific (handlers, FSM, keyboards)?
  └─ yes → services/bot/

Is it DB-aware (SQLAlchemy models, repos)?
  └─ yes → libs/argus_db/

Is it shared infra (settings, logging, http, events, ratelimit)?
  └─ yes → libs/argus_common/

Is it a first-party plugin?
  └─ yes → plugins/<name>/

Is it deployment config?
  └─ yes → ops/<provider>/
```

## 9. Bootstrap order on a fresh clone

```bash
# from project root
scripts/termux-bootstrap.sh    # Termux only
./scripts/dev.sh bootstrap      # creates .venv, installs deps
./scripts/migrate.sh upgrade    # applies DB migrations
./scripts/seed.sh               # inserts plan + plugin catalog
./scripts/tmux-dev.sh start     # starts api+bot+worker+beat in tmux
```
