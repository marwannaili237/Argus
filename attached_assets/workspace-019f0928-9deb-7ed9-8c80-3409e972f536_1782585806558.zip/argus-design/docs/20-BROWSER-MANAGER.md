# 20 — Browser Manager

> Lifecycle, pooling, and health management for headless Chromium
> contexts used by the Scraping Engine. Worker-only. No browser ever
> runs in the API or Bot process.

---

## 0. Why a separate subsystem

Browser instances are:

- **Heavy** — 200-500 MB RSS each, 1 vCPU equivalent per context.
- **Slow to launch** — 2-5s for a fresh Chromium.
- **Stateful** — cookies, localStorage, IndexedDB.
- **Crash-prone** — memory leaks, GPU process crashes, page hangs.

The Scraping Engine needs a **stable supply** of healthy browser
contexts. It must not be concerned with launching, recycling, or
draining. Hence: `BrowserManager`.

## 1. Public interface

```python
# libs/argus_intelligence/browser/contract.py
class BrowserManager(Protocol):
    async def start(self) -> None: ...
    async def acquire(
        self,
        *,
        tenant_id: UUID,
        geo: str | None = None,
        fingerprint: str | None = None,
        purpose: str = "scrape",
        timeout_s: float = 30.0,
    ) -> "BrowserLease": ...
    async def status(self) -> "BrowserPoolStatus": ...
    async def shutdown(self) -> None: ...
```

`BrowserLease` is an async context manager:

```python
class BrowserLease(Protocol):
    async def __aenter__(self) -> "BrowserContextHandle": ...
    async def __aexit__(self, *exc) -> None: ...
```

`BrowserContextHandle`:

```python
class BrowserContextHandle(Protocol):
    async def new_page(self) -> Page: ...
    async def close(self) -> None: ...
    async def cookies(self) -> list[dict]: ...
    async def storage_state(self) -> dict: ...
    profile_id: str
    browser_id: str
```

## 2. Topology

```
BrowserManager (singleton per worker)
    │
    ├── Browser Pool  (N=ceil(mem_budget/512MB))
    │       │
    │       ├── Browser #1 (Chromium process)
    │       │       ├── Context #A (default ephemeral)
    │       │       ├── Context #B (default ephemeral)
    │       │       ├── Context #C (persistent, tenant-X)
    │       │       └── Context #D (quarantined, leak-suspect)
    │       │
    │       └── Browser #2 …
    │
    ├── HealthMonitor (background task)
    │       ├── pulse-checks each context every 30s
    │       ├── RSS sampler every 10s
    │       └── crash logger
    │
    └── Scheduler (decides acquire/release)
```

`Browser` here means a Chromium process. `Context` means a
BrowserContext (an isolated profile-like state). A single Browser
process typically hosts 4-8 Contexts.

## 3. Lifecycle — Browser process

```
                 ┌─────────────┐
                 │  requested  │
                 └──────┬──────┘
                        │
                 ┌──────▼──────┐
                 │  launching  │   Playwright.launch()
                 └──────┬──────┘
                        │
                 ┌──────▼──────┐
                 │  ready      │   first context available
                 └──────┬──────┘
                        │
                 ┌──────▼──────┐
                 │  active     │◄──────┐
                 └──────┬──────┘       │
                        │              │
                 ┌──────▼──────┐       │
                 │  draining   │       │ recycle
                 └──────┬──────┘       │
                        │              │
                 ┌──────▼──────┐       │
                 │  recycled   │───────┘
                 └──────┬──────┘
                        │  (after max_lifetime_s or crash)
                 ┌──────▼──────┐
                 │  dead       │
                 └─────────────┘
```

Transitions:

- `requested → launching`: pool scheduler decided to scale up.
- `launching → ready`: Playwright reports `connected`.
- `ready → active`: first `acquire()`.
- `active → draining`: signal sent; no new contexts handed out.
- `draining → recycled`: all contexts returned; new Browser
  process spawned if needed.
- `recycled → active`: reused on next acquire.
- `active → dead`: process crashed or memory limit hit.
- `ready/active → dead`: also on launch failure.

`max_lifetime_s` defaults to 1800 (30 min) to bound memory growth.

## 4. Lifecycle — Context

```
   acquire → create → bound → in_use → released → evicted
                              ↑           │
                              └───────────┘  (re-acquired)
```

- `create`: `browser.new_context(**overrides)` with fingerprint
  profile applied via CDP.
- `bound`: assigned to a tenant_id for the duration.
- `in_use`: at least one Page open.
- `released`: all Pages closed, no in-flight tasks.
- `evicted`: TTL expired, fingerprint stale, or memory high.

Default context TTL: 600s idle, then evicted.

## 5. Pool sizing and scaling

### 5.1 Sizing formula

```
target_mem_mb = settings.worker_browser_mem_mb   # default 2048
mb_per_browser = 512
mb_per_context = 80
max_browsers = floor(target_mem_mb / mb_per_browser)
max_contexts_per_browser = floor(mb_per_browser / mb_per_context) - 1  # reserve
```

Default (2 GB budget): `max_browsers=4`, `max_contexts=5` → 20 total.

### 5.2 Scaling rules

| Trigger | Action |
|---------|--------|
| `queue_wait_time_p95 > 5s` for 60s | scale up by 1 browser (if budget) |
| `idle_browsers > 2` for 5 min | scale down by 1 browser |
| Total RSS > 80% of `worker_browser_mem_mb` | refuse new contexts |
| Browser crash count > 3 in 60s | restart pool |

Scaling is **vertical only** in V1 (one worker, more browsers). V2
adds horizontal scaling (more worker processes).

### 5.3 Acquire fairness

Acquires are FIFO with two priority lanes:

- `priority=high`: paid tier, manual investigations.
- `priority=normal`: everything else.

A high-priority acquire preempts a low-priority context only if
explicitly requested via `acquire(preempt=True)`. Default is no
preemption.

## 6. Persistent profiles

Some investigations require a logged-in session. We support
**persistent profiles**:

```python
@dataclass(slots=True)
class PersistentProfile:
    profile_id: str
    tenant_id: UUID
    domain: str
    storage_state: dict          # cookies + localStorage
    created_at: datetime
    last_used_at: datetime
    use_count: int
    max_uses: int = 100
    expires_at: datetime
```

Profiles are stored under
`argus:browser:profile:{tenant}:{domain}:{profile_id}` in Redis.

When a plugin requests `use_profile=profile_id`, the manager:

1. Decrypts `storage_state` using Fernet (key from env).
2. Creates a Context with `storage_state=…`.
3. Sets fingerprint overrides.
4. Increments `use_count`.
5. On `use_count > max_uses` → rotates the profile (logout flow
   simulated).

User consent is required to create persistent profiles. Consent is
logged in `audit.event`.

## 7. Ephemeral contexts (default)

The vast majority of fetches need no state. Default Context is:

- No cookies pre-loaded.
- Random fingerprint (per 22).
- Random proxy (per 21).
- Random viewport.
- Closed and discarded after the request.

This is the "clean slate" mode and is the only mode we expose to
third-party plugins.

## 8. Health monitoring

### 8.1 Pulse checks

Every 30s, the HealthMonitor picks 1 random Context per Browser and:

1. Opens `about:blank`.
2. Runs `await page.evaluate("1+1")`.
3. Verifies it returns `2`.
4. Measures round-trip latency.
5. Closes.

Failed pulse → mark Context `unhealthy`. Browser with > 50%
unhealthy contexts → mark Browser `degraded`. Acquire() avoids
unhealthy contexts.

### 8.2 Memory watchdog

A background asyncio task samples RSS via `/proc/{pid}/status`
every 10s. If RSS > 80% of `mb_per_browser`, browser is marked
`oom_risk`. Acquire() refuses it. If RSS > 95%, browser is killed.

### 8.3 Crash detection

Playwright emits `Browser.disconnected` events. We register
listeners. On disconnect:

- All in-flight leases receive `BrowserClosedError`.
- Browser marked `crashed`.
- Pool decides: replace (if `crash_count` low) or restart pool.

### 8.4 Zombie contexts

If a Context has been `in_use` but no Page activity for 60s, it is
forcibly closed (the page might be hung). The lease's task is
cancelled.

## 9. Failure modes and recovery

| Failure | Detection | Recovery |
|---------|-----------|----------|
| Launch fails (missing binary) | `playwright._impl._api_types.Error` | log; mark pool `unavailable`; refuse acquires |
| Launch OOM | process exits before connect | retry once with `--disable-dev-shm-usage` |
| Browser crash mid-task | `Browser.disconnected` | leases get `BrowserClosedError`; pool replaces |
| Context hang (page stuck) | 60s idle | close context; fail lease with `ContextTimeout` |
| Memory leak (RSS climbing) | watchdog | drain browser, replace |
| Page hangs on `wait_for_selector` | Playwright timeout | fail lease with `SelectorTimeout` |
| CDP error | Playwright raises | retry once; if persistent, recycle context |
| Disk full (Playwright user-data-dir) | ENOSPC | rotate user-data-dir |

## 10. Configuration

```bash
# .env additions
ARGUS_BROWSER_ENABLED=1
ARGUS_BROWSER_MAX_BROWSERS=4
ARGUS_BROWSER_MAX_CONTEXTS_PER_BROWSER=5
ARGUS_BROWSER_LAUNCH_TIMEOUT_S=30
ARGUS_BROWSER_MAX_LIFETIME_S=1800
ARGUS_BROWSER_CONTEXT_TTL_S=600
ARGUS_BROWSER_HEALTH_PULSE_INTERVAL_S=30
ARGUS_BROWSER_MEMORY_WATCHDOG_INTERVAL_S=10
ARGUS_BROWSER_DISABLE_DEV_SHM=1
ARGUS_BROWSER_PROXY_INJECT=1   # route through 21-PROXY-MANAGER
ARGUS_BROWSER_HEADLESS=1
```

Chromium flags we set by default:

```
--no-sandbox --disable-dev-shm-usage --disable-gpu
--disable-background-networking --disable-default-apps
--disable-extensions --no-first-run --no-default-browser-check
--disable-features=Translate,BackForwardCache,AcceptCHFrame
--disable-blink-features=AutomationControlled
```

The last flag is critical for evading `navigator.webdriver`
detection; see 22-ANTI-BOT.

## 11. Free-tier compatibility

- Free-tier workers run with `ARGUS_BROWSER_ENABLED=0`. Engine
  returns `BrowserDisabled` and falls back to HTTP mode (with
  caveat documented in plugin manifest).
- Local Termux dev also disables browser mode by default
  (`ARGUS_BROWSER_ENABLED=0` in `.env.example`).
- Browser mode requires ≥ 1 GB RAM per worker process.

## 12. Security

- Each Context is bound to one tenant. We do NOT allow sharing.
- Persistent profile `storage_state` is encrypted with Fernet
  (key from env). Plaintext never on disk.
- Persistent profiles require explicit user consent (recorded in
  audit).
- Browser cannot access host filesystem outside
  `argus:browser:user_data_dir` (default `/tmp/argus-browsers`).
- All Playwright `evaluate()` scripts must come from engine
  internal code; plugin-supplied JS is rejected.

## 13. Abuse prevention

- Browser fetches count toward the tenant's `scrape` quota (31).
- Persistent profiles are limited to 100 per tenant.
- Domain blocklist (manual + auto from 22 risk) applies.
- Browser launch is rate-limited (1 launch / 5s) to prevent
  resource exhaustion by misbehaving tenants.

## 14. Scalability — 1000 concurrent investigations

- 1 worker handles ~8 concurrent browser scrapes (1 per context).
- For 1000 concurrent investigations × 20% browser path = 200
  browser scrapes in flight = 25 worker processes × 8 each.
- On free-tier PaaS, this requires horizontal scaling — see
  [13-DEPLOYMENT.md](13-DEPLOYMENT.md).
- Browser pool memory: 25 × 4 × 512 MB = 50 GB. Realistic only on
  multi-VM deploys. V2 with profile sharing and smarter context
  reuse.

## 15. Lifecycle — full sequence (acquire → release)

```
Worker task              BrowserManager       Browser        Context          Page
    │                        │                  │              │              │
    │ acquire()              │                  │              │              │
    ├───────────────────────►│                  │              │              │
    │                        │ find healthy     │              │              │
    │                        ├─────────────────►│              │              │
    │                        │ new_context()    │              │              │
    │                        ├─────────────────────────────────►│              │
    │                        │ apply fingerprint│              │              │
    │                        │ via CDP          │              │              │
    │                        ├─────────────────────────────────►│              │
    │                        │ return handle    │              │              │
    │ ◄──────────────────────┤                  │              │              │
    │ lease.__aenter__() returns handle         │              │              │
    │ new_page()            │                  │              │              │
    ├──────────────────────────────────────────────────────────►│              │
    │ page.goto(url)        │                  │              │              │
    ├────────────────────────────────────────────────────────────────────────►│
    │ page.content()        │                  │              │              │
    ├────────────────────────────────────────────────────────────────────────►│
    │ page.screenshot()     │                  │              │              │
    ├────────────────────────────────────────────────────────────────────────►│
    │ handle.close()        │                  │              │              │
    ├──────────────────────────────────────────────────────────►│              │
    │ lease.__aexit__()     │                  │              │              │
    │                        │ mark context idle│              │              │
    │                        ├─────────────────────────────────►│              │
    │                        │ schedule eviction│              │              │
    │                        │ if ttl expired   │              │              │
    │ ◄──────────────────────┤                  │              │              │
```

## 16. Trade-offs and rationale

| Decision | Rationale | Trade-off |
|----------|-----------|-----------|
| One Browser process per ~5 Contexts | Memory sweet spot | Less isolation than 1:1 |
| Health pulse every 30s | Detect stuck Contexts | Small CPU overhead |
| Persistent profiles in Redis | Easy sharing across worker | Encryption cost |
| No browser fallback in HTTP path | Predictability | Some sites unreachable on free tier |
| Recycle Browser every 30 min | Bound memory growth | Loss of any cross-context warm cache |

## 17. References

- [19-SCRAPING-ENGINE.md](19-SCRAPING-ENGINE.md) — Primary consumer
- [22-ANTI-BOT.md](22-ANTI-BOT.md) — Fingerprint application
- [21-PROXY-MANAGER.md](21-PROXY-MANAGER.md) — Proxy injection
- [06-WORKERS.md](06-WORKERS.md) — Worker process model
- [32-OBSERVABILITY.md](32-OBSERVABILITY.md) — Metrics
