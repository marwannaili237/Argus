# 33 — Plugin Runtime

> The execution engine that runs plugins in worker subprocesses.
> Extends and concretizes the developer-facing [07-PLUGIN-SDK.md](07-PLUGIN-SDK.md)
> with the operator/runtime perspective. Worker-only.

---

## 0. Position in the architecture

```
   Worker (services/worker)                    Plugin Runtime (33)
       │                                              │
       │ plugin_runner task                          │
       ├────────────────────►   PluginHost            │
                                 │                    │
                                 ▼                    │
                          SubprocessManager ────►  spawn(plugin)
                                 │                    │
                                 ▼                    │
                       ┌──────────────────┐           │
                       │ Plugin Subprocess│ ◄─────────┘
                       │  - python entry  │
                       │  - argus_plugin_sdk (07)
                       │  - emits JSON over stdout
                       │  - reads stdin for input
                       └──────────────────┘
```

The runtime lives in `libs/argus_intelligence/runtime/` and is
imported only by `services/worker/`. It is **not** part of the SDK
that plugins themselves import.

## 1. Goals and non-goals

**Goals**

- Hard isolation: a misbehaving plugin cannot crash the worker.
- Deterministic resource consumption: CPU, RAM, time bounded.
- Capability-based security: plugins only access declared
  capabilities.
- Versioned, atomic upgrades: in-flight runs finish on old
  version; new runs use new version.
- Auditability: every plugin invocation is logged and metered.
- Compatibility: the same SDK that third-party authors use
  ([07](07-PLUGIN-SDK.md)) works inside the runtime without
  modification.

**Non-goals**

- Reimplementing Python imports or sandboxing at the language
  level — we delegate to subprocess + rlimit + RestrictedPython.
- Supporting non-Python plugins in V1.
- Multi-language plugin signing (V2).

## 2. Public interface

```python
class PluginHost(Protocol):
    async def install(self, manifest: PluginManifest, blob: bytes) -> PluginRef: ...
    async def uninstall(self, plugin_name: str, version: str) -> None: ...
    async def upgrade(self, plugin_name: str, new_version: str, blob: bytes) -> UpgradeReport: ...
    async def rollback(self, plugin_name: str, to_version: str) -> RollbackReport: ...
    async def run(self, request: PluginRunRequest) -> PluginRunResult: ...
    async def status(self, plugin_name: str) -> PluginHealth: ...
```

### 2.1 `PluginRunRequest`

```python
@dataclass(slots=True, frozen=True)
class PluginRunRequest:
    plugin_name: str
    plugin_version: str
    investigation_id: UUID
    plugin_run_id: UUID
    tenant_id: UUID
    inputs: dict[str, Any]                # JSON-serializable
    capabilities: tuple[str, ...]          # subset of manifest caps
    timeout_s: float
    memory_mb: int
    cpu_seconds: float
    secrets: tuple[str, ...]              # refs into secrets manager
    proxy_profile: str | None
    fingerprint_profile: str | None
    cost_budget_credits: int
```

### 2.2 `PluginRunResult`

```python
@dataclass(slots=True)
class PluginRunResult:
    plugin_run_id: UUID
    success: bool
    exit_code: int
    duration_s: float
    memory_peak_mb: int
    cpu_seconds_used: float
    bytes_read: int
    bytes_written: int
    evidence_count: int
    log_records: tuple[LogRecord, ...]
    artifacts: tuple[ArtifactRef, ...]
    error: str | None
    error_class: str | None
    metrics: dict[str, float]
```

### 2.3 Versioning

The runtime exposes `RUNTIME_VERSION = "1.0"`. Plugins declare
their `runtime_compat` in the manifest. Mismatch is fatal.

```python
@dataclass(slots=True, frozen=True)
class PluginManifest:                    # extends 07-PLUGIN-SDK §2
    name: str
    version: str
    runtime_compat: tuple[str, ...]      # ["^1.0",]
    entrypoint: str
    capabilities: tuple[str, ...]
    # ... rest as in 07
```

## 3. Lifecycle — Plugin

```
   registered (in DB) ──► downloaded ──► verified ──► installed
                                                              │
                                                              ▼
                                                  active (running)
                                                              │
                                                              ├──► upgraded (atomic swap)
                                                              │       │
                                                              │       └──► previous version = deprecated
                                                              ├──► deprecated (90 days notice)
                                                              └──► retired (DB only, code on disk)
```

## 4. Lifecycle — Plugin Run

```
   requested ──► dispatched ──► launched ──► running ──► collecting
        │             │            │           │            │
        │             │            │           │            └──► writing
        │             │            │           └──► completing
        │             │            └──► failed (crash)
        │             └──► rejected (capability)
        └──► rejected (cost/budget)
```

## 5. Process isolation

### 5.1 Process model

Each `plugin.run` spawns a fresh subprocess (Python interpreter
with plugin entry point). We do **not** share a long-lived process
across runs because:

- Memory leak containment.
- Clean capability reset per run.
- Crash isolation.
- Reproducibility.

Trade-off: cold start 200-500 ms. Mitigation: warm pool (see §13).

### 5.2 POSIX rlimits

```python
def apply_rlimits(cpu_s: int, mem_mb: int, fsize_mb: int, nofile: int):
    resource.setrlimit(resource.RLIMIT_CPU, (cpu_s, cpu_s))
    resource.setrlimit(resource.RLIMIT_AS, (mem_mb * 1024 * 1024,
                                             mem_mb * 1024 * 1024))
    resource.setrlimit(resource.RLIMIT_FSIZE, (fsize_mb * 1024 * 1024,
                                                fsize_mb * 1024 * 1024))
    resource.setrlimit(resource.RLIMIT_NOFILE, (nofile, nofile))
    resource.setrlimit(resource.RLIMIT_NPROC, (4, 4))    # no fork bombs
    os.setsid()                                            # own pgid
```

### 5.3 Network namespace

On Linux hosts we use `unshare(CLONE_NEWNET)` to give the plugin a
private network namespace. Allowed destinations are configured
via the manifest's `[plugin.capabilities.http]` allowlist; we use
nftables to enforce egress.

```bash
# Generated per plugin run
nft add rule inet argus_plugins_out meta skuid $PLUGIN_UID \
    tcp dport { 80, 443 } ip daddr { $ALLOWLIST } accept
nft add rule inet argus_plugins_out meta skuid $PLUGIN_UID drop
```

### 5.4 Capability enforcement

Plugin code imports `argus_plugin_sdk.http`, `.dns`, etc. The
SDK facade checks the runtime-provided `CapabilityContext`:

```python
# plugins/_sdk/src/argus_plugin_sdk/http.py
class HttpClient:
    def get(self, url, **kw):
        ctx = get_current_context()
        if not ctx.capabilities.http:
            raise PermissionDenied("http")
        if not ctx.capabilities.http_allows(url):
            raise PermissionDenied(f"http not allowed for {url}")
        # ... real request via injected transport
```

`ctx` is injected by the runtime via a small RPC layer (not
importable from outside).

### 5.5 RestrictedPython for plugin code

We wrap plugin code with `RestrictedPython` for an extra layer of
protection against obvious mistakes:

```python
from RestrictedPython import compile_restricted
bytecode = compile_restricted(plugin_source, filename, "exec")
```

This blocks direct `import os`, `subprocess`, `socket`, etc. The
plugin must use SDK facades. Bypass detection: we audit imports
at install time.

## 6. IPC protocol

### 6.1 Wire format

Length-prefixed JSON lines over stdio.

```
[HEADER LINE: {"type":"init","ctx":{...}}]
[REQUEST LINE: {"type":"request","payload":{...}}]
[EVIDENCE LINES: {"type":"evidence","payload":{...}}]
[LOG LINES: {"type":"log","payload":{...}}]
[FOOTER LINE: {"type":"result","exit_code":0,"metrics":{...}}]
```

Length prefix: 4-byte big-endian, then UTF-8 JSON, then newline.
This avoids issues with embedded newlines in JSON.

### 6.2 Why stdio, not HTTP

- No port conflicts.
- No DNS overhead.
- Subprocess ownership is clear.
- Trivial to debug with `tee`.

### 6.3 Limits

- Max line size: 1 MB (configurable per plugin).
- Max total stream: 100 MB (then we abort the run).
- Backpressure: if plugin writes faster than runtime reads, we
  SIGSTOP the plugin (POSIX). We never block the runtime.

### 6.4 Sequence

```
   Runtime (parent)            Plugin (child)
        │                            │
        │ spawn + send header        │
        ├───────────────────────────►│
        │                            │ init()
        │ send request               │
        ├───────────────────────────►│
        │                            │ run()
        │ receive evidence           │
        │ ◄───────────────────────────┤
        │ receive evidence           │
        │ ◄───────────────────────────┤
        │ receive log                │
        │ ◄───────────────────────────┤
        │ receive result             │
        │ ◄───────────────────────────┤
        │ wait()                     │
        │ collect exit code          │
        │                            │
```

## 7. Resource quotas

| Resource | Default | Override | Enforcement |
|----------|---------|----------|-------------|
| CPU seconds | 60 | `request.cpu_seconds` | RLIMIT_CPU |
| Memory | 256 MB | `request.memory_mb` | RLIMIT_AS + watchdog |
| Wall time | 120 s | `request.timeout_s` | SIGTERM at soft, SIGKILL at hard |
| File size per write | 100 MB | manifest | RLIMIT_FSIZE |
| Open files | 256 | none | RLIMIT_NOFILE |
| Processes | 4 | none | RLIMIT_NPROC |
| Network connections | 50 | manifest | netfilter |
| Output lines | 10,000 | none | counted in runtime |
| Evidence count | 1,000 | per-plugin manifest | counted in runtime |

If a quota is exceeded:

- CPU: SIGKILL.
- Memory: SIGKILL (OOM).
- Wall time: SIGTERM (graceful), then SIGKILL after 5 s.
- Lines: SIGTERM.
- Evidence count: SIGTERM with `ResultTooLarge` exit.

## 8. Secrets management

Plugins **never** receive raw env vars. The runtime injects only
the secrets the manifest declares:

```toml
[plugin.secrets]
required = ["shodan_api_key", "hunter_api_key"]
optional = ["virustotal_api_key"]
```

At run time:

```python
ctx.secrets.get("shodan_api_key")  # returns value, audit-logged
```

Secrets are stored in the secrets manager (env / Vault V2). The
runtime never persists them to disk or logs them.

### 8.1 Secret rotation

When a secret rotates:

- Plugin manifest is unchanged.
- Runtime fetches fresh value per run.
- Old values invalidated after TTL.

### 8.2 Audit

Every secret access writes to `audit.event` with
`action="plugin.secret_access"`.

## 9. Permission model

Permissions are declared in the manifest and enforced by the
runtime + SDK.

| Capability | SDK facade | Network requirement |
|------------|-----------|---------------------|
| `http` | `argus_plugin_sdk.http.get/post/...` | Allowlist URLs |
| `dns` | `argus_plugin_sdk.dns.resolve` | Allowlist resolvers |
| `browser` | `argus_plugin_sdk.browser.new_page` | Via 20-BROWSER-MANAGER |
| `storage` | `argus_plugin_sdk.storage.{read,write}` | none |
| `geo` | `argus_plugin_sdk.geo.lookup` | none |
| `ai` | `argus_plugin_sdk.ai.summarize` | none (uses internal model) |
| `email_send` | `argus_plugin_sdk.email.send` | forbidden by default |

Plugin runs receive a `CapabilityContext` containing the subset
of capabilities actually granted (e.g. user paid for shodan but
not virustotal).

```python
@dataclass(slots=True, frozen=True)
class CapabilityContext:
    http: bool
    http_allowlist: tuple[str, ...]      # host patterns
    dns: bool
    dns_resolvers: tuple[str, ...]
    browser: bool
    storage: bool
    geo: bool
    ai: bool
    email_send: bool
    granted_secrets: tuple[str, ...]
```

## 10. Health monitoring

### 10.1 Per-run metrics

Every run emits:

```
argus_plugin_run_duration_seconds{plugin,version,result}   histogram
argus_plugin_run_memory_peak_mb{plugin,version}            gauge
argus_plugin_run_cpu_seconds{plugin,version}               gauge
argus_plugin_run_evidence_count{plugin,version}            histogram
argus_plugin_run_quota_exceeded_total{plugin,quota}        counter
argus_plugin_run_error_total{plugin,class}                 counter
```

### 10.2 Heartbeat

For long-running plugins (crawlers), the runtime expects a
heartbeat line every 5 s:

```json
{"type":"heartbeat","ts":"2026-06-27T10:00:00Z"}
```

Missed heartbeat → SIGTERM after 10 s.

### 10.3 Status endpoint

```
GET /v1/admin/plugins/{name}/health
```

Returns:

```json
{
  "plugin": "whois",
  "latest_version": "1.2.0",
  "active_versions": ["1.2.0"],
  "recent_runs": 245,
  "success_rate": 0.97,
  "p95_duration_s": 1.8,
  "last_failure_at": "2026-06-27T09:00:00Z",
  "status": "healthy"
}
```

## 11. Crash recovery

### 11.1 Crash detection

A subprocess crash is detected by:

- Non-zero exit without a `result` line.
- Process disappeared before sending result.
- Wall-time exceeded.

### 11.2 Recovery

The runtime translates crashes into one of:

| Crash kind | Runtime action | Plugin outcome |
|------------|----------------|----------------|
| Memory exceeded | SIGKILL | `PluginOOM` (no retry) |
| CPU exceeded | SIGKILL | `PluginTimeout` (retry once) |
| Wall-time exceeded | SIGTERM → SIGKILL | `PluginTimeout` (retry once) |
| Segfault | collect status | `PluginCrash` (no retry) |
| Exit code 1 | collect result | `PluginInputError` (no retry) |
| Exit code 2 | collect result | `PluginTransientError` (retry 3x) |
| Exit code 3 | collect result | `PluginPermanentError` (no retry) |

Exit codes 4-99: treated as `PluginPermanentError` (no retry).

### 11.3 Worker process crash

If the worker itself crashes mid-run:

- The plugin subprocess gets SIGKILL (pgid cleanup).
- `plugin_run` row is marked `pending_recovery`.
- On worker restart, Celery's `acks_late=True` re-queues the task.
- Plugin run re-executes from scratch (no checkpoint in V1).

### 11.4 Restart cap

If the same plugin crashes ≥ 3 times in 60 s, the runtime marks
the plugin `quarantined` and refuses new runs for 5 minutes.
Alert sent to ops (32-OBSERVABILITY §6).

## 12. Version compatibility

### 12.1 Compatibility matrix

```
Runtime  Plugin runtime_compat
1.0      ^1.0, ~1.0, 1.0.x
1.1      ^1.0, ^1.1, ~1.0
```

We use npm-style semver ranges:

- `^1.0` → `>=1.0.0, <2.0.0`
- `~1.0` → `>=1.0.0, <1.1.0`
- `1.0.x` → `>=1.0.0, <1.1.0`

### 12.2 Negotiation

At install time, we resolve `runtime_compat` against the running
runtime. At run time, we re-check (in case runtime was upgraded
while plugin was inactive).

### 12.3 Engine contract

The plugin runtime version is exposed at
`argus_plugin_runtime.__version__`. Plugins can import this for
diagnostics.

### 12.4 Breaking changes

Bumping the runtime major version requires:

- Deprecation notice (90 days).
- Dual-run period (both runtimes active).
- Migration path documented.

## 13. Plugin upgrades and rollback

### 13.1 Upgrade flow

```
admin: upload plugin.whois v1.3.0 (signed)
   │
   ▼
runtime.install("whois", "1.3.0", blob)
   │
   ├── verify signature
   ├── verify runtime_compat
   ├── extract to /var/lib/argus/plugins/whois/1.3.0/
   ├── record in plugin.installation (with version=1.3.0)
   └── emit event: plugin.installed
```

### 13.2 Atomic swap

When `plugin.latest_version` changes:

- New investigations get `version=latest`.
- In-flight investigations finish on their original version.
- Old version remains on disk for 90 days ("grace period").

### 13.3 Rollback

If a new version misbehaves:

```bash
curl -X POST /v1/admin/plugins/{name}/rollback \
    -d '{"to_version": "1.2.0"}'
```

The runtime:

1. Marks `1.3.0` as `disabled` (new runs blocked).
2. Marks `1.2.0` as `latest` again.
3. Records in `plugin.upgrade_audit`.

In-flight runs on 1.3.0 are **not** interrupted. New runs use
1.2.0.

### 13.4 Dual-version period

For 90 days after upgrade, both versions can be installed
simultaneously. Useful for A/B testing (30-FEATURE-FLAGS §11).

## 14. Data model — additions to 03

```sql
CREATE TABLE plugin.runtime_health (
    plugin_name        TEXT PRIMARY KEY,
    last_heartbeat_at  TIMESTAMPTZ,
    last_success_at    TIMESTAMPTZ,
    last_failure_at    TIMESTAMPTZ,
    consecutive_failures INT NOT NULL DEFAULT 0,
    quarantined_until  TIMESTAMPTZ,
    last_status        TEXT
);

CREATE TABLE plugin.execution_log (
    id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    plugin_run_id      UUID NOT NULL REFERENCES investigation.plugin_run(id) ON DELETE CASCADE,
    line_seq           INT NOT NULL,
    line_type          TEXT NOT NULL,         -- 'evidence','log','heartbeat','result'
    payload            JSONB NOT NULL,
    received_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX execution_log_run_idx
    ON plugin.execution_log (plugin_run_id, line_seq);

CREATE TABLE plugin.upgrade_audit (
    id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    plugin_name        TEXT NOT NULL,
    from_version       TEXT,
    to_version         TEXT NOT NULL,
    action             TEXT NOT NULL,         -- 'install','upgrade','rollback','uninstall'
    actor_id           UUID,
    reason             TEXT,
    created_at         TIMESTAMPTZ NOT NULL DEFAULT now()
);
```

## 15. State diagrams

### 15.1 Plugin version lifecycle

```
   registered ──► installed ──► active ──► deprecated ──► retired
                     │            │           │
                     │            └─► quarantined (3 crashes)
                     │                │
                     │                └─► active (after 5 min)
                     └──► rolled-back (1-step)
```

### 15.2 Subprocess lifecycle

```
   fork ──► preexec(rlimits) ──► execve(plugin) ──► init() ──► run()
                                                                      │
                                                              ┌───────┴───────┐
                                                              │               │
                                                       success             failure
                                                              │               │
                                                       teardown         cleanup
                                                              │               │
                                                              └───► exit ─────┘
```

## 16. Sequence diagram — full run

```
   Worker task   PluginHost    SubprocManager   Plugin     Audit    Cost
       │              │             │             │          │        │
       │ run(req)     │             │             │          │        │
       ├─────────────►│             │             │          │        │
       │              │ charge cost │             │          │        │
       │              ├───────────────────────────────────────────────────►
       │              │ cap check   │             │          │        │
       │              │ spawn       │             │          │        │
       │              ├────────────►│             │          │        │
       │              │             │ preexec     │          │        │
       │              │             │ execve      │          │        │
       │              │             ├────────────►│          │        │
       │              │             │             │ init()   │        │
       │              │             │             │ run()    │        │
       │              │             │             │ emit     │        │
       │              │             │             ├─────────►│        │
       │              │             │             │          │ log    │
       │              │             │             ├────────────────►
       │              │ receive     │             │          │        │
       │              │ ◄──────────┤             │          │        │
       │              │ wait()      │             │          │        │
       │              │             │ result      │          │        │
       │              │ ◄──────────┤ ◄───────────┤          │        │
       │              │ persist    │             │          │        │
       │              ├────────────►             │          │        │
       │              │ evidence   │             │          │        │
       │              ├────────────►             │          │        │
       │ result       │             │             │          │        │
       │ ◄────────────┤             │             │          │        │
```

## 17. Failure modes

| Failure | Detection | Recovery |
|---------|-----------|----------|
| Plugin subprocess won't start | `OSError: [Errno 2]` | retry with `--no-sandbox` once |
| Plugin OOM | rlimit kill | mark `PluginOOM`; do not retry |
| Plugin hangs | heartbeat missed | SIGTERM after 10s |
| Worker process OOM | kernel OOM killer | worker restart; Celery requeue |
| nftables rule load fails | exit code | fall back to allow-all with audit |
| Plugin writes to stderr | captured to log | no recovery; log; continue |
| Plugin produces invalid JSON | parser error | abort run with `PluginProtocolError` |
| Plugin ignores capability | SDK raises | terminate; audit; alert |
| Plugin requests undeclared secret | SDK raises | terminate; audit |
| Disk full on plugin install | OSError | retry with cleanup; alert |
| Signature verification fails | exception | reject install |

## 18. Security

- Plugin code never sees raw env. Only `ctx.secrets` filtered by
  manifest.
- Capability bypass attempt → terminate + audit + admin alert.
- Network egress is enforced via nftables. Plugin cannot bypass
  (root required to disable nftables).
- Process isolation via subprocess + rlimit + seccomp (V2) +
  namespace (V2).
- Memory ceiling prevents OOM kills of the worker.
- File system: plugin sees only `/var/lib/argus/plugins/<name>/<version>/`
  + its workdir.
- Symlink attacks: workdir is `O_NOFOLLOW` opened.
- Replay: plugin install blob is content-addressed by SHA256;
  duplicate install is no-op.

## 19. Abuse prevention

- Per-tenant plugin invocation rate limit (default 30/min,
  configurable).
- Per-plugin daily call cap (free tier: 30; pro: 500).
- Plugins cannot spawn subprocesses (`os.execve` blocked via
  rlimits).
- Plugins cannot access `/proc` or `/sys` (mount namespace).
- Cost cap per plugin run: default 5 credits, overridable.
- Repeated capability violations → plugin disabled globally.

## 20. Scalability

- Subprocess startup: 200 ms cold, 50 ms warm pool.
- Throughput: ~5 plugin runs/sec per worker slot.
- 1M investigations × 6 plugins avg = 6M runs/day = 70 runs/sec
  peak.
- Memory: 4 workers × 4 slots × 256 MB = 4 GB.
- On free-tier PaaS (1 GB): 1 worker × 1 slot × 256 MB.
- Plugin run logs: ~100 KB each × 6M = 600 GB/day. We sample
  (32-OBSERVABILITY §4) and only persist error logs.

## 21. Free-tier / Termux compatibility

- Free tier: warm pool size 1; cold start acceptable.
- Termux dev: subprocess works inside proot; rlimits are
  best-effort (some are no-ops). Documented in
  [14-TERMUX-WORKFLOW.md](14-TERMUX-WORKFLOW.md).
- nftables requires root on Linux. On PaaS we run as root in
  Docker. On Termux, we skip nftables and rely on SDK-side
  capability checks only. Documented as a known gap.

## 22. Configuration

```bash
ARGUS_PLUGIN_RUNTIME_VERSION=1.0
ARGUS_PLUGIN_POOL_WARM_SIZE=2
ARGUS_PLUGIN_POOL_MAX_SIZE=8
ARGUS_PLUGIN_DEFAULT_TIMEOUT_S=120
ARGUS_PLUGIN_DEFAULT_MEMORY_MB=256
ARGUS_PLUGIN_DEFAULT_CPU_S=60
ARGUS_PLUGIN_GRACE_DAYS=90
ARGUS_PLUGIN_QUARANTINE_COOLDOWN_S=300
ARGUS_PLUGIN_NETFILTER_ENABLED=1
ARGUS_PLUGIN_RLIMIT_ENABLED=1
ARGUS_PLUGIN_RESTRICTED_PYTHON=1
```

## 23. Trade-offs and rationale

| Decision | Rationale | Trade-off |
|----------|-----------|-----------|
| Subprocess per run | Isolation | Cold start cost |
| SDK facade for capabilities | Plugin author simplicity | More SDK code |
| nftables for egress | Strongest isolation | Requires root |
| Length-prefixed JSON over stdio | Simple | Larger wire size |
| Semver ranges | Familiar | Plugin author must learn |
| 90-day grace for old versions | Rollback safety | Disk cost |
| Heartbeat line | Detect hangs | Plugin must send |

## 24. References

- [07-PLUGIN-SDK.md](07-PLUGIN-SDK.md) — Developer-facing SDK
- [19-SCRAPING-ENGINE.md](19-SCRAPING-ENGINE.md) — Engine consumer
- [20-BROWSER-MANAGER.md](20-BROWSER-MANAGER.md) — Browser capability
- [21-PROXY-MANAGER.md](21-PROXY-MANAGER.md) — Proxy capability
- [22-ANTI-BOT.md](22-ANTI-BOT.md) — Fingerprint context
- [24-PLANNER.md](24-PLANNER.md) — Plan execution
- [31-COST-CONTROLLER.md](31-COST-CONTROLLER.md) — Cost charging
- [32-OBSERVABILITY.md](32-OBSERVABILITY.md) — Metrics
- [34-DATA-SOURCE-REGISTRY.md](34-DATA-SOURCE-REGISTRY.md) — Source metadata
- [35-WORKFLOW-ENGINE.md](35-WORKFLOW-ENGINE.md) — DAG execution
