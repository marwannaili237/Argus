# 21 — Proxy Manager

> Proxy abstraction, rotation, health scoring, geo selection,
> cooldowns, reputation, and cost-aware routing. Worker-only.

---

## 0. Why a dedicated proxy subsystem

Without centralized management:

- Each plugin rolls its own proxy list — duplicates cost.
- Failed proxies are reused indefinitely.
- High-cost residential proxies get used for cheap datacenter
  targets.
- Target sites see bursty patterns from a single exit IP.
- GDPR / compliance: we need a single point to enforce jurisdiction
  rules.

`ProxyManager` owns all proxy selection decisions.

## 1. Proxy types

| Type | Use case | Cost | Speed | Anonymity |
|------|----------|------|-------|-----------|
| `datacenter` | Bulk HTTP, low-block sites | $0–$1/GB | Fast | Low |
| `residential` | High-block sites | $3–$10/GB | Medium | High |
| `mobile` | Very high block (IG, TikTok) | $10–$25/GB | Slow | Highest |
| `isp` | Mid-cost, mid-anonymity | $2–$5/GB | Medium | High |
| `tor` | Free, no logs | $0 | Very slow | Medium (exit nodes blacklisted) |

## 2. Public interface

```python
class ProxyManager(Protocol):
    async def acquire(
        self,
        *,
        tenant_id: UUID,
        purpose: str = "scrape",
        domain: str | None = None,
        geo: str | None = None,
        sticky_session_id: str | None = None,
        cost_tier: Literal["low","medium","high"] | None = None,
    ) -> "ProxyLease": ...
    async def report(self, proxy_id: str, outcome: ProxyOutcome) -> None: ...
    async def status(self) -> "ProxyPoolStatus": ...
```

`ProxyLease`:

```python
@dataclass(slots=True)
class ProxyLease:
    proxy_id: str
    proxy_url: str                # never logged in plain
    proxy_type: str
    geo: str
    cost_per_gb_cents: int
    async def release(self) -> None: ...
```

## 3. Data model

```python
@dataclass(slots=True)
class Proxy:
    proxy_id: str                 # uuid
    proxy_type: str
    endpoint: str                 # host:port
    username: str | None
    password: str | None          # stored encrypted
    geo_country: str             # ISO 3166-1 alpha-2
    geo_city: str | None
    cost_per_gb_cents: int
    provider: str                 # "brightdata", "smartproxy", …
    tags: list[str]
    enabled: bool = True
    cooldown_until: datetime | None = None
    sticky_session_key: str | None = None
    created_at: datetime
    last_used_at: datetime | None = None

@dataclass(slots=True)
class ProxyHealth:
    proxy_id: str
    success_count: int
    failure_count: int
    bytes_sent: int
    bytes_received: int
    latency_p50_ms: int
    latency_p95_ms: int
    last_success: datetime | None
    last_failure: datetime | None
    consecutive_failures: int
    score: float                  # 0.0 to 1.0
```

Proxies are stored in Postgres (`proxy.proxy` and `proxy.health`),
credentials in Redis (`argus:proxy:credential:{proxy_id}`,
encrypted with Fernet).

## 4. Health score formula

```
score = w1 * success_rate
      + w2 * speed_score
      + w3 * freshness_score
      - w4 * cooldown_penalty
      - w5 * blacklist_penalty

where:
  success_rate      = success / max(1, success + failure)        [0,1]
  speed_score       = clamp(1 - (p95_ms / SLA_MS), 0, 1)        [0,1]
  freshness_score   = exp(-age_s / FRESH_TTL_S)                  [0,1]
  cooldown_penalty  = 1.0 if cooldown else 0
  blacklist_penalty = blacklist_count / 10
  weights           = w1=0.5, w2=0.2, w3=0.1, w4=0.15, w5=0.05
```

`SLA_MS = 3000` by default. `FRESH_TTL_S = 86400`.

Proxies with `score < 0.2` are quarantined. Score is recomputed on
every report.

## 5. Rotation strategy

Default: **weighted round-robin with cooldown**.

```python
def pick_proxy(candidates: list[Proxy]) -> Proxy:
    weights = [max(p.health.score, 0.01) for p in candidates]
    return random.choices(candidates, weights=weights, k=1)[0]
```

Special modes:

- **Sticky session**: if `sticky_session_id` is set, pick the same
  proxy for the same key (TTL 30 min). Used when target site ties
  sessions to IP.
- **Geo-pinned**: if `geo` is set, restrict to that country.
- **Cost-capped**: if `cost_tier="low"`, restrict to datacenter +
  tor.
- **Anti-detection (22)**: if risk score high, restrict to
  residential/mobile.

## 6. Cooldowns

When a proxy fails:

- 1 failure → 60s cooldown.
- 2 consecutive failures → 300s cooldown.
- 3 consecutive failures → 900s + quarantine flag.
- 5 consecutive failures → permanent removal (admin alert).

Cooldown is recorded on `Proxy.cooldown_until` and respected by the
acquire algorithm.

## 7. Reputation scoring

Beyond per-proxy health, we track:

- **Domain-specific reputation**: a proxy that gets 403s from
  `example.com` may be fine elsewhere. We track per
  `(proxy, domain)` pair.
- **Network reputation**: if our ASN or datacenter range is
  blacklisted by a target, switch to residential.
- **Historical reputation**: long-term success rate by provider.

These are aggregated nightly into `proxy.reputation` materialized
view.

## 8. Failure tracking

Each `ProxyOutcome` carries:

```python
@dataclass(slots=True)
class ProxyOutcome:
    proxy_id: str
    domain: str
    status_code: int | None
    latency_ms: int
    bytes_sent: int
    bytes_received: int
    error: str | None
    error_class: str | None
    timestamp: datetime
    tenant_id: UUID
```

Outcome is reported by the Scraping Engine via
`proxy_manager.report(proxy_id, outcome)` after every attempt
(success or fail). This is the primary input to scoring.

## 9. Sticky sessions

When a plugin needs to maintain a session on a target site:

1. Plugin sets `sticky_session_id = "scrape-{run_id}-{domain}"`.
2. `acquire()` checks `argus:sticky:{session_id}` in Redis.
3. If present and not expired (TTL 1800s), reuse the proxy.
4. Else, pick a proxy, store under `argus:sticky:{session_id}`.
5. On sticky session end, the proxy is released back to rotation
   (not quarantined).

This survives worker restarts because state lives in Redis.

## 10. Cost-aware routing

We model each request's "cost" as:

```
cost = base_cost
     + bytes_sent * egress_cost
     + bytes_received * ingress_cost
     + cost_per_request if provider charges per-request
```

For each request we ask: "what's the cheapest proxy that will
succeed here?". The decision tree:

```
if target.is_known_easy:
    → datacenter, score >= 0.5
elif target.is_known_hard:
    → residential, score >= 0.7
elif risk_score > 0.7:
    → residential or mobile, score >= 0.8
else:
    → score-weighted round-robin across all enabled proxies
```

`target.is_known_*` is in `proxy.target_difficulty` table, learned
from historical outcomes.

## 11. Free-tier optimization

For free-tier tenants (plan=free), the default `cost_tier` is
`low`. The ProxyManager:

- Prefers datacenter proxies.
- Caps monthly bytes per tenant (default 10 GB).
- Switches to residential only when 3 datacenter attempts fail.
- Switches to mobile never (cost-prohibitive).

This keeps free-tier investigation cost predictable.

## 12. Paid provider abstraction

Different providers have different APIs. We abstract with
`ProxyProvider`:

```python
class ProxyProvider(Protocol):
    name: str
    async def list_proxies(self) -> list[Proxy]: ...
    async def enable(self, proxy_id: str) -> None: ...
    async def disable(self, proxy_id: str) -> None: ...
    async def usage(self, since: datetime) -> "ProviderUsage": ...
```

Built-in providers: `brightdata`, `smartproxy`, `oxylabs`,
`webshare`, `tor` (self-hosted). New providers added as adapters
in `libs/argus_intelligence/proxy/providers/`.

Provider usage is reconciled nightly by a Celery beat task against
the provider's API to detect drift.

## 13. State diagram — Proxy lifecycle

```
   added ──► enabled ──► active ──► cooldown ──► active
                │           │           │
                │           │           └────► quarantine
                │           └────► disabled (admin)
                │
                └────► disabled (admin / permanent fail)
```

## 14. Failure modes

| Failure | Detection | Recovery |
|---------|-----------|----------|
| Provider API down | curl returns 5xx | retry with backoff; fall back to cached proxy list |
| Auth failure on proxy | 407 from upstream | mark proxy dead; rotate credentials; alert |
| Geo-mismatch (returned IP not in geo) | check `https://ipinfo.io/{ip}` | mark proxy mislabeled; disable |
| All proxies in geo exhausted | acquire returns empty | return `ProxyPoolEmpty(geo)`; caller decides |
| Redis down (sticky session state lost) | connection error | rebuild from in-memory cache; warn |
| Quota exceeded (paid provider) | 429 from provider API | mark all from that provider cooldown; alert |

## 15. Security

- Proxy credentials stored encrypted (Fernet) in Redis. Decrypted
  only at acquire time, held in memory for lease lifetime.
- We **do not** log proxy credentials. Audit logs record
  `proxy_id` only.
- Geo selection can be tenant-imposed (free tier EU users only use
  EU proxies for GDPR). Implemented as a per-tenant
  `proxy.geo_allowlist`.
- For abuse: rapid-fire from same proxy across many tenants is
  detected and proxy is shared-rate-limited.

## 16. Scalability

Per worker:

- 100 proxies in rotation → acquire() latency < 1 ms (Redis ZSET
  lookup).
- 10,000 proxies (datacenter-heavy) → still < 5 ms with
  pre-filtering.
- Score recomputation is O(proxies) and runs once per report;
  aggregated lazily into materialized view.

Across workers:

- Proxy pool is global (Postgres + Redis). All workers see the
  same scores.
- Lease tracking is local (in-memory) — workers don't coordinate
  on which proxy is in use. We rely on abundance.
- Sticky sessions are global via Redis.

## 17. Configuration

```bash
# .env additions
ARGUS_PROXY_ENABLED=1
ARGUS_PROXY_DEFAULT_COST_TIER=medium
ARGUS_PROXY_COOLDOWN_BASE_S=60
ARGUS_PROXY_COOLDOWN_MAX_S=900
ARGUS_PROXY_SCORE_QUARANTINE=0.2
ARGUS_PROXY_ROTATION=weighted_round_robin   # or round_robin, geo_first
ARGUS_PROXY_STICKY_TTL_S=1800
ARGUS_PROXY_TOR_ENABLED=0
ARGUS_PROXY_BRIGHTDATA_USER=
ARGUS_PROXY_BRIGHTDATA_PASS=
ARGUS_PROXY_SMARTPROXY_USER=
ARGUS_PROXY_SMARTPROXY_PASS=
```

## 18. Trade-offs and rationale

| Decision | Rationale | Trade-off |
|----------|-----------|-----------|
| Weighted round-robin | Simple, well-understood | Doesn't adapt to sudden shifts |
| Per-proxy health in Redis | Cheap reads | One more dependency |
| Domain-specific reputation | Avoids global quarantines | Higher storage |
| Free tier = datacenter only | Cost control | Less reliable for hard sites |
| No Tor by default | Speed, blacklist issues | Opt-in for high-anonymity needs |

## 19. References

- [19-SCRAPING-ENGINE.md](19-SCRAPING-ENGINE.md) — Primary consumer
- [22-ANTI-BOT.md](22-ANTI-BOT.md) — Risk-based proxy selection
- [31-COST-CONTROLLER.md](31-COST-CONTROLLER.md) — Cost caps
- [32-OBSERVABILITY.md](32-OBSERVABILITY.md) — Metrics
