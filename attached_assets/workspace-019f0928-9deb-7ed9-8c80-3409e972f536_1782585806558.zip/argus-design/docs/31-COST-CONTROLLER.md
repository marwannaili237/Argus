# 31 — Cost Controller

> Credit accounting, budget enforcement, cost estimation, resource
> quotas, execution cancellation, paid provider abstraction, and
> free-tier optimization. Pure domain logic + worker integration.

---

## 0. Why cost control is a subsystem

OSINT investigations have variable cost:

- DNS query: ~$0
- WHOIS: ~$0
- Residential proxy GB: ~$5
- Mobile proxy GB: ~$15
- Shodan query: $0.001 each
- Email verification: $0.01 each
- Browser context: ~$0.05 per fetch (memory + time)

Without budget enforcement, a single misconfigured tenant can drain
Argus's provider budget in hours.

## 1. Concepts

- **Credit**: Argus's internal unit. 1 credit ≈ $0.001 (configurable).
- **Plan**: free / pro / team, with monthly credit allowance.
- **Budget**: per-tenant monthly + per-investigation caps.
- **Cost**: predicted and actual credits per operation.
- **Resource quota**: concurrent runs, plugins, etc.

## 2. Pricing table

```python
COST_TABLE = {
    # ── Plugin step costs ────────────────────────────────────────
    "plugin_step": {
        "whois": 1,
        "dns": 1,
        "http_crawl": 3,
        "email_hunt": 5,
        "social_x": 4,
        "breach_search": 6,
        "public_records": 8,
        "shodan": 10,            # paid provider
        "censys": 10,            # paid provider
        "ip_geolocation": 2,
        "asn_lookup": 1,
        "certificate_transparency": 2,
    },
    # ── Resource costs (per request) ─────────────────────────────
    "http_request": 0.1,
    "browser_request": 5,
    "screenshot": 2,
    "html_snapshot": 1,
    # ── External provider (passed through) ──────────────────────
    "proxy_residential_gb": 500,    # $0.50 per GB
    "proxy_mobile_gb": 1500,        # $1.50 per GB
    "proxy_datacenter_gb": 50,      # $0.05 per GB
    "captcha_solve": 100,           # $0.10 per solve
    "shodan_query": 1,
    "censys_query": 1,
    "email_verify": 10,
    # ── Internal ────────────────────────────────────────────────
    "export_render": 2,
    "ai_summary": 20,                # V2 only
}
```

Costs are configurable per tenant (override in DB).

## 3. Public interface

```python
class CostController(Protocol):
    def estimate(self, plan: Plan, tenant_id: UUID) -> CostEstimate: ...
    def pre_check(self, plan: Plan, tenant_id: UUID) -> None: ...   # raises
    def charge(self, op: Operation, tenant_id: UUID) -> ChargeReceipt: ...
    def refund(self, op: Operation, tenant_id: UUID) -> None: ...
    def status(self, tenant_id: UUID) -> TenantCostStatus: ...
```

```python
@dataclass(slots=True)
class CostEstimate:
    total_credits: int
    breakdown: dict[str, int]
    provider_costs_cents: int
    duration_s: float
    risk_level: Literal["low","medium","high"]
```

```python
@dataclass(slots=True, frozen=True)
class TenantCostStatus:
    tenant_id: UUID
    plan: str
    credits_remaining: int
    monthly_allowance: int
    monthly_used: int
    monthly_period_end: datetime
    concurrent_running: int
    concurrent_limit: int
```

## 4. State diagram — credit balance

```
   ok ──charge──► deducting ──ok (remaining > 0)
                     │
                     └──► exhausted ──► blocked (until reset)
                                            │
                                            └──► topped_up (admin)
```

## 5. Pre-flight check

```python
def pre_check(self, plan: Plan, tenant_id: UUID) -> None:
    status = self.status(tenant_id)
    if status.credits_remaining < plan.total_cost_estimate:
        raise QuotaExceeded(
            "credits",
            remaining=status.credits_remaining,
            required=plan.total_cost_estimate,
        )
    if status.concurrent_running >= status.concurrent_limit:
        raise QuotaExceeded("concurrent_running",
            current=status.concurrent_running,
            limit=status.concurrent_limit)
    if any(p in plan.plugins for p in
           self.paid_plugins_outside_plan(tenant_id)):
        raise QuotaExceeded("paid_plugin",
            plugin=p, plan=plan.plan)
```

Pre-flight runs at API request time (synchronous) and at the start
of every Celery task (defensive).

## 6. Charge

```python
def charge(self, op: Operation, tenant_id: UUID) -> ChargeReceipt:
    cost = COST_TABLE[op.kind] + op.quantity * COST_TABLE.get(op.unit, 0)
    with session_scope() as s:
        counter = UsageCounterRepo(s).increment(
            tenant_id=tenant_id,
            metric=op.kind,
            count=cost,
        )
        if counter.remaining < 0:
            # concurrent charge detected overshoot
            counter.remaining = 0
            raise QuotaExceeded("credits", overshoot=True)
        AuditRepo.write("cost.charged", tenant_id=tenant_id,
                        operation=op, cost=cost)
        s.commit()
    return ChargeReceipt(op_id=op.id, cost=cost,
                          remaining=counter.remaining)
```

Charge is per-operation, idempotent on `(op.id, op.kind)`. We use
`SELECT ... FOR UPDATE` to serialize concurrent charges.

## 7. Refund

When a task fails partially, we refund the unused portion:

```python
def refund(self, op: Operation, tenant_id: UUID) -> None:
    counter = UsageCounterRepo(tenant_id).decrement(op.kind, op.cost)
    AuditRepo.write("cost.refunded", tenant_id=tenant_id, operation=op)
```

Refunds are bounded: a tenant cannot refund below zero (defense
against refund loops).

## 8. Cost estimation

```python
def estimate(self, plan: Plan, tenant_id: UUID) -> CostEstimate:
    breakdown = {}
    for step in plan.steps:
        if step.skip_reason: continue
        plugin_cost = COST_TABLE["plugin_step"].get(step.plugin.name, 5)
        breakdown[step.plugin.name] = plugin_cost
    # add proxy costs
    proxy_cost = 0
    for step in plan.steps:
        proxy_cost += estimate_proxy_cost(step)
    # add export cost (if export requested)
    if plan.options.include_export:
        breakdown["export"] = COST_TABLE["export_render"]
    total = sum(breakdown.values()) + proxy_cost
    return CostEstimate(
        total_credits=total,
        breakdown=breakdown,
        provider_costs_cents=int(proxy_cost * COST_PER_CREDIT_CENTS),
        duration_s=plan.estimated_duration_s,
        risk_level=self.risk_level(plan),
    )
```

## 9. Plan-based quotas

| Plan | Monthly credits | Concurrent runs | Daily exports | Paid plugins |
|------|------------------|------------------|---------------|--------------|
| free | 2,000 | 1 | 5 | none |
| trial | 5,000 | 3 | 20 | none |
| pro | 50,000 | 5 | 100 | shodan, censys |
| team | 250,000 | 20 | 500 | all |
| enterprise | unlimited (negotiated) | negotiated | negotiated | all |

Plans are configurable via `billing.plan` rows.

## 10. Resource quotas

Beyond credits:

- **Concurrent runs** per tenant (default 1 free, 5 pro).
- **Concurrent browser contexts** per tenant (default 1 free,
  4 pro).
- **Daily plugin calls** per kind (free: 30/day; pro: 500/day).
- **Daily exports** (free: 5; pro: 100).
- **Storage bytes** (free: 1 GB; pro: 50 GB).
- **Watchlists** (free: 3; pro: 50).
- **Alert recipients** (free: 1; pro: 10).

Each quota is enforced at the relevant subsystem (browser pool,
storage, scheduler).

## 11. Execution cancellation

When balance hits zero mid-investigation:

```python
@shared_task(name="argus.cost.check_budget")
def check_budget(investigation_id: str):
    inv = InvestigationRepo.get(investigation_id)
    if inv.status != "running": return
    status = cost_controller.status(inv.tenant_id)
    if status.credits_remaining < 10:  # safety margin
        InvestigationRepo.cancel(inv.id, reason="budget_exhausted")
        for task_id in get_active_tasks(inv.id):
            celery_app.control.revoke(task_id, terminate=True)
        event_bus.publish("investigation.cancelled",
                          {"id": str(inv.id), "reason":"budget_exhausted"})
```

This runs every 30 seconds on active investigations via Celery
beat.

## 12. Paid provider abstraction

```python
class PaidProvider(Protocol):
    name: str
    async def call(self, request: dict) -> dict: ...
    def cost(self, request: dict) -> int: ...
```

Implementations: `shodan`, `censys`, `hunter`, `clearbit`, etc.
Each registers itself with the cost controller on startup.

Free-tier tenants never reach paid providers — the Planner refuses
to include them in `Plan.steps` (see 24-PLANNER §7).

## 13. Free-tier optimization

- Default plugins are free (whois, dns, http_crawl, social_x).
- Free-tier tenants use datacenter proxies only (21-PROXY-MANAGER
  §11).
- Browser mode disabled by default.
- Persistent profiles disabled.
- Watchlists capped at 3.
- Exports capped at 5/day.

Free-tier cost cap: $5/tenant/month in provider spend. We stop
dispatching if projected monthly spend exceeds the cap.

## 14. Lifecycle — investigation budget

```
   planned (estimate) ──► pre_check ok ──► charging ──► complete
        │                       │              │            │
        │                       │              │            └──► refunded (fail)
        │                       └──► rejected (over budget)
        └──► rejected (cost > monthly limit)
```

## 15. Failure modes

| Failure | Detection | Recovery |
|---------|-----------|----------|
| Provider API returns cost > estimate | mismatch | alert; downgrade tenant plan |
| Counter increment races | FOR UPDATE serializes | retry |
| Refund below zero | guard | reject refund; log |
| Plan deleted mid-investigation | status check | cancel investigation |
| Stripe subscription past_due | webhook | downgrade to free |

## 16. State diagram — cost controller

```
   ready ──estimate──► ready (with estimate)
     │
     └──pre_check──► ok / rejected
                      │
                  ok
                      │
                  charge
                      │
                      ▼
                   ok / refused
                      │
                  refund (optional)
                      │
                      ▼
                   ready
```

## 17. Security

- Cost controller never accepts untrusted cost values from plugins.
- All charges write to audit log.
- Refunds are bounded; no infinite refund loops.
- Admin scope required to grant extra credits.

## 18. Scalability

- Counter increments are O(1) with proper indexing.
- Pre-check is O(1) Redis read.
- Charge is one row update + one audit insert per operation.
- 1M operations/day ≈ 30M charges/mo ≈ trivial.

## 19. Public interface versioning

```python
COST_SCHEMA_VERSION = "1.0"
```

Cost table is JSON-serializable; tenants see their effective
prices via `GET /v1/billing/quotes`.

## 20. Configuration

```bash
ARGUS_COST_FREE_MONTHLY_CREDITS=2000
ARGUS_COST_PRO_MONTHLY_CREDITS=50000
ARGUS_COST_TEAM_MONTHLY_CREDITS=250000
ARGUS_COST_PROVIDER_MONTHLY_CAP_CENTS=500
ARGUS_COST_BUDGET_CHECK_INTERVAL_S=30
ARGUS_COST_SAFETY_MARGIN_CREDITS=10
```

## 21. Trade-offs and rationale

| Decision | Rationale | Trade-off |
|----------|-----------|-----------|
| Credits as internal unit | Stable across price changes | Less transparent to users |
| Per-operation charging | Fine-grained control | More audit rows |
| Pre-flight + periodic check | Defense in depth | Slight overhead |
| Free tier = free plugins only | Avoid surprise costs | Limited capability |
| Refund on partial fail | Fairness | Refund code complexity |

## 22. References

- [24-PLANNER.md](24-PLANNER.md) — Plan + cost estimate
- [21-PROXY-MANAGER.md](21-PROXY-MANAGER.md) — Proxy costs
- [28-SCHEDULER.md](28-SCHEDULER.md) — Continuous cost accrual
- [10-QUEUE-DESIGN.md](10-QUEUE-DESIGN.md) — Quota token buckets
- [13-DEPLOYMENT.md](13-DEPLOYMENT.md) — Provider credentials
