# 03 — Database Schema

## 0. Conventions

- Engine: **PostgreSQL 16+**.
- Charset: `UTF8`, collation: `en_US.utf8` (we don't sort human text
  in DB).
- All tables: `id UUID PRIMARY KEY DEFAULT gen_random_uuid()`.
- All timestamps: `TIMESTAMPTZ NOT NULL DEFAULT now()`.
- All money: integer minor units (`BIGINT`).
- All soft-delete: `deleted_at TIMESTAMPTZ NULL`.
- All audit columns: `created_at`, `updated_at`, `created_by`,
  `updated_by` (except `audit.events` which is append-only).
- All FKs: `ON DELETE RESTRICT` by default; opt into `CASCADE` only
  with comment.
- Indexes: prefix with `(tenant_id, ...)` for tenant-scoped reads.
- Naming: snake_case tables, no pluralization (`user`, not `users`)
  because SQLAlchemy model name is the singular noun.

Schemas (Postgres schemas, not OAuth):

- `identity` — users, tenants, api_keys, sessions
- `investigation` — investigations, evidence, entities, relationships
- `plugin` — plugins, manifests, installations
- `billing` — plans, subscriptions, invoices, quotas
- `audit` — events, immutable

Schemas are owned by the application role; migrations create them.

## 1. Identity schema

```sql
CREATE SCHEMA identity;

CREATE TABLE identity.tenant (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    slug            CITEXT UNIQUE NOT NULL,
    name            TEXT NOT NULL,
    plan_id         UUID,                           -- FK -> billing.plan
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    deleted_at      TIMESTAMPTZ
);

CREATE TABLE identity."user" (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id       UUID NOT NULL REFERENCES identity.tenant(id) ON DELETE RESTRICT,
    telegram_id     BIGINT UNIQUE,                  -- nullable for non-Telegram
    email           CITEXT UNIQUE,
    username        CITEXT,
    full_name       TEXT,
    locale          TEXT NOT NULL DEFAULT 'en',
    role            TEXT NOT NULL DEFAULT 'member', -- member|admin|owner
    is_active       BOOLEAN NOT NULL DEFAULT TRUE,
    last_seen_at    TIMESTAMPTZ,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    deleted_at      TIMESTAMPTZ,
    CONSTRAINT user_role_chk CHECK (role IN ('member','admin','owner'))
);

CREATE INDEX user_tenant_idx ON identity."user" (tenant_id) WHERE deleted_at IS NULL;

CREATE TABLE identity.api_key (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id       UUID NOT NULL REFERENCES identity.tenant(id) ON DELETE RESTRICT,
    user_id         UUID NOT NULL REFERENCES identity."user"(id) ON DELETE CASCADE,
    name            TEXT NOT NULL,
    key_hash        BYTEA NOT NULL,                 -- argon2id
    key_prefix      TEXT NOT NULL,                  -- first 8 chars for display
    scopes          TEXT[] NOT NULL DEFAULT '{}',
    last_used_at    TIMESTAMPTZ,
    expires_at      TIMESTAMPTZ,
    revoked_at      TIMESTAMPTZ,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX api_key_lookup_idx ON identity.api_key (key_prefix) WHERE revoked_at IS NULL;

CREATE TABLE identity.session (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id         UUID NOT NULL REFERENCES identity."user"(id) ON DELETE CASCADE,
    refresh_jti     UUID UNIQUE NOT NULL,
    user_agent      TEXT,
    ip              INET,
    issued_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
    expires_at      TIMESTAMPTZ NOT NULL,
    revoked_at      TIMESTAMPTZ
);

CREATE TABLE identity.password_reset (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id         UUID NOT NULL REFERENCES identity."user"(id) ON DELETE CASCADE,
    token_hash      BYTEA NOT NULL,
    expires_at      TIMESTAMPTZ NOT NULL,
    used_at         TIMESTAMPTZ
);
```

## 2. Investigation schema

```sql
CREATE SCHEMA investigation;

CREATE TABLE investigation.investigation (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id       UUID NOT NULL REFERENCES identity.tenant(id),
    owner_id        UUID NOT NULL REFERENCES identity."user"(id),
    title           TEXT NOT NULL,
    target_kind     TEXT NOT NULL,                  -- domain|email|username|ip|person|company
    target_value    TEXT NOT NULL,                  -- canonical form
    target_meta     JSONB NOT NULL DEFAULT '{}',    -- extra hints
    status          TEXT NOT NULL DEFAULT 'pending',
    progress_pct    SMALLINT NOT NULL DEFAULT 0 CHECK (progress_pct BETWEEN 0 AND 100),
    current_step    TEXT,
    evidence_count  INTEGER NOT NULL DEFAULT 0,
    entity_count    INTEGER NOT NULL DEFAULT 0,
    relationship_count INTEGER NOT NULL DEFAULT 0,
    error_count     INTEGER NOT NULL DEFAULT 0,
    started_at      TIMESTAMPTZ,
    completed_at    TIMESTAMPTZ,
    paused_at       TIMESTAMPTZ,
    cancelled_at    TIMESTAMPTZ,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT investigation_status_chk CHECK (
        status IN ('pending','planned','running','paused','completed','failed','cancelled')
    )
);

CREATE INDEX investigation_tenant_status_idx
    ON investigation.investigation (tenant_id, status, created_at DESC);
CREATE INDEX investigation_owner_idx
    ON investigation.investigation (owner_id, created_at DESC);

CREATE TABLE investigation.plugin_run (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    investigation_id UUID NOT NULL REFERENCES investigation.investigation(id) ON DELETE CASCADE,
    plugin_name     TEXT NOT NULL,
    plugin_version  TEXT NOT NULL,
    status          TEXT NOT NULL DEFAULT 'pending',
    input           JSONB NOT NULL,
    output_summary  JSONB,
    error           TEXT,
    attempts        SMALLINT NOT NULL DEFAULT 0,
    started_at      TIMESTAMPTZ,
    finished_at     TIMESTAMPTZ,
    duration_ms     INTEGER,
    CONSTRAINT plugin_run_status_chk CHECK (
        status IN ('pending','running','succeeded','failed','skipped','timed_out')
    )
);

CREATE INDEX plugin_run_investigation_idx
    ON investigation.plugin_run (investigation_id, status);

CREATE TABLE investigation.evidence (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    investigation_id UUID NOT NULL REFERENCES investigation.investigation(id) ON DELETE CASCADE,
    plugin_run_id   UUID NOT NULL REFERENCES investigation.plugin_run(id) ON DELETE CASCADE,
    kind            TEXT NOT NULL,                  -- whois_record|dns_record|page|profile|email|...
    source_url      TEXT,
    content_sha256  BYTEA NOT NULL,
    content_size    BIGINT NOT NULL,
    storage_key     TEXT,                            -- S3/R2 key for blob
    summary         JSONB NOT NULL DEFAULT '{}',
    raw             JSONB,                          -- small, optional inline
    confidence      REAL NOT NULL DEFAULT 1.0 CHECK (confidence BETWEEN 0 AND 1),
    observed_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT evidence_kind_chk CHECK (kind IN (
        'whois_record','dns_record','http_page','http_headers',
        'social_profile','email_artifact','certificate','image_meta',
        'document','geolocation','phone','breach_entry','other'
    ))
);

CREATE INDEX evidence_investigation_idx
    ON investigation.evidence (investigation_id, kind);
CREATE INDEX evidence_sha256_idx ON investigation.evidence (content_sha256);

CREATE TABLE investigation.entity (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id       UUID NOT NULL REFERENCES identity.tenant(id),
    investigation_id UUID NOT NULL REFERENCES investigation.investigation(id) ON DELETE CASCADE,
    type            TEXT NOT NULL,                  -- person|domain|email|ip|org|username|phone|...
    value           TEXT NOT NULL,                  -- canonical
    aliases         TEXT[] NOT NULL DEFAULT '{}',
    attributes      JSONB NOT NULL DEFAULT '{}',
    first_seen_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    last_seen_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT entity_type_chk CHECK (type IN (
        'person','domain','subdomain','email','ip','organization',
        'username','phone','address','document','account','other'
    ))
);

-- Entity uniqueness within an investigation
CREATE UNIQUE INDEX entity_unique_idx
    ON investigation.entity (investigation_id, type, value);

CREATE INDEX entity_tenant_type_idx
    ON investigation.entity (tenant_id, type);

CREATE TABLE investigation.relationship (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    investigation_id UUID NOT NULL REFERENCES investigation.investigation(id) ON DELETE CASCADE,
    from_entity_id  UUID NOT NULL REFERENCES investigation.entity(id) ON DELETE CASCADE,
    to_entity_id    UUID NOT NULL REFERENCES investigation.entity(id) ON DELETE CASCADE,
    kind            TEXT NOT NULL,                  -- owns|registered_by|resolves_to|has_email|...
    weight          REAL NOT NULL DEFAULT 1.0,
    evidence_ids    UUID[] NOT NULL DEFAULT '{}',
    attributes      JSONB NOT NULL DEFAULT '{}',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT relationship_no_self CHECK (from_entity_id <> to_entity_id)
);

CREATE INDEX relationship_investigation_idx
    ON investigation.relationship (investigation_id);
CREATE INDEX relationship_from_idx
    ON investigation.relationship (from_entity_id);
CREATE INDEX relationship_to_idx
    ON investigation.relationship (to_entity_id);

CREATE TABLE investigation.export (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    investigation_id UUID NOT NULL REFERENCES investigation.investigation(id) ON DELETE CASCADE,
    tenant_id       UUID NOT NULL REFERENCES identity.tenant(id),
    format          TEXT NOT NULL,                  -- json|csv|pdf
    status          TEXT NOT NULL DEFAULT 'pending',
    size_bytes      BIGINT,
    storage_key     TEXT,
    download_url    TEXT,
    expires_at      TIMESTAMPTZ,
    error           TEXT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    finished_at     TIMESTAMPTZ,
    CONSTRAINT export_format_chk CHECK (format IN ('json','csv','pdf')),
    CONSTRAINT export_status_chk CHECK (status IN ('pending','running','ready','failed'))
);

CREATE INDEX export_investigation_idx
    ON investigation.export (investigation_id, created_at DESC);
```

### Partitioning

`investigation.evidence` is the largest table. Partition by
`created_at` (monthly) starting month 7. Pre-partition, expect 50M
rows / 100 GB at 10k investigations × 5k evidence each.

```sql
-- Example: monthly range partition
CREATE TABLE investigation.evidence_2026_07 PARTITION OF investigation.evidence
    FOR VALUES FROM ('2026-07-01') TO ('2026-08-01');
```

## 3. Plugin schema

```sql
CREATE SCHEMA plugin;

CREATE TABLE plugin.plugin (
    name            TEXT PRIMARY KEY,               -- e.g. 'whois'
    description     TEXT NOT NULL,
    homepage        TEXT,
    author          TEXT NOT NULL,
    latest_version  TEXT NOT NULL,
    target_kinds    TEXT[] NOT NULL,                -- ['domain','email',...]
    required_caps   TEXT[] NOT NULL DEFAULT '{}',   -- ['http','dns']
    icon_url        TEXT,
    is_official     BOOLEAN NOT NULL DEFAULT FALSE,
    is_enabled      BOOLEAN NOT NULL DEFAULT TRUE,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE plugin.installation (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id       UUID NOT NULL REFERENCES identity.tenant(id) ON DELETE CASCADE,
    plugin_name     TEXT NOT NULL REFERENCES plugin.plugin(name) ON DELETE CASCADE,
    version         TEXT NOT NULL,
    config          JSONB NOT NULL DEFAULT '{}',    -- per-tenant config
    enabled         BOOLEAN NOT NULL DEFAULT TRUE,
    installed_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (tenant_id, plugin_name)
);

CREATE TABLE plugin.manifest (
    plugin_name     TEXT NOT NULL REFERENCES plugin.plugin(name) ON DELETE CASCADE,
    version         TEXT NOT NULL,
    manifest_toml   TEXT NOT NULL,
    signature       BYTEA,                           -- detached
    signed_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (plugin_name, version)
);
```

## 4. Billing schema

```sql
CREATE SCHEMA billing;

CREATE TABLE billing.plan (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    code            TEXT UNIQUE NOT NULL,           -- 'free','pro','team'
    name            TEXT NOT NULL,
    stripe_price_id TEXT,
    monthly_price_cents BIGINT NOT NULL,
    currency        TEXT NOT NULL DEFAULT 'USD',
    limits          JSONB NOT NULL,                 -- quotas
    is_default      BOOLEAN NOT NULL DEFAULT FALSE,
    is_active       BOOLEAN NOT NULL DEFAULT TRUE,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE billing.subscription (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id       UUID NOT NULL UNIQUE REFERENCES identity.tenant(id) ON DELETE CASCADE,
    plan_id         UUID NOT NULL REFERENCES billing.plan(id),
    stripe_sub_id   TEXT UNIQUE,
    status          TEXT NOT NULL,                  -- active|past_due|canceled|trialing|incomplete
    current_period_end TIMESTAMPTZ,
    cancel_at       TIMESTAMPTZ,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT subscription_status_chk CHECK (
        status IN ('active','past_due','canceled','trialing','incomplete','unpaid')
    )
);

CREATE TABLE billing.invoice (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id       UUID NOT NULL REFERENCES identity.tenant(id),
    stripe_invoice_id TEXT UNIQUE,
    amount_cents    BIGINT NOT NULL,
    currency        TEXT NOT NULL,
    status          TEXT NOT NULL,                  -- paid|open|void|uncollectible
    pdf_url         TEXT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE billing.usage_counter (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id       UUID NOT NULL REFERENCES identity.tenant(id) ON DELETE CASCADE,
    metric          TEXT NOT NULL,                  -- investigations_started|evidence_collected|...
    period_start    TIMESTAMPTZ NOT NULL,
    period_end      TIMESTAMPTZ NOT NULL,
    count           BIGINT NOT NULL DEFAULT 0,
    UNIQUE (tenant_id, metric, period_start)
);

CREATE INDEX usage_counter_lookup_idx
    ON billing.usage_counter (tenant_id, metric, period_start);
```

## 5. Audit schema (append-only)

```sql
CREATE SCHEMA audit;

CREATE TABLE audit.event (
    id              BIGSERIAL PRIMARY KEY,
    occurred_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
    actor_kind      TEXT NOT NULL,                  -- user|api_key|system|plugin
    actor_id        UUID,
    tenant_id       UUID,
    action          TEXT NOT NULL,                  -- investigation.created, auth.login, ...
    target_kind     TEXT,
    target_id       UUID,
    request_id      UUID,
    ip              INET,
    user_agent      TEXT,
    payload         JSONB NOT NULL DEFAULT '{}',
    prev_hash       BYTEA,                          -- hash chain for tamper detection
    row_hash        BYTEA NOT NULL
);

CREATE INDEX audit_tenant_time_idx ON audit.event (tenant_id, occurred_at DESC);
CREATE INDEX audit_actor_time_idx ON audit.event (actor_id, occurred_at DESC);
CREATE INDEX audit_action_time_idx ON audit.event (action, occurred_at DESC);

-- Tamper-evident hash chain
CREATE OR REPLACE FUNCTION audit.event_hash() RETURNS trigger AS $$
DECLARE
    prev BYTEA;
BEGIN
    SELECT row_hash INTO prev
    FROM audit.event
    ORDER BY id DESC LIMIT 1;
    NEW.prev_hash := prev;
    NEW.row_hash := digest(
        COALESCE(prev, '\x'::bytea)::text ||
        NEW.occurred_at::text ||
        NEW.actor_kind ||
        COALESCE(NEW.actor_id::text,'') ||
        NEW.action ||
        COALESCE(NEW.payload::text,'{}'),
        'sha256'
    );
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER audit_event_hash_trg
    BEFORE INSERT ON audit.event
    FOR EACH ROW EXECUTE FUNCTION audit.event_hash();
```

`audit.event` is write-only from the app role. Reads go through a
separate read-only role. No `UPDATE` or `DELETE` grants.

## 6. Materialized views

```sql
-- Investigation dashboard aggregations
CREATE MATERIALIZED VIEW investigation.dashboard_stats AS
SELECT
    tenant_id,
    date_trunc('hour', created_at) AS bucket,
    COUNT(*) AS investigations_started,
    COUNT(*) FILTER (WHERE status = 'completed') AS completed,
    COUNT(*) FILTER (WHERE status = 'failed') AS failed,
    AVG(EXTRACT(EPOCH FROM (completed_at - started_at)))
        FILTER (WHERE completed_at IS NOT NULL) AS avg_duration_s
FROM investigation.investigation
GROUP BY tenant_id, date_trunc('hour', created_at);

CREATE UNIQUE INDEX dashboard_stats_idx
    ON investigation.dashboard_stats (tenant_id, bucket);

-- Refresh hourly via Celery beat
```

## 7. Enum-like TEXT vs Postgres ENUM

Decision: use **TEXT + CHECK constraint**, not Postgres ENUMs.
Reason: changing an enum requires migration dance. CHECK is
one-line. We do pay slightly in storage but it's negligible.

## 8. JSONB conventions

Every JSONB column has a documented schema, validated by Pydantic on
the application side. We do **not** use Postgres JSON Schema validation
in V1 — it's slow and adds friction. Instead:

- All JSONB access from app goes through a typed accessor
  (`MyModel.from_jsonb(value)`).
- Migrations add GIN indexes only when a real query pattern needs them.

Example indexes (added when needed, not on day one):

```sql
CREATE INDEX evidence_summary_gin ON investigation.evidence
    USING GIN (summary jsonb_path_ops);
```

## 9. Soft delete

`deleted_at TIMESTAMPTZ NULL`. All queries use a default scope that
filters `deleted_at IS NULL` unless explicitly bypassed
(`SELECT … FROM … WHERE … AND deleted_at IS NOT NULL`).

GDPR hard-delete: `purge_user(user_id)` SQL function does
`DELETE FROM …` across schemas, runs from a Celery task.

## 10. Migrations (Alembic)

Layout:

```
libs/argus_db/migrations/
├── env.py
├── script.py.mako
├── versions/
│   ├── 0001_initial.py
│   ├── 0002_investigation.py
│   ├── 0003_evidence.py
│   ├── ...
│   └── 0042_partition_evidence.py
└── seed/
    ├── plans.yaml
    └── plugin_catalog.yaml
```

`env.py` reads `DATABASE_URL` from settings. Uses `asyncpg` engine.

Alembic runs:

- At API startup: `alembic current` and **asserts** matches `head`.
  If not, refuses to boot. This prevents API and worker drift.
- At Worker startup: `alembic upgrade head` (only the worker runs
  migrations in production — see [13-DEPLOYMENT.md](13-DEPLOYMENT.md)).
- In CI: full migration test against a throwaway DB.

Naming convention: 12-char hex revision IDs. Each revision file
header has `Revision ID`, `Revises`, `Create Date`, and a `Summary`
with the issue tracker link.

## 11. Backups

- Nightly `pg_dump --schema=identity,investigation,plugin,billing,audit`
  compressed with zstd, uploaded to R2.
- 30-day retention.
- WAL archiving via `wal-g` (or simpler: PITR via managed provider).
- Monthly restore test in staging.

## 12. Connection pooling

- API: `asyncpg` pool size = `(cores × 2)`, `min_size=2`, statement
  cache 1000.
- Worker: same pool, but `pool_size = concurrency × 2`.
- PgBouncer not required in V1 (managed Postgres handles scale).

## 13. Performance budget per query

| Query | p95 target |
|-------|------------|
| Get investigation by id | < 20 ms |
| List investigations (paged) | < 50 ms |
| Get evidence (paged) | < 80 ms |
| Insert evidence (bulk 100) | < 200 ms |
| Insert entity (single) | < 10 ms |

We measure with `pg_stat_statements` and a Grafana panel. Queries
exceeding budget are flagged with `/* PERF */` comment and
revisited.

## 14. Future schema (V2+)

Not in V1, listed for context:

- `investigation.note` — analyst annotations.
- `investigation.share_link` — public read-only links with TTL.
- `plugin.webhook` — plugins can register outbound webhooks.
- `investigation.tag` — user-defined labels.
- `identity.sso_provider` — SAML/OIDC for team plans.
