# 10 — Queue Design

## 0. The two queues

We run **two queue systems** intentionally:

1. **Celery** — task execution (investigation lifecycle, plugin runs,
   exports, billing reconciliation, periodic jobs).
2. **Redis Streams** — domain event bus (see
   [09-EVENT-SYSTEM.md](09-EVENT-SYSTEM.md)).

Each has a clear role. Celery = "do this work". Streams = "this
happened".

Mixing them causes pain: if you put domain events on Celery, you
lose replay. If you put task execution on Streams, you lose retries.

## 1. Celery queues

Priority-ordered, name-kebab-cased, routed by task name.

| Queue | Priority | Concurrency (prod) | Purpose |
|-------|----------|---------------------|---------|
| `ctrl` | 10 | 2 | Lifecycle (plan, cancel, pause, resume) |
| `plugins` | 5 | 2 | Plugin subprocess runs |
| `evidence` | 3 | 1 | Persist + dedupe evidence |
| `entity` | 3 | 1 | Entity extraction |
| `relationship` | 3 | 1 | Graph build |
| `export` | 2 | 1 | JSON/CSV/PDF render |
| `billing` | 5 | 1 | Stripe webhooks, quota reset |
| `maintenance` | 1 | 1 | Cleanup, dashboard refresh |

Priority is `0–10`. Kombu uses `queue_order_strategy="priority"`.

## 2. Per-tenant and per-plugin isolation

### Per-tenant cap on concurrent investigations

Tracked in Redis: `argus:quota:concurrency:{tenant_id}` is an integer
counter.

```python
async def acquire_concurrency_slot(tenant_id: UUID, limit: int) -> bool:
    key = f"argus:quota:concurrency:{tenant_id}"
    current = await redis.incr(key)
    if current > limit:
        await redis.decr(key)
        return False
    return True

async def release_concurrency_slot(tenant_id: UUID) -> None:
    await redis.decr(f"argus:quota:concurrency:{tenant_id}")
```

Slots are released in `finally:` of `argus.investigation.reduce` and
`argus.investigation.cancel_cleanup`.

### Per-tenant rate limit (RPM)

Token bucket per tenant for plugin invocations:

```python
# libs/argus_common/ratelimit/token_bucket.py
import time
from redis.asyncio import Redis

LUA = """
local key = KEYS[1]
local rate = tonumber(ARGV[1])     -- tokens per second
local capacity = tonumber(ARGV[2])
local now = tonumber(ARGV[3])
local cost = tonumber(ARGV[4])

local data = redis.call('HMGET', key, 'tokens', 'ts')
local tokens = tonumber(data[1]) or capacity
local ts = tonumber(data[2]) or now

local delta = math.max(0, now - ts)
tokens = math.min(capacity, tokens + delta * rate)

if tokens < cost then
    return {0, tokens}
end
tokens = tokens - cost
redis.call('HMSET', key, 'tokens', tokens, 'ts', now)
redis.call('EXPIRE', key, 60)
return {1, tokens}
"""

class TokenBucket:
    def __init__(self, redis: Redis, key: str, rate: float, capacity: float):
        self._r = redis
        self._key = key
        self._rate = rate
        self._cap = capacity
        self._script = redis.register_script(LUA)

    async def acquire(self, cost: float = 1.0) -> tuple[bool, float]:
        now = time.time()
        ok, remaining = await self._script(
            keys=[self._key],
            args=[self._rate, self._cap, now, cost],
        )
        return bool(ok), float(remaining)
```

## 3. SLA per task

| Task | p95 target | p99 target | Hard timeout |
|------|------------|------------|---------------|
| `argus.investigation.plan` | 1 s | 3 s | 30 s |
| `argus.plugin.run` | 30 s | 90 s | 300 s |
| `argus.evidence.persist` | 200 ms | 500 ms | 30 s |
| `argus.entity.extract` | 500 ms | 2 s | 60 s |
| `argus.relationship.discover` | 1 s | 5 s | 120 s |
| `argus.export.render` (PDF ≤ 1k ev) | 5 s | 15 s | 60 s |
| `argus.export.render` (PDF ≤ 10k ev) | 30 s | 60 s | 180 s |

Hard timeout is enforced via Celery `time_limit`; soft timeout via
`soft_time_limit` sends SIGTERM first.

## 4. Retry policy

| Layer | Retries | Backoff | Notes |
|-------|---------|---------|-------|
| HTTPX client (API → upstream) | 3 | exp, jitter, max 30s | For 502/503/504 + connect |
| Plugin subprocess | 3 | exp, max 300s | Only `PluginTransientError` |
| Celery task | per-task | exp, max per-task | See [06-WORKERS.md](06-WORKERS.md) |
| Event consumer | 3 (in handler) | exp, max 30s | After: → DLQ |

`tenacity` is the in-process retry lib. Celery's `autoretry_for` is
the cross-process retry.

## 5. Dead-letter queue

After Celery max retries, the task result is moved to:

- Redis list `argus:dlq:tasks` with the original args + last error.
- `audit.event` row with `action="task.dlq"`.

A Celery beat job (`argus.maintenance.drain_dlq`) reads the DLQ every
5 minutes and:

- For investigation failures → update status to `failed`, notify bot
  via event.
- For billing failures → page on-call.
- For plugin failures → mark plugin as `unstable` in catalog after
  5 fails / hour.

## 6. Backpressure strategies

If a queue depth exceeds threshold:

- **plugins > 200**: pause `POST /v1/investigations` for that
  tenant until depth drops.
- **evidence > 1000**: drop oldest by `MAXLEN`, never lose in-flight
  plugin outputs.
- **export > 100**: bot shows "exports temporarily slow" banner.
- **billing > 20**: critical; alarm on-call.

Depth thresholds live in `Settings.queue.depth_thresholds`. We
monitor with Prometheus and write to `argus.queue_depth` gauge.

## 7. Quota enforcement

When `POST /v1/investigations` arrives:

```python
async def enforce_quotas(tenant_id, plan) -> None:
    # Per-month counter
    used = await UsageCounterRepo(plan.tenant_id).current_period(
        metric="investigations_started")
    if used >= plan.limits["investigations_per_month"]:
        raise QuotaExceeded("investigations_per_month")
    # Concurrency
    if not await acquire_concurrency_slot(tenant_id, plan.limits["concurrent_running"]):
        raise QuotaExceeded("concurrent_running")
```

On success, the counter is incremented in the same transaction as the
investigation row insert. Counter is in `billing.usage_counter`.

## 8. Cron / periodic jobs (Celery beat)

| Job | Schedule | Purpose |
|-----|----------|---------|
| `argus.billing.reset_daily_quotas` | 00:05 UTC | (Daily quotas reset; monthly is on subscription cycle) |
| `argus.billing.reconcile_stripe` | every 6 h | Pull subscriptions from Stripe, repair local mirror |
| `argus.maintenance.refresh_dashboard_mv` | hourly :15 | REFRESH MATERIALIZED VIEW |
| `argus.maintenance.cleanup_expired_exports` | 03:00 UTC | Delete S3 keys + rows past `expires_at` |
| `argus.maintenance.run_pending_purges` | hourly :00 | GDPR purges |
| `argus.maintenance.cleanup_idempotency` | 02:00 UTC | Delete idempotency rows past TTL |
| `argus.maintenance.session_gc` | 04:00 UTC | Drop revoked sessions after 30 d |
| `argus.maintenance.drain_dlq` | every 5 min | Process DLQ |
| `argus.maintenance.health_self` | every 1 min | Self-ping /health from worker |

## 9. Failure isolation between tenants

- Celery queues are **shared**, not per-tenant. We rely on:
  - Per-tenant concurrency slot (above).
  - Per-tenant plugin rate bucket.
  - Per-tenant monthly counter.
- **Do not** spin up per-tenant queues — operational overhead is
  high and free-tier Redis can't handle thousands of queues.
- For V2 we will route by tenant hash to a fixed pool of queues
  (e.g. 16 queues, hash mod 16) if isolation proves insufficient.

## 10. Worker scaling

Single worker process with `concurrency=4` handles ~50 investigations
in flight. To scale:

- **Vertical**: bump `--concurrency` to 8. Bottleneck is plugin
  subprocess startup (cold start). Pool sub-interpreters.
- **Horizontal**: run multiple worker processes (`worker@1`,
  `worker@2`, ...) and let Celery autoscale via
  `--autoscale=8,2`. Free-tier PaaS supports this on Railway/Koyeb.
- **Plugin pool**: keep N pre-started subprocess per plugin per
  worker. Cuts cold start from 200ms to <20ms.

## 11. Bot-side queues

The bot has **no** task queue. It uses:

- aiogram's `Dispatcher` for updates.
- An in-process asyncio.Task per active progress watcher (cancelled
  when user moves away).
- Redis FSM storage for cross-restart state.

This is intentional. The bot does not do background work; the worker
does.

## 12. Stream consumer groups

| Group | Topics | Members |
|-------|--------|---------|
| `entity-extractor` | `evidence.found` | Worker (entity task triggered per event) |
| `relationship-builder` | `entity.found`, `entity.updated` | Worker |
| `analytics` | `investigation.*`, `plugin.*`, `evidence.found` | Worker (analytics writer) |
| `billing-counter` | `investigation.completed`, `export.requested` | Worker |
| `bot-{user_id}` | `investigation.*`, `evidence.found`, `entity.*`, `relationship.*`, `export.*` | Bot SSE forwarder (API) |

Per-user bot groups are auto-created on SSE connect and never
destroyed (cheap on Redis).

## 13. Ordering per investigation

Redis Streams guarantees append order per key. We use one stream
per topic (`investigation.created`, `evidence.found`, etc.). Events
for one investigation interleave with events for others — that's
fine because:

- The bot's SSE forwarder filters by investigation_id and reorders
  by `occurred_at` if needed (rare in practice).
- Workers consuming by tenant_id don't care about global order.

## 14. Capacity planning (1k investigations / day)

| Metric | Budget |
|--------|--------|
| Investigations/day | 1,000 |
| Avg plugin tasks per investigation | 6 |
| Total plugin tasks/day | 6,000 |
| Plugin runs/sec (peak) | 4 |
| Evidence items/investigation | 200 |
| Total evidence rows/day | 200,000 |
| Events/sec (peak) | 200 |
| DB writes/sec (peak) | 50 |
| Redis ops/sec (peak) | 1,500 |

A single 4-vCPU / 8GB API + 4-concurrency worker + 1 Redis + managed
Postgres handles this with 40% headroom. Documented in
`docs/runbooks/capacity.md`.

## 15. SLOs

| SLO | Target | Measurement |
|-----|--------|-------------|
| API availability | 99.5% | `/health` 200 vs 5xx over 30d |
| Investigation completion p95 | < 60 s | `investigation.completed_at - started_at` |
| Bot edit-to-render p95 | < 2 s | SSE → Telegram edit |
| Worker task success rate | > 99% | `tasks_total{status=success} / tasks_total` |
| Quota enforcement accuracy | 100% | Property test: under plan, never blocked; over plan, blocked |

## 16. Day-to-day operations

- Inspect Celery: `celery -A argus_worker.celery_app inspect active`
- Inspect Redis streams: `redis-cli XLEN argus:events:evidence.found`
- Drain DLQ manually: `python scripts/drain_dlq.py`
- Force cancel an investigation: `python scripts/force_cancel.py <id>`

## 17. Anti-patterns (things we will not do)

- Direct Celery `send_task` with raw `args=[...]` from the API — too
  easy to get wrong. Use shared task objects and `delay()`.
- Long-running tasks (≥ 5 min) — split into smaller pieces with
  checkpoints.
- Per-tenant worker — operationally expensive.
- Blocking `time.sleep` in async tasks — always use
  `await asyncio.sleep`.
- Cross-tenant data access — fail-fast at the repo layer.

## 18. Migration to multi-region (V3)

The Redis bus makes multi-region harder (single-region Streams).
For V3 we will:

- Run one Redis per region.
- Route events by tenant home region.
- Use NATS JetStream (or Pulsar) for cross-region fan-out.

V1 design keeps this option open by routing through the `EventBus`
Protocol.
