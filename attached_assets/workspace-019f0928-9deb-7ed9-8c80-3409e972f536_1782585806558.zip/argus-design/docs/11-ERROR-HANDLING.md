# 11 — Error Handling

## 0. Goals

1. Every error has a stable **code**, an HTTP status, and a
   user-actionable message.
2. Stack traces never reach end users.
3. Errors are **observable** — Sentry, Loki, audit log.
4. Retry decisions are explicit, not guesswork.
5. Plugin errors are **contained** — they never crash the worker.

## 1. Exception hierarchy

```python
# libs/argus_common/errors.py
class ArgusError(Exception):
    """Base. Has a stable code, an HTTP status, and a public message."""
    code: str = "internal_error"
    status: int = 500
    public: bool = False  # True → safe to surface to end user

    def __init__(self, message: str = "", *, http: int | None = None,
                 public: bool | None = None, **context):
        super().__init__(message)
        self.message = message or self.code
        if http is not None: self.status = http
        if public is not None: self.public = public
        self.context = context

# ── Input ─────────────────────────────────────────────────────────
class InvalidInputError(ArgusError):
    code = "invalid_input"
    status = 400
    public = True

class InvalidTargetError(InvalidInputError):
    code = "invalid_target"

class InvalidPluginManifestError(ArgusError):
    code = "invalid_plugin_manifest"
    status = 400

# ── Auth ──────────────────────────────────────────────────────────
class UnauthenticatedError(ArgusError):
    code = "unauthenticated"
    status = 401

class ForbiddenError(ArgusError):
    code = "forbidden"
    status = 403

class RefreshReuseDetectedError(ArgusError):
    code = "refresh_reuse"
    status = 401

class InvalidTelegramDataError(ArgusError):
    code = "invalid_telegram_data"
    status = 401

# ── Resource ──────────────────────────────────────────────────────
class NotFoundError(ArgusError):
    code = "not_found"
    status = 404

class ConflictError(ArgusError):
    code = "conflict"
    status = 409

class IdempotencyConflictError(ConflictError):
    code = "idempotency_conflict"

# ── Quota / rate ──────────────────────────────────────────────────
class QuotaExceededError(ArgusError):
    code = "quota_exceeded"
    status = 402

class RateLimitedError(ArgusError):
    code = "rate_limited"
    status = 429

# ── Upstream ──────────────────────────────────────────────────────
class UpstreamUnavailableError(ArgusError):
    code = "upstream_unavailable"
    status = 502

class PluginTransientError(ArgusError):
    code = "plugin_transient"
    status = 502

class PluginPermanentError(ArgusError):
    code = "plugin_permanent"
    status = 502

class PluginTimeoutError(ArgusError):
    code = "plugin_timeout"
    status = 504

class PluginNotFoundError(ArgusError):
    code = "plugin_not_found"
    status = 404

class PluginUnsignedError(ArgusError):
    code = "plugin_unsigned"
    status = 403

class PluginSignatureError(ArgusError):
    code = "plugin_signature"
    status = 403

class PluginInputError(ArgusError):
    code = "plugin_input"
    status = 502

class PluginExecutionError(ArgusError):
    code = "plugin_execution"
    status = 502

# ── System ────────────────────────────────────────────────────────
class ServiceUnavailableError(ArgusError):
    code = "service_unavailable"
    status = 503

class DependencyDownError(ArgusError):
    code = "dependency_down"
    status = 503

# ── Domain specific ───────────────────────────────────────────────
class InvestigationNotStartableError(ArgusError):
    code = "investigation_not_startable"
    status = 409

class InvestigationAlreadyFinishedError(ArgusError):
    code = "investigation_already_finished"
    status = 409

class ExportTooLargeError(ArgusError):
    code = "export_too_large"
    status = 413

class StorageError(ArgusError):
    code = "storage_error"
    status = 502
```

## 2. RFC 7807 mapping (API)

```python
# services/api/src/argus_api/middleware/errors.py
import traceback
from fastapi import Request, status
from fastapi.responses import JSONResponse
import structlog

from argus_common.errors import ArgusError
from argus_common.logging import request_id_var

log = structlog.get_logger()

async def error_middleware(request: Request, call_next):
    try:
        return await call_next(request)
    except ArgusError as e:
        return _argus_error_response(request, e)
    except Exception as e:
        return _unhandled_error_response(request, e)

def _argus_error_response(request, e: ArgusError):
    body = {
        "type": f"https://docs.argus.saas/errors/{e.code}",
        "title": e.code.replace("_", " ").title(),
        "status": e.status,
        "detail": e.message if e.public else "An error occurred.",
        "instance": str(request.url.path),
        "request_id": str(request_id_var.get()),
    }
    if e.context:
        body["errors"] = [
            {"code": e.code, "message": str(v), "field": str(k)}
            for k, v in e.context.items()
        ]
    log.warning("api.error", code=e.code, status=e.status,
                path=str(request.url.path), method=request.method,
                detail=e.message, **e.context)
    if e.status >= 500:
        log.error("api.error_5xx", code=e.code, exc_info=True)
    return JSONResponse(body, status_code=e.status)

def _unhandled_error_response(request, e: Exception):
    log.exception("api.unhandled", path=str(request.url.path))
    sentry_sdk.capture_exception(e)
    return JSONResponse(
        {
            "type": "https://docs.argus.saas/errors/internal_error",
            "title": "Internal Server Error",
            "status": 500,
            "detail": "An internal error occurred.",
            "instance": str(request.url.path),
            "request_id": str(request_id_var.get()),
        },
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
    )
```

## 3. Pydantic validation → 400

Pydantic `ValidationError` is caught and converted:

```python
from pydantic import ValidationError

@app.exception_handler(ValidationError)
async def validation_handler(request, exc):
    return JSONResponse(
        {
            "type": "https://docs.argus.saas/errors/invalid_input",
            "title": "Invalid input",
            "status": 400,
            "detail": "One or more fields failed validation.",
            "instance": str(request.url.path),
            "request_id": str(request_id_var.get()),
            "errors": [
                {
                    "field": ".".join(str(p) for p in e["loc"][1:]),
                    "code": e["type"],
                    "message": e["msg"],
                }
                for e in exc.errors()
            ],
        },
        status_code=400,
    )
```

## 4. Worker error handling

```python
# services/worker/src/argus_worker/tasks/_safety.py
from argus_common.logging import configure_logging
from argus_common.errors import (
    ArgusError, PluginTransientError, PluginPermanentError,
)
import sentry_sdk

log = configure_logging("worker")

def task_error_handler(task_name: str):
    def decorator(fn):
        def wrapper(self, *args, **kwargs):
            try:
                return fn(self, *args, **kwargs)
            except PluginTransientError as e:
                log.warning("task.transient",
                            task=task_name, error=str(e))
                raise self.retry(exc=e, countdown=min(60, 2 ** self.request.retries))
            except PluginPermanentError as e:
                log.error("task.permanent",
                          task=task_name, error=str(e))
                # Don't retry; record DLQ
                _send_to_dlq(self.name, args, kwargs, str(e))
                sentry_sdk.capture_exception(e)
                raise Ignore()
            except ArgusError as e:
                log.error("task.domain_error",
                          task=task_name, code=e.code, error=str(e))
                sentry_sdk.capture_exception(e)
                raise Ignore()
            except Exception as e:
                log.exception("task.unhandled", task=task_name)
                sentry_sdk.capture_exception(e)
                raise Ignore()
        return wrapper
    return decorator
```

`celery.exceptions.Ignore` swallows the failure so Celery doesn't
count it toward max retries.

## 5. Plugin subprocess exit codes

| Exit | Meaning | Worker action |
|------|---------|---------------|
| 0 | Success | Persist outputs |
| 1 | `PluginInputError` | Mark `plugin_run` failed, no retry |
| 2 | `PluginTransientError` | Retry up to 3 |
| 3 | `PluginPermanentError` | Mark failed, no retry, audit |
| 124 | Timeout (SIGTERM after soft_time_limit) | Retry once (transient), then mark timeout |
| 137 | SIGKILL (OOM or hard kill) | Mark failed, audit |
| other | Uncaught exception | Mark failed, capture stderr in `plugin_run.error` |

## 6. Bot error mapping

The bot translates API errors into user-friendly strings via the
`ERROR_MAP` (see [05-TELEGRAM-BOT.md](05-TELEGRAM-BOT.md)).

```python
ERROR_MAP = {
    "invalid_input":           ("errors.invalid_input",       True),
    "unauthenticated":         ("errors.please_restart",      False),
    "forbidden":               ("errors.no_access",          False),
    "not_found":               ("errors.not_found",          True),
    "conflict":                ("errors.conflict",           True),
    "quota_exceeded":          ("errors.quota_exceeded",      True),
    "rate_limited":            ("errors.slow_down",          True),
    "upstream_unavailable":    ("errors.upstream_failed",    True),
    "service_unavailable":     ("errors.service_degraded",   True),
    "plugin_transient":        ("errors.plugin_retrying",    True),
    "plugin_permanent":        ("errors.plugin_failed",      True),
    "plugin_timeout":          ("errors.plugin_slow",        True),
    "export_too_large":        ("errors.export_too_large",   True),
    "internal_error":          ("errors.something_wrong",    False),
}
```

Second tuple element = whether the error gets a "Retry" button.

## 7. Retry strategy — table

| Error class | HTTP | Celery retry? | Plugin retry? | HTTPX retry? |
|-------------|------|---------------|---------------|---------------|
| `InvalidInputError` | 400 | No | — | — |
| `UnauthenticatedError` | 401 | No | — | — |
| `ForbiddenError` | 403 | No | — | — |
| `NotFoundError` | 404 | No | — | — |
| `QuotaExceededError` | 402 | No | — | — |
| `RateLimitedError` | 429 | Yes (after Retry-After) | — | — |
| `UpstreamUnavailableError` | 502 | Yes (3, exp backoff) | — | Yes |
| `PluginTransientError` | 502 | Yes (3, exp backoff) | Yes | — |
| `PluginPermanentError` | 502 | No | No | — |
| `PluginTimeoutError` | 504 | Yes (1) | No | — |
| `ServiceUnavailableError` | 503 | Yes (5, exp backoff) | — | — |
| `StorageError` | 502 | Yes (5, exp backoff) | — | — |
| Unhandled `Exception` | 500 | No (DLQ) | No | — |

## 8. Structured logging on errors

Every error log line includes:

```json
{
  "level": "error",
  "timestamp": "2026-06-27T10:00:00Z",
  "service": "api",
  "request_id": "...",
  "user_id": "...",
  "tenant_id": "...",
  "path": "/v1/investigations",
  "method": "POST",
  "status": 500,
  "code": "internal_error",
  "error": "division by zero",
  "exc_type": "ZeroDivisionError",
  "exc_message": "division by zero",
  "trace_id": "..."  // OTel
}
```

## 9. Sentry integration

```python
# libs/argus_common/observability.py
import sentry_sdk
from sentry_sdk.integrations.fastapi import FastApiIntegration
from sentry_sdk.integrations.celery import CeleryIntegration
from sentry_sdk.integrations.sqlalchemy import SqlalchemyIntegration
from sentry_sdk.integrations.redis import RedisIntegration

def init_sentry(service: str, settings):
    sentry_sdk.init(
        dsn=settings.sentry_dsn,
        environment=settings.env,
        release=settings.release,
        service=service,
        integrations=[
            FastApiIntegration(),
            CeleryIntegration(),
            SqlalchemyIntegration(),
            RedisIntegration(),
        ],
        traces_sample_rate=settings.otel_sampling_ratio,
        profiles_sample_rate=0.1,
        before_send=_scrub,
    )

def _scrub(event, hint):
    # Strip Authorization, cookies, tokens
    if "request" in event and "headers" in event["request"]:
        event["request"]["headers"] = {
            k: v for k, v in event["request"]["headers"].items()
            if k.lower() not in ("authorization", "cookie", "x-telegram-init-data")
        }
    return event
```

## 10. Correlation IDs

- API: `X-Request-ID` header is read or generated by
  `CorrelationMiddleware`. Stored in `request_id_var` contextvar.
- Worker: each task generates a `task_request_id` at start.
- Event bus: every event has `event_id` (acts as correlation ID for
  the consumer).
- Bot: every Telegram update gets a `update_request_id` from
  `CorrelationMiddleware`.

These IDs propagate through logs and into Sentry breadcrumbs so a
single user action is fully traceable.

## 11. User-facing error messages

Tone: **apologetic, actionable, never blaming the user, never
revealing internal details.**

Examples:

- `"We couldn't reach one of our data sources. Retrying automatically — no action needed."`
- `"You've used all 20 free investigations this month. Upgrade to Pro to continue."` + Upgrade button.
- `"That doesn't look like a valid domain. Try something like example.com."`
- `"This is taking longer than expected. You can wait, or cancel and try again later."`

We never say "NullPointerException" or "Internal Server Error" to
users. Bot's `errors.py` is the single source of truth.

## 12. Testing the error contract

```python
# services/api/tests/test_error_contract.py
import pytest
from argus_common.errors import (
    InvalidInputError, QuotaExceededError, RateLimitedError,
)

@pytest.mark.parametrize("error,status", [
    (InvalidInputError("bad"), 400),
    (QuotaExceededError("plan"), 402),
    (RateLimitedError("bucket"), 429),
])
def test_error_status(error, status):
    assert error.status == status

@pytest.mark.parametrize("error,public", [
    (InvalidInputError("x"), True),
    (QuotaExceededError("x"), True),
    (UnauthenticatedError("x"), False),
])
def test_error_public_flag(error, public):
    assert error.public == public

def test_rfc7807_shape(client):
    r = client.post("/v1/investigations", json={"target": {"kind": "x", "value": "!"}})
    assert r.status_code == 400
    body = r.json()
    assert body["type"].startswith("https://docs.argus.saas/errors/")
    assert "request_id" in body
```

## 13. Error budgets

| Category | Weekly error budget | Action on breach |
|----------|---------------------|------------------|
| 5xx API responses | 0.1% of total | Page on-call |
| Worker task failures | 1% of total | Investigate top failure cause |
| Plugin signature failures | 5 / week | Page on-call (security signal) |
| Quota errors (expected) | unlimited | None |
| Rate limit errors (expected) | unlimited | None |

## 14. Self-healing behaviors

- `PluginTransientError` → automatic retry.
- `ServiceUnavailableError` → automatic retry with backoff.
- `RefreshReuseDetectedError` → automatic family revoke.
- DLQ → automatic audit, manual review.
- DB transient → automatic retry (3 times).
- Redis transient → automatic retry with reconnect (5 times).

## 15. What we do not do

- Catch-all `except Exception:` without re-raising or logging.
- Silent fallbacks ("return empty list on error"). Fail loud.
- Custom error subclasses that don't inherit from `ArgusError`.
- Stack traces in HTTP responses (only in logs/Sentry).
- Generic `"Error"` strings — every error has a stable `code`.

## 16. Documenting new errors

When you add a new error class:

1. Inherit from `ArgusError` or appropriate subclass.
2. Set `code`, `status`, `public` as class attributes.
3. Add a mapping in bot's `ERROR_MAP`.
4. Add a row in [04-API-SPEC.md § 12](04-API-SPEC.md).
5. Add a test in `test_error_contract.py`.

A linter rule (custom) flags new `Exception` subclasses outside
`libs/argus_common/errors.py` that don't inherit from `ArgusError`.
