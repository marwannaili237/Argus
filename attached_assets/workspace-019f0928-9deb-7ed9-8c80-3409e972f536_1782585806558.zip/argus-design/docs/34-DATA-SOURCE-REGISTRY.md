# 34 — Data Source Registry

> Central registry of every data source Argus can query (internal
> or third-party). Provides capabilities, authentication, rate
> limits, reliability score, cost model, browser/proxy needs,
> supported entity types, output schema versions, and lifecycle.
> Shared between Planner, Runtime, Cost Controller, and Scheduler.

---

## 0. Position

```
   Plugin catalog (03 / 07)         Source Registry (34)
       │                                  │
       │ plugin.plugin row               │ source_registry row (extends)
       │                                  │
       └──────► merged into source_registry ◄──── plugin source code
                                                          │
                                                          ▼
                                          Used by:
                                            Planner (24) — selects
                                            Runtime (33) — applies caps
                                            Cost (31) — applies pricing
                                            Scheduler (28) — schedules
```

The Source Registry is the **authoritative metadata layer** for
data sources. Each `plugin.plugin` row from 03/07 is **automatically
registered** in the registry on plugin install. The registry
extends plugin metadata with operational fields (auth, rate
limits, reliability, cost).

## 1. Goals

1. One place to look up: "what does source X cost, what does it
   return, who maintains it, is it deprecated?".
2. Source failures don't take down the system — registry-driven
   fallback.
3. Clear deprecation lifecycle.
4. Output schema versions explicitly tracked.

## 2. Public interface

```python
class DataSourceRegistry(Protocol):
    async def get(self, source_id: str) -> SourceSpec: ...
    async def list_for_kind(self, entity_kind: str) -> list[SourceSpec]: ...
    async def list_for_capability(self, capability: str) -> list[SourceSpec]: ...
    async def register(self, spec: SourceSpec) -> None: ...
    async def update(self, source_id: str, patch: dict) -> None: ...
    async def deprecate(self, source_id: str, replacement: str | None, reason: str) -> None: ...
    async def status(self) -> SourceRegistryStatus: ...
```

```python
@dataclass(slots=True, frozen=True)
class SourceSpec:
    source_id: str                       # unique stable ID
    display_name: str
    description: str
    plugin_name: str                     # links to plugin.plugin
    plugin_version: str                  # pinned version
    entity_kinds: tuple[str, ...]        # ['domain','email','ip',...]
    capabilities_required: tuple[str, ...]  # ['http','browser','dns',...]
    auth_required: tuple[AuthRequirement, ...]
    rate_limit: RateLimit
    reliability_score: float              # 0.0 - 1.0
    cost_model: CostModel
    output_schema_version: int
    browser_required: bool
    proxy_required: bool
    proxy_types: tuple[str, ...]         # ['residential','mobile']
    geo_requirements: tuple[str, ...]    # ['any'] or ['us','eu']
    maintenance_status: MaintenanceStatus
    deprecation: DeprecationInfo | None
    documentation_url: str | None
    contact_email: str | None
    registered_at: datetime
    last_verified_at: datetime | None

@dataclass(slots=True, frozen=True)
class AuthRequirement:
    secret_key: str                      # ref into secrets manager
    scheme: Literal["api_key","bearer","basic","oauth2","none"]
    description: str

@dataclass(slots=True, frozen=True)
class RateLimit:
    requests_per_minute: int | None
    requests_per_hour: int | None
    requests_per_day: int | None
    bytes_per_minute: int | None
    bytes_per_hour: int | None
    notes: str

@dataclass(slots=True, frozen=True)
class CostModel:
    cost_per_call_credits: int | None
    cost_per_kb_credits: int | None
    cost_per_call_cents: float | None    # for billing pass-through
    monthly_cap_cents: int | None
    notes: str

@dataclass(slots=True, frozen=True)
class MaintenanceStatus:
    state: Literal["active","limited","stale","unmaintained"]
    last_commit_at: datetime | None
    open_issues: int
    maintainer_team: str | None

@dataclass(slots=True, frozen=True)
class DeprecationInfo:
    deprecated_at: datetime
    sunset_at: datetime
    replacement_source_id: str | None
    reason: str
    migration_guide_url: str | None
```

## 3. Data model

```sql
CREATE TABLE plugin.source_registry (
    source_id             TEXT PRIMARY KEY,
    display_name          TEXT NOT NULL,
    description           TEXT NOT NULL,
    plugin_name           TEXT NOT NULL REFERENCES plugin.plugin(name),
    plugin_version        TEXT NOT NULL,
    entity_kinds          TEXT[] NOT NULL,
    capabilities_required TEXT[] NOT NULL,
    auth_required         JSONB NOT NULL DEFAULT '[]',
    rate_limit            JSONB NOT NULL DEFAULT '{}',
    reliability_score     REAL NOT NULL DEFAULT 0.5
                          CHECK (reliability_score BETWEEN 0 AND 1),
    cost_model            JSONB NOT NULL DEFAULT '{}',
    output_schema_version INT NOT NULL DEFAULT 1,
    browser_required      BOOLEAN NOT NULL DEFAULT FALSE,
    proxy_required        BOOLEAN NOT NULL DEFAULT FALSE,
    proxy_types           TEXT[] NOT NULL DEFAULT '{}',
    geo_requirements      TEXT[] NOT NULL DEFAULT '{any}',
    maintenance_status    JSONB NOT NULL DEFAULT '{}',
    deprecation           JSONB,
    documentation_url     TEXT,
    contact_email         TEXT,
    registered_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
    last_verified_at      TIMESTAMPTZ,
    CONSTRAINT source_geo_chk CHECK (
        cardinality(geo_requirements) >= 1
    )
);
CREATE INDEX source_registry_kind_idx
    ON plugin.source_registry USING GIN (entity_kinds);
CREATE INDEX source_registry_cap_idx
    ON plugin.source_registry USING GIN (capabilities_required);

CREATE TABLE plugin.source_reliability_history (
    id                   UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    source_id            TEXT NOT NULL REFERENCES plugin.source_registry(source_id) ON DELETE CASCADE,
    observed_at          TIMESTAMPTZ NOT NULL,
    success_count        INT NOT NULL DEFAULT 0,
    failure_count        INT NOT NULL DEFAULT 0,
    avg_latency_ms       INT,
    p95_latency_ms       INT,
    sample_size          INT NOT NULL,
    reliability_score    REAL NOT NULL
);
CREATE INDEX source_reliability_source_idx
    ON plugin.source_reliability_history (source_id, observed_at DESC);

CREATE TABLE plugin.source_capability_changes (
    id                   UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    source_id            TEXT NOT NULL,
    field                TEXT NOT NULL,
    old_value            JSONB,
    new_value            JSONB NOT NULL,
    reason               TEXT,
    actor_id             UUID,
    changed_at           TIMESTAMPTZ NOT NULL DEFAULT now()
);
```

## 4. Source capabilities

Capabilities are inherited from the plugin manifest but documented
explicitly in the registry for routing purposes.

| Capability | Examples |
|-----------|----------|
| `domain.whois` | RDAP/WHOIS |
| `domain.dns` | DNS record lookup |
| `domain.subdomain_enum` | crt.sh, Amass |
| `domain.http` | HTTP crawl |
| `domain.cert` | Certificate Transparency |
| `email.verify` | Hunter, NeverBounce |
| `email.breach` | HIBP, dehashed.com |
| `person.social` | social_x |
| `person.public_records` | voter rolls |
| `phone.carrier` | Twilio Lookup |
| `phone.geolocation` | HLR |
| `ip.geolocation` | MaxMind, ipinfo |
| `ip.asn` | BGP tools |
| `ip.reputation` | AbuseIPDB |
| `company.financial` | OpenCorporates |
| `company.employees` | LinkedIn (paid) |
| `crypto.address` | Blockchain explorers |
| `image.reverse_search` | TinEye, Yandex |
| `document.osint` | Maltego, Recorded Future |

## 5. Authentication requirements

Each source declares what credentials it needs. The runtime
(33) fetches them from the secrets manager at run time.

| Auth scheme | Examples |
|-------------|----------|
| `none` | crt.sh, RDAP |
| `api_key` | Shodan, Hunter, VirusTotal |
| `bearer` | HaveIBeenPwned |
| `basic` | Some legacy APIs |
| `oauth2` | Twitter/X, some Google APIs |

The registry stores the **names** of secrets needed (e.g.
`shodan_api_key`), not values. Values live in the secrets manager
and are injected per run via 33-PLUGIN-RUNTIME §8.

## 6. Rate limits

Sources have heterogeneous limits. We model:

- Per-minute, per-hour, per-day request caps.
- Byte caps (for streaming sources).
- Concurrent connection caps (rare; mostly tracked in plugin).

The runtime respects these via the bucket:

```python
@dataclass(slots=True, frozen=True)
class SourceRateBucket:
    source_id: str
    capacity_min: int
    capacity_hr: int
    capacity_day: int
    refill_per_s: float
```

We use a token-bucket per source per tenant. Same algorithm as
[10-QUEUE-DESIGN §2](10-QUEUE-DESIGN.md).

## 7. Reliability score

Updated continuously by the runtime. Formula:

```
score = 0.4 * recent_success_rate
      + 0.3 * long_term_success_rate
      + 0.2 * speed_score
      + 0.1 * freshness_score

recent_success_rate = last_24h successes / last_24h total
long_term_success_rate = last_30d successes / last_30d total
speed_score = clamp(1 - p95_ms / SLA_MS, 0, 1)
freshness_score = exp(-age_s / FRESH_TTL_S)
```

`SLA_MS` and `FRESH_TTL_S` are per-source. Sources with `score <
0.3` are flagged `degraded` and planners (24) avoid them.

## 8. Cost model

Per source:

- Fixed cost per call (e.g., Hunter: $0.01 per email check).
- Variable cost per KB (e.g., Shodan: per-result size).
- Per-call cents (passed through to Stripe billing).
- Monthly cap (e.g., VirusTotal: free tier 4 req/min, 500/day).

The cost model drives:

- 31-COST-CONTROLLER pre-flight.
- 24-PLANNER cost estimates.
- 31 free-tier optimization.

## 9. Browser requirements

Some sources require JavaScript execution:

- LinkedIn profiles (logged-in).
- Twitter/X timelines.
- Some gov records portals.
- Most captcha-protected sites.

Marked `browser_required=True` in registry. Planner only schedules
them for tenants with browser enabled.

## 10. Proxy requirements

Some sources block datacenter IPs:

- Instagram, TikTok → residential or mobile.
- Some e-commerce price scrapers → residential.
- Most public-record sources → datacenter OK.

Marked `proxy_types` per source. Proxy manager (21) selects
appropriately.

## 11. Supported entity types

Each source declares which entity kinds it can produce:

```yaml
source_id: shodan
entity_kinds:
  - ip
  - domain
  - asn
  - service
```

The planner (24) uses this for fast selection.

## 12. Output schema versions

Every source has a versioned output schema:

```yaml
source_id: shodan
output_schema_version: 3
schema_url: https://docs.argus.saas/schemas/shodan/v3.json
```

When the plugin updates its output format, the version is
incremented. Consumers (extractor, scorer) check version
compatibility.

```python
@dataclass(slots=True, frozen=True)
class OutputSchema:
    source_id: str
    version: int
    fields: tuple[str, ...]
    example: dict[str, Any]
    json_schema_url: str
```

Old consumers handle multiple versions; new consumers must
declare a `min_schema_version` per source.

## 13. Maintenance lifecycle

```yaml
maintenance_status:
  state: active             # active|limited|stale|unmaintained
  last_commit_at: 2026-06-15
  open_issues: 3
  maintainer_team: argus/plugins-team
```

State transitions:

```
   active ──► limited ──► stale ──► unmaintained
       │          │          │             │
       └──► deprecated (any state) ──► retired
```

- **active**: maintained, issues addressed in < 7 days.
- **limited**: maintained but slow (issues > 30 days).
- **stale**: no commits in 6 months, issues accumulating.
- **unmaintained**: author unresponsive or unavailable.

The Planner (24) down-weights sources with state ≥ stale by 30%.

## 14. Deprecation strategy

When a source must be retired (provider gone, license lost, bad
data quality):

1. Mark `deprecation.deprecated_at = now`.
2. Set `sunset_at = now + 90 days`.
3. Specify `replacement_source_id` if available.
4. Plugin still runs but emits `plugin.warning` event on each
   invocation.
5. Bot surfaces "this source is being retired; consider <X>"
   message.
6. After `sunset_at`, `source_registry.deprecation.sunset` is
   enforced: new investigations cannot include this source.
7. After 90 more days, source is removed from registry; old
   `plugin_run` rows still reference the source_id for audit.

## 15. Built-in sources

V1 ships these first-party sources:

| Source ID | Entity kinds | Cost | Browser | Notes |
|-----------|--------------|------|---------|-------|
| `argus.whois` | domain | free | no | RDAP-based |
| `argus.dns` | domain, subdomain | free | no | DoH resolver |
| `argus.dns_subdomain_enum` | subdomain | free | no | public CT logs + wordlist |
| `argus.http_crawl` | domain, person, company | free | yes | generic HTTP + extract |
| `argus.cert_transparency` | domain, subdomain | free | no | crt.sh |
| `argus.email_verify` | email | free | no | SMTP RCPT TO |
| `argus.breach_aggregator` | email, username | free | no | public breach lists |
| `argus.social_x` | person, company | free | yes | X/Twitter |
| `argus.github` | username | free | yes | GitHub profile |
| `argus.reddit` | username | free | yes | Reddit |
| `argus.ip_geo` | ip | free | no | MaxMind GeoLite2 |
| `argus.asn` | ip | free | no | Team Cymru DNS |
| `argus.crypto_btc` | crypto | free | no | blockchain.info |
| `argus.reverse_image` | image | free | yes | Google Lens, Yandex |
| `argus.public_records_eu` | person, company | free | no | OpenCorporates EU |
| `shodan` | ip, domain, asn, service | paid | no | Shodan API |
| `censys` | ip, domain, cert | paid | no | Censys API |
| `hunter` | email | paid | no | Hunter.io |
| `virustotal` | domain, ip, hash | paid | no | VirusTotal |
| `haveibeenpwned` | email | paid | no | HIBP |
| `twilio_lookup` | phone | paid | no | Twilio |
| `clearbit` | company, person | paid | yes | Clearbit |

## 16. Discovery

API:

```
GET /v1/sources
GET /v1/sources/{source_id}
GET /v1/sources?kind=domain&capability=domain.whois
GET /v1/sources?maintenance=stale
```

Response includes `SourceSpec` plus `reliability_score` snapshot.

## 17. Verification

A nightly Celery beat task verifies each active source:

- Check that the plugin is installed.
- Run a smoke test (one cheap call) and update
  `source_reliability_history`.
- Alert if reliability drops below 0.3.

For paid sources without credentials for our test tenant, we skip
the smoke test (mark `last_verified_at` only).

## 18. Failure modes

| Failure | Detection | Recovery |
|---------|-----------|----------|
| Plugin uninstalled but source still in registry | registry check | mark source `unavailable`; alert |
| Auth credentials missing | runtime raises | source marked `no_auth`; not used |
| Rate limit hit on source | 429 response | backoff + circuit breaker |
| Source returns malformed output | schema mismatch | record error; reliability drops |
| Source becomes unavailable | consecutive failures | quarantine 24h; alert |
| Replacement source not installed | deprecation check | block deprecation; alert admin |

## 19. Security

- Auth secrets never in the registry. Only secret names.
- Plugin binary verified per 33-PLUGIN-RUNTIME §13.
- Source capabilities declared; cannot bypass at runtime.
- Registry updates are tenant-scoped (no cross-tenant mutation).
- Smoke tests use a low-privilege service account.

## 20. Abuse prevention

- Per-tenant rate against shared sources (default 30/min).
- Sources marked `commercial_only` not available to free tier.
- Smoke tests run on a separate rate-limited service tenant.
- Audit log for every `register/update/deprecate` action.

## 21. Scalability

- Registry is small: ~100 sources V1.
- `source_reliability_history` is large; partitioned monthly.
- GIN indexes on `entity_kinds` and `capabilities_required`
  make selection O(10) for typical queries.
- Reload is O(sources); < 100 ms.

## 22. Free-tier / Termux compatibility

- Free tier: free sources only.
- Termux: all free sources work; paid sources require API keys.

## 23. Configuration

```bash
ARGUS_SOURCE_REGISTRY_REFRESH_INTERVAL_S=300
ARGUS_SOURCE_REGISTRY_VERIFY_BATCH_SIZE=20
ARGUS_SOURCE_REGISTRY_RELIABILITY_WINDOW_DAYS=30
ARGUS_SOURCE_REGISTRY_DEGRADED_THRESHOLD=0.3
ARGUS_SOURCE_REGISTRY_QUARANTINE_THRESHOLD=0.2
```

## 24. Trade-offs and rationale

| Decision | Rationale | Trade-off |
|----------|-----------|-----------|
| Registry as DB table | Easy admin | One more table |
| Reliability score in registry | Single source of truth | Updated continuously |
| 90-day deprecation | Industry norm | More state to track |
| Per-source schema version | Forward compat | Plugin authors must update |

## 25. References

- [07-PLUGIN-SDK.md](07-PLUGIN-SDK.md) — Plugin authoring
- [33-PLUGIN-RUNTIME.md](33-PLUGIN-RUNTIME.md) — Plugin execution
- [21-PROXY-MANAGER.md](21-PROXY-MANAGER.md) — Proxy needs
- [20-BROWSER-MANAGER.md](20-BROWSER-MANAGER.md) — Browser needs
- [24-PLANNER.md](24-PLANNER.md) — Source selection
- [31-COST-CONTROLLER.md](31-COST-CONTROLLER.md) — Cost model
- [32-OBSERVABILITY.md](32-OBSERVABILITY.md) — Reliability tracking
- [35-WORKFLOW-ENGINE.md](35-WORKFLOW-ENGINE.md) — Source usage
