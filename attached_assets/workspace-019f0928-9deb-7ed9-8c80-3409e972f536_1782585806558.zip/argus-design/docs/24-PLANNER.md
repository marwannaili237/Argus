# 24 — Planner

> Query planner (for repeated / scheduled investigations) and
> investigation planner (initial run). Produces execution plans
> (DAGs) from a target + plugin catalog. Pure domain logic with a
> worker-side execution adapter.

---

## 0. Two planners, one model

- **Investigation planner** — first run. Given `(target, plugins)`,
  produce a DAG of plugin tasks to run.
- **Query planner** — subsequent runs. Given `(target, prior_state)`,
  decide what's new and what can be skipped.

Both share the same `Plan` and `PlanStep` types. The Query Planner
adds a `skip_reason` to each step.

## 1. Position

```
       API / Scheduler (28) / Bot
                  │
                  ▼
        ┌──────────────────────┐
        │  Planner (24)        │   Pure domain
        │  - InvestigationPlanner
        │  - QueryPlanner      │
        └─────────┬────────────┘
                  │ Plan (DAG)
                  ▼
        ┌──────────────────────┐
        │  Worker (06)         │   Executes DAG
        └─────────┬────────────┘
                  │
                  ▼
        Evidence + Entities + Graph (23)
```

Planner lives in `domain/investigation/planner/`. It does **no** I/O
beyond reading the plugin manifest (which is loaded via DI).

## 2. Inputs

```python
@dataclass(slots=True, frozen=True)
class PlanInputs:
    target: Target                          # domain/investigations/target.py
    installed_plugins: tuple[PluginRef, ...]
    options: PlanOptions
    prior_state: PriorState | None           # for query planner

@dataclass(slots=True, frozen=True)
class PluginRef:
    name: str
    version: str
    capabilities: tuple[str, ...]
    cost_estimate: int                      # credits

@dataclass(slots=True, frozen=True)
class PlanOptions:
    max_evidence: int = 1000
    max_duration_s: int = 600
    risk_tolerance: Literal["low","medium","high"] = "medium"
    plugins_required: tuple[str, ...] = ()  # user-mandated
    plugins_forbidden: tuple[str, ...] = ()
    deep_scan: bool = False

@dataclass(slots=True, frozen=True)
class PriorState:
    investigation_id: UUID | None
    last_run_at: datetime | None
    known_entities: tuple[EntityKey, ...]
    known_evidence_hashes: tuple[bytes, ...]
```

## 3. Output

```python
@dataclass(slots=True, frozen=True)
class Plan:
    plan_id: UUID
    investigation_id: UUID
    steps: tuple[PlanStep, ...]
    total_cost_estimate: int
    estimated_duration_s: float
    created_at: datetime

@dataclass(slots=True, frozen=True)
class PlanStep:
    step_id: UUID
    plugin: PluginRef
    inputs: dict[str, Any]
    depends_on: tuple[UUID, ...]             # step_ids
    timeout_s: float
    retry_policy: RetryPolicy
    cost_estimate: int
    skip_reason: str | None = None           # only for query planner

@dataclass(slots=True, frozen=True)
class RetryPolicy:
    max_retries: int
    backoff_base_s: float
    backoff_max_s: float
    retry_on: tuple[str, ...]                # error class names
```

## 4. Algorithm — Investigation planner

```
1. Filter plugins:
   - Remove plugins not in tenant's installations.
   - Remove plugins in `plugins_forbidden`.
   - Keep plugins in `plugins_required`.
   - For optional plugins, select based on target.kind:
       domain → [whois, dns, http_crawl, certificate_transparency]
       email  → [email_hunt, breach_search, social_x]
       person → [social_x, breach_search, public_records]
       ip     → [ip_geolocation, asn_lookup, reverse_dns]
       company→ [whois, dns, http_crawl, employee_search]
       username → [social_x, breach_search]
   - Cap at 12 plugins max.

2. Compute dependency graph:
   - DNS depends on nothing.
   - WHOIS depends on nothing.
   - HTTP crawl depends on DNS (for subdomain discovery).
   - Certificate transparency depends on nothing.
   - Breach search depends on email_hunt (need email first).
   - Relationship extraction (built-in) depends on all scrapers.

3. Compute parallel groups (topological levels):
   - Level 0: independent (whois, dns, ct).
   - Level 1: depends on Level 0 (http_crawl uses dns subdomains).
   - Level 2: depends on Level 1 (breach search needs email_hunt results).

4. Estimate cost per step:
   - Read from plugin manifest `[plugin.cost]`.
   - Default: 1 credit per step; deep_scan adds 5.

5. Estimate duration:
   - Per-step timeout (default plugin.timeout).
   - Plus parallel slack: max(steps in level) + levels × slack_s.

6. If total_cost > tenant budget (31) → reject with QuotaExceeded.

7. If estimated_duration > options.max_duration_s → trim optional
   plugins by cost descending until under limit.
```

## 5. Algorithm — Query planner

```
1. If no prior_state → use Investigation planner.
2. Else:
   a. For each candidate plugin step:
      - If plugin output is purely deterministic (WHOIS re-fetch
        after 24h) → include.
      - If plugin output depends on time (`as_of` parameter) →
        include with input updated.
      - If plugin output is fully cached (input unchanged → same
        output) and prior evidence exists → SKIP with
        skip_reason="cache_valid".
   b. For "freshness-required" plugins:
      - Compare prior evidence timestamps to last_run_at.
      - If older than plugin.freshness_max_age_s → include.
   c. For "delta detection" plugins (28):
      - Re-run, then diff against prior state.
3. Apply same cost/duration caps as Investigation planner.
```

The Query Planner emits `PlanStep.skip_reason` for skipped steps so
the audit trail records what was considered and why it wasn't run.

## 6. Plugin selection — detailed rules

```yaml
# Plugin selection matrix (in code, not YAML)
selectors:
  domain:
    primary: [whois, dns, certificate_transparency]
    secondary: [http_crawl, subdomain_brute]
    optional: [breach_search, social_x_company]
  email:
    primary: [email_hunt, breach_search]
    secondary: [social_x_email]
    optional: [public_records]
  ip:
    primary: [ip_geolocation, asn_lookup, reverse_dns]
    secondary: [shodan, censys]
  person:
    primary: [social_x, breach_search]
    secondary: [public_records, company_affiliations]
    optional: [sanctions, pep]
  company:
    primary: [whois, dns, http_crawl]
    secondary: [employee_search, social_x_company]
  username:
    primary: [social_x, breach_search]
    secondary: [github, gitlab]
```

`optional` plugins run only when:
- Deep scan enabled.
- Cost budget has slack.
- Risk tolerance allows.

## 7. Dependency graph — examples

### 7.1 Domain target

```
  whois ──────────────────────┐
  dns   ──┬── http_crawl      │
          └── subdomain_brute ─┤
  ct      ─────────────────────┤
                               ▼
                    (relationship extraction)
```

### 7.2 Email target

```
  email_hunt ──┬── breach_search
               └── social_x_email
                                │
                                ▼
                    (relationship extraction)
```

## 8. Cost estimation

```python
def estimate_cost(plan: Plan) -> int:
    return sum(s.cost_estimate for s in plan.steps if s.skip_reason is None)
```

Per plugin, cost = base + (bytes_expected / GB) * cost_per_gb.

We assume average bytes from past runs of that plugin (cached in
`plugin.cost_history` materialized view).

## 9. Timeout strategy

- `timeout_s` per step = `min(plugin.timeout, options.max_duration_s / 4)`.
- Plan total = `sum(level_max_timeout for level in levels) + 60s` slack.
- If exceeds `options.max_duration_s`, trim non-required steps.

## 10. Retry policies

Default:

```python
RetryPolicy(
    max_retries=3,
    backoff_base_s=2.0,
    backoff_max_s=60.0,
    retry_on=("PluginTransientError","UpstreamUnavailableError","ConnectError","TimeoutException"),
)
```

Plugin manifest may override `retry.policy`. Planner respects
override but caps `max_retries ≤ 5`.

## 11. Result aggregation

Worker emits events; the Planner is not involved at execution time.
But the `Plan` is referenced by the resulting evidence/entities so
analysts can see why each step ran.

After execution:

```
PlanRunReport {
    plan_id
    started_at
    finished_at
    steps_total
    steps_succeeded
    steps_failed
    steps_skipped
    total_cost
    total_duration_s
    evidence_count
    entity_count
    relationship_count
}
```

Stored as `investigation.plan_run_report` row.

## 12. Failure modes

| Failure | Detection | Recovery |
|---------|-----------|----------|
| Plugin manifest missing | load raises | reject plan |
| Cycle in dependency graph | topo sort raises | reject plan |
| Cost > tenant budget | precheck | reject plan with QuotaExceeded |
| All optional plugins trimmed | count == 0 | run with required only |
| Tenant changed since plan creation | check at execution | re-plan |
| Plugin disabled since plan creation | check at execution | skip step |

## 13. State diagram — plan lifecycle

```
   requested ──► planning ──► ready ──► executing ──► done
                    │           │           │
                    │           │           └──► partial
                    └─► rejected (cost/cycle/disallowed)
```

## 14. Sequence diagram — first-run investigation

```
User / Bot          API         Planner      Worker       Plugin
    │                │             │            │             │
    │ POST           │             │            │             │
    │ /investigations│             │            │             │
    ├───────────────►│             │            │             │
    │                │ build PlanInputs          │             │
    │                ├────────────►│             │             │
    │                │             │ plan = ...  │             │
    │                │ ◄───────────┤             │             │
    │                │ cost-check  │             │             │
    │                │ persist plan│             │             │
    │                ├────────────►│             │             │
    │                │ enqueue chord│            │             │
    │                ├─────────────────────────►│             │
    │ 202            │             │             │ dispatch    │
    │ ◄──────────────┤             │             ├────────────►│
    │                │             │             │ evidence    │
    │                │             │             │ ◄───────────┤
    │                │             │             │ persist     │
    │                │             │             │ extract     │
    │                │             │             │ graph       │
    │                │             │ chord body  │             │
    │                │             │ ◄───────────┤             │
    │                │ emit events │             │             │
```

## 15. Sequence diagram — scheduled re-run

```
Scheduler          API        QueryPlanner   Worker
    │               │             │             │
    │ tick          │             │             │
    ├──────────────►│             │             │
    │               │ build PlanInputs(prior)   │
    │               ├────────────►│             │
    │               │             │ diff vs prior│
    │               │             │ plan (with skips)│
    │               │ ◄───────────┤             │
    │               │ enqueue     │             │
    │               ├─────────────────────────►│
    │               │             │             │
```

## 16. Public interface versioning

The `Plan` schema is versioned. New fields bump schema version;
removals bump major.

```python
PLAN_SCHEMA_VERSION = "1.0"

class Plan(BaseModel):
    schema_version: Literal["1.0"] = "1.0"
    ...
```

Workers refuse to execute a `Plan` whose `schema_version` is older
than the engine's minimum supported. Older plans are re-planned.

## 17. Scalability

- Planner is pure, O(plugins × targets). For 12 plugins and one
  target: < 1 ms.
- Plan storage: ~10 KB per plan. 1M investigations = 10 GB.
  Negligible.
- Query planner diffing: O(prior evidence) for cache_validity
  check. With prior capped at 1000 hashes, < 5 ms.

## 18. Security

- Plans never include secrets.
- Plugin manifests verified before use (07-PLUGIN-SDK.md).
- `plugins_required` from API request is rate-limited per tenant.
- Plans are tenant-scoped.

## 19. Configuration

```bash
ARGUS_PLANNER_MAX_PLUGINS=12
ARGUS_PLANNER_DEFAULT_TIMEOUT_S=120
ARGUS_PLANNER_DEFAULT_RETRIES=3
ARGUS_PLANNER_DEEP_SCAN_COST_BONUS=5
ARGUS_PLANNER_SCHEMA_MIN_VERSION=1.0
```

## 20. Trade-offs and rationale

| Decision | Rationale | Trade-off |
|----------|-----------|-----------|
| Pure domain planner | Easy to test, reuse | Has to be reimplemented if framework changes |
| Skip in plan, not silent | Audit trail | More events |
| Cost pre-flight | Prevents surprise overruns | Can't use dynamic pricing |
| Plugin manifest caps retries | Avoid runaway | Less plugin-specific tuning |

## 21. References

- [06-WORKERS.md](06-WORKERS.md) — Execution
- [07-PLUGIN-SDK.md](07-PLUGIN-SDK.md) — Plugin manifest
- [23-INVESTIGATION-GRAPH.md](23-INVESTIGATION-GRAPH.md) — Result model
- [25-NORMALIZATION.md](25-NORMALIZATION.md) — Normalizes entities
- [26-EVIDENCE-SCORING.md](26-EVIDENCE-SCORING.md) — Confidence
- [28-SCHEDULER.md](28-SCHEDULER.md) — Triggers re-runs
- [31-COST-CONTROLLER.md](31-COST-CONTROLLER.md) — Budgets
