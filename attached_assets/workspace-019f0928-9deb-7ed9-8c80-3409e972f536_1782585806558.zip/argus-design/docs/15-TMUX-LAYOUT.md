# 15 — tmux Session Layout

## 0. Goal

A single tmux session `argus` that contains all four dev services
(API, Bot, Worker, Beat) plus interactive shells for editing,
testing, and tailing logs — restartable from a single script.

## 1. The session

```
┌──────────────────────────────────────────────────────────────────────────┐
│  argus [dev]  ● api ● bot ● worker ● beat   2026-06-27 10:00  termux       │
├──────────────────────────────────────────────────────────────────────────┤
│                                                                          │
│  Window 0: api                                                          │
│  ┌────────────────────────────────────┬─────────────────────────────┐   │
│  │ uvicorn argus_api.main:app         │ tail -f logs/api.log | jq -C │   │
│  │ --reload --port 8080               │                             │   │
│  │                                    │                             │   │
│  │ INFO:  Uvicorn running on :8080    │ 2026-06-27T10:00:00 INFO api │   │
│  │ INFO:  Application startup complete│ request.completed method=PO │   │
│  │                                    │ ST path=/v1/investigations  │   │
│  │ > POST /v1/investigations          │ status=202 duration_ms=42   │   │
│  │ < 202 Accepted                     │                             │   │
│  │                                    │                             │   │
│  └────────────────────────────────────┴─────────────────────────────┘   │
│                                                                          │
│  Window 1: bot                                                           │
│  ┌────────────────────────────────────┬─────────────────────────────┐   │
│  │ python -m argus_bot               │ tail -f logs/bot.log | jq -C  │   │
│  │                                    │                             │   │
│  │ [aiogram] Bot started as @argus... │ update.received update_id=42 │   │
│  │ [aiogram] Polling started          │ handler.completed handler=... │   │
│  │                                    │                             │   │
│  └────────────────────────────────────┴─────────────────────────────┘   │
│                                                                          │
│  Window 2: worker                                                        │
│  ┌────────────────────────────────────┬─────────────────────────────┐   │
│  │ celery -A argus_worker worker      │ tail -f logs/worker.log      │   │
│  │ --loglevel=INFO -c 4               │                             │   │
│  │                                    │ task.start task=argus.plugin│   │
│  │ celery@termux ready.               │ .run args=[...]              │   │
│  │ [queues]                           │ task.completed duration=...  │   │
│  │ > ctrl                             │                             │   │
│  │ > plugins                          │                             │   │
│  │ > evidence,entity,relationship     │                             │   │
│  │ > export,billing,maintenance       │                             │   │
│  └────────────────────────────────────┴─────────────────────────────┘   │
│                                                                          │
│  Window 3: beat                                                           │
│  ┌────────────────────────────────────┬─────────────────────────────┐   │
│  │ celery -A argus_worker beat        │ tail -f logs/beat.log        │   │
│  │ --loglevel=INFO                    │                             │   │
│  │                                    │ beat: Starting...            │   │
│  │ Scheduler: Sending due task        │ beat: Ticked                 │   │
│  │   argus.billing.reset_daily_quotas │                             │   │
│  └────────────────────────────────────┴─────────────────────────────┘   │
│                                                                          │
│  Window 4: shell                                                          │
│  ┌────────────────────────────────────┬─────────────────────────────┐   │
│  │ $ source .venv/bin/activate        │ $ ./scripts/test.sh          │   │
│  │ (.venv) $                          | collected 42 items           │   │
│  │ (.venv) $ ./scripts/migrate.sh     | passed in 3.14s              │   │
│  │                                    |                              │   │
│  └────────────────────────────────────┴─────────────────────────────┘   │
│                                                                          │
│  Window 5: edit                                                           │
│  ┌────────────────────────────────────────────────────────────────────┐  │
│  │ nvim services/api/src/argus_api/routers/investigations.py         │   │
│  │                                                                    │   │
│  └────────────────────────────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────────────────────────────┘
```

## 2. Status line

Configured in `~/.tmux.conf` (we provide `configs/tmux.conf`):

```tmux
set -g status-interval 5
set -g status-left-length 80
set -g status-left  "#[fg=green]#S #[fg=white]| #[fg=yellow]argus"
set -g status-right "#[fg=cyan]%Y-%m-%d %H:%M #[fg=white]| #[fg=magenta]#h"

# Service health dots
set -g status-right "#[fg=green]● api #[fg=yellow]● bot #[fg=blue]● worker #[fg=red]● beat | %Y-%m-%d %H:%M"
```

Health dots are driven by `scripts/service-health.sh` (see below).

## 3. tmux.conf (committed to repo)

```tmux
# configs/tmux.conf — Argus dev session
# Source this with: tmux -f configs/tmux.conf

# ── General ───────────────────────────────────────────────────────
set -g default-terminal "tmux-256color"
set -ga terminal-overrides ',xterm-256color:Tc'
set -g mouse on
set -g history-limit 50000
set -g base-index 1
setw -g pane-base-index 1
set -g renumber-windows on

# ── Bindings ──────────────────────────────────────────────────────
unbind C-b
set -g prefix C-a
bind C-a send-prefix

bind h select-pane -L
bind j select-pane -D
bind k select-pane -U
bind l select-pane -R

bind r source-file ~/.tmux.conf \; display "reloaded"

bind , split-window -h -c "#{pane_current_path}"
bind . split-window -v -c "#{pane_current_path}"

bind 0 select-window -t :0
bind 1 select-window -t :1
bind 2 select-window -t :2
bind 3 select-window -t :3
bind 4 select-window -t :4
bind 5 select-window -t :5

# ── Status ────────────────────────────────────────────────────────
set -g status-interval 5
set -g status-justify left
set -g status-bg colour234
set -g status-fg white

# Health indicator (filled in by scripts/tmux-health.sh)
set -g status-right-length 100
set-option -g status-right "#(bash scripts/tmux-health.sh) | %Y-%m-%d %H:%M"
```

## 4. The startup script

```bash
#!/usr/bin/env bash
# scripts/tmux-dev.sh
set -euo pipefail
cd "$(dirname "$0")/.."

SESSION="${ARGUS_TMUX_SESSION:-argus}"
ROOT="$(pwd)"
LOG_DIR="$ROOT/logs"
mkdir -p "$LOG_DIR"

ensure_log() { : > "$LOG_DIR/$1.log"; }

start_or_attach() {
    if tmux has-session -t "$SESSION" 2>/dev/null; then
        tmux attach -t "$SESSION"
        return
    fi
    tmux new-session -d -s "$SESSION" -x 200 -y 50 -n api -c "$ROOT"

    # Window 1: api
    ensure_log api
    tmux send-keys -t "$SESSION:1" \
        "source .venv/bin/activate && \
         exec uvicorn argus_api.main:app --reload --port 8080 2>&1 | tee logs/api.log" C-m
    tmux split-window -h -t "$SESSION:1" -c "$ROOT"
    tmux send-keys -t "$SESSION:1.right" \
        "tail -F logs/api.log | jq -C" C-m

    # Window 2: bot
    ensure_log bot
    tmux new-window -t "$SESSION" -n bot -c "$ROOT"
    tmux send-keys -t "$SESSION:2" \
        "source .venv/bin/activate && \
         exec python -m argus_bot 2>&1 | tee logs/bot.log" C-m
    tmux split-window -h -t "$SESSION:2" -c "$ROOT"
    tmux send-keys -t "$SESSION:2.right" \
        "tail -F logs/bot.log | jq -C" C-m

    # Window 3: worker
    ensure_log worker
    tmux new-window -t "$SESSION" -n worker -c "$ROOT"
    tmux send-keys -t "$SESSION:3" \
        "source .venv/bin/activate && \
         exec celery -A argus_worker.celery_app worker -l INFO -c 4 \
         -Q ctrl,plugins,evidence,entity,relationship,export,billing,maintenance \
         2>&1 | tee logs/worker.log" C-m
    tmux split-window -h -t "$SESSION:3" -c "$ROOT"
    tmux send-keys -t "$SESSION:3.right" \
        "tail -F logs/worker.log | jq -C" C-m

    # Window 4: beat
    ensure_log beat
    tmux new-window -t "$SESSION" -n beat -c "$ROOT"
    tmux send-keys -t "$SESSION:4" \
        "source .venv/bin/activate && \
         exec celery -A argus_worker.celery_app beat -l INFO \
         2>&1 | tee logs/beat.log" C-m
    tmux split-window -h -t "$SESSION:4" -c "$ROOT"
    tmux send-keys -t "$SESSION:4.right" \
        "tail -F logs/beat.log | jq -C" C-m

    # Window 5: shell + tests
    tmux new-window -t "$SESSION" -n shell -c "$ROOT"
    tmux send-keys -t "$SESSION:5" \
        "source .venv/bin/activate && clear" C-m
    tmux split-window -h -t "$SESSION:5" -c "$ROOT"
    tmux send-keys -t "$SESSION:5.right" \
        "source .venv/bin/activate && clear" C-m

    # Window 6: edit
    tmux new-window -t "$SESSION" -n edit -c "$ROOT"
    tmux send-keys -t "$SESSION:6" \
        "source .venv/bin/activate && nvim ." C-m

    tmux select-window -t "$SESSION:1"
    tmux attach -t "$SESSION"
}

case "${1:-start}" in
  start) start_or_attach ;;
  stop)  tmux kill-session -t "$SESSION" 2>/dev/null || true ;;
  status) tmux list-sessions | grep "^$SESSION:" || echo "not running" ;;
  *) echo "Usage: $0 {start|stop|status}"; exit 1 ;;
esac
```

## 5. Service health dot

```bash
# scripts/tmux-health.sh
#!/usr/bin/env bash
# Prints colored dots indicating which services are up.
# Used in tmux status-right.

probe() {
    local name="$1" url="$2"
    if curl -fsS -m 1 "$url" >/dev/null 2>&1; then
        printf "#[fg=green]● %s" "$name"
    else
        printf "#[fg=red]○ %s" "$name"
    fi
}

parts=()
parts+=( "$(probe api http://localhost:8080/health)" )
parts+=( "#[fg=yellow]$(probe bot tcp://localhost:8081)" )  # bot has /health on its own port
parts+=( "#[fg=blue]$(probe worker tcp://localhost:8082)" )
parts+=( "#[fg=magenta]$(probe beat tcp://localhost:8083)" )

IFS=' '; echo "${parts[*]}"
```

## 6. Window / pane focus cheatsheet

| Key | Action |
|-----|--------|
| `Ctrl-a 1` … `Ctrl-a 6` | Switch window (api, bot, worker, beat, shell, edit) |
| `Ctrl-a h j k l` | Move pane left/down/up/right |
| `Ctrl-a ,` | Split horizontal |
| `Ctrl-a .` | Split vertical |
| `Ctrl-a d` | Detach (session keeps running) |
| `Ctrl-a [` | Copy mode |
| `Ctrl-a r` | Reload tmux.conf |
| `Ctrl-a x` | Kill pane (with confirmation) |

## 7. Window 5 (shell) conventions

Left pane: REPL and one-off commands.
Right pane: test runner on watch.

```bash
# Right pane: tests on change
source .venv/bin/activate
ptw -- ./scripts/test.sh tests/  # pytest-watch
```

Install `ptw` (`uv add --dev pytest-watch`).

## 8. Logging

Each pane sends its service stdout to `logs/<service>.log` via
`tee`. We also have a side pane `tail -F logs/<service>.log | jq -C`
so we never lose a line.

`tee` + `tail -F` ensures:
- Live view in the pane.
- Persistent file even after pane scrolls.
- File readable by external tools.

## 9. Restarting a single service

```bash
# From the tmux shell pane
tmux send-keys -t argus:1 C-c   # kill current command
tmux send-keys -t argus:1 \
    "exec uvicorn argus_api.main:app --reload --port 8080" C-m
```

Or use the alias `rapi`:

```bash
alias rapi='tmux send-keys -t argus:1 C-c; \
            tmux send-keys -t argus:1 \
              "exec uvicorn argus_api.main:app --reload --port 8080" C-m'
```

## 10. Connecting to remote services

If Postgres / Redis are remote, the dev panes still work — only the
URLs in `.env` change.

```bash
# .env
DATABASE_URL=postgresql+asyncpg://...@ep-xyz.neon.tech/argus?sslmode=require
ARGUS_REDIS_URL=rediss://default:...@us1-xyz.upstash.io:6379
```

No additional tmux setup.

## 11. CI parity

The same `scripts/dev.sh api` etc. used in tmux is what CI runs.
Same flags, same env. We don't maintain a separate CI script.

## 12. Plugins pane (optional)

For plugin authors, an extra window:

```
Window 7: plugin-dev
   - left:  nvim plugins/plugin_dns
   - right: tail -F logs/plugin-test.log
```

Started via `scripts/tmux-dev.sh plugins`.

## 13. Stop / cleanup

```bash
./scripts/tmux-dev.sh stop   # kill session
# or
tmux kill-session -t argus
```

Logs persist in `logs/`. Old logs rotate via `scripts/rotate-logs.sh`:

```bash
#!/usr/bin/env bash
# scripts/rotate-logs.sh
for f in logs/*.log; do
    [ -f "$f" ] || continue
    if [ "$(stat -c %s "$f")" -gt 10485760 ]; then
        mv "$f" "$f.$(date +%Y%m%d-%H%M%S)"
        gzip "$f".* || true
        ls -1t "$f".*.gz 2>/dev/null | tail -n +11 | xargs -r rm --
    fi
done
```

## 14. Disaster: tmux session lost

```bash
# Recover running processes
ps aux | grep -E 'uvicorn|argus_bot|celery' | grep -v grep

# Reattach if session exists
tmux ls
tmux attach -t argus

# If session is gone, processes may still be running.
# Kill them and restart.
pkill -f 'uvicorn argus_api' || true
pkill -f 'python -m argus_bot' || true
pkill -f 'celery -A argus_worker' || true
./scripts/tmux-dev.sh start
```

## 15. Termux caveats

- `Ctrl-a` may conflict with Android keybindings. Use `Ctrl-b` (the
  default) if you prefer.
- Mouse mode in tmux over Termux works via `Termux:API` and the
  Bluetooth/wired mouse. On touchscreen, no mouse.
- Tmux on Termux before 0.30 had stability issues. Install latest:
  `pkg upgrade tmux`.

## 16. Session script summary

| Command | Effect |
|---------|--------|
| `./scripts/tmux-dev.sh start` | Start or attach |
| `./scripts/tmux-dev.sh stop` | Kill session |
| `./scripts/tmux-dev.sh status` | List sessions |
| `tmux attach -t argus` | Attach manually |
| `tmux kill-session -t argus` | Hard kill |

## 17. Why this layout

- One keystroke (`Ctrl-a 1`) to reach any service.
- Service + log side-by-side: never context-switch to debug.
- Edit + test side-by-side: TDD-friendly.
- `tail -F` survives log rotation.
- All four services in **one tmux** so detach/reattach preserves
  state. Phone screen real estate used efficiently.
