# 04 — API Specification

## 0. Style

- **REST + JSON**, OpenAPI 3.1.
- **Versioned** in URL: `/v1/...`. Breaking changes → `/v2/...`.
- **HTTPS only**. HSTS header on all responses.
- **JWT** for end-users (bot), **API key** for programmatic clients.
- **Cursor pagination** on all collections (keyset, not offset).
- **RFC 7807** problem+json on errors.
- **Idempotency-Key** header on POST that creates resources.
- **Rate-Limit headers** on every response (`X-RateLimit-Limit`,
  `X-RateLimit-Remaining`, `X-RateLimit-Reset`).

## 1. Auth

### `POST /v1/auth/telegram`

Exchange Telegram Login Widget `initData` for JWT.

Request:

```json
{
  "init_data": "query_id=...&user=...&auth_date=...&hash=..."
}
```

Response `200`:

```json
{
  "access_token": "eyJ...",
  "refresh_token": "d4e5f6...",
  "token_type": "Bearer",
  "expires_in": 900,
  "user": {
    "id": "uuid",
    "telegram_id": 12345678,
    "username": "alice",
    "full_name": "Alice",
    "tenant_id": "uuid",
    "role": "owner",
    "plan": "free"
  }
}
```

Errors:

- `400 invalid_init_data` — bot token mismatch or expired.
- `403 user_blocked` — tenant deactivated.

### `POST /v1/auth/refresh`

```json
{ "refresh_token": "d4e5f6..." }
```

Rotates. Old refresh is revoked. Reuse of revoked token revokes entire
session family.

### `POST /v1/auth/api-key`

Machine-to-machine. Trade API key for short-lived JWT.

```json
{ "api_key": "argus_live_xxxxxxxx..." }
```

Returns same shape as Telegram login.

### `POST /v1/auth/logout`

Revoke current refresh family.

## 2. Users

### `GET /v1/users/me`

```json
{
  "id": "uuid",
  "tenant_id": "uuid",
  "telegram_id": 12345678,
  "email": null,
  "username": "alice",
  "full_name": "Alice",
  "role": "owner",
  "locale": "en",
  "plan": "free",
  "quotas": {
    "investigations_per_month": 20,
    "investigations_used": 7,
    "investigations_remaining": 13,
    "concurrent_running": 1,
    "export_max_mb": 25
  },
  "created_at": "2026-01-01T00:00:00Z"
}
```

### `PATCH /v1/users/me`

```json
{
  "locale": "ru",
  "email": "alice@example.com",
  "full_name": "Alice Smith"
}
```

### `DELETE /v1/users/me`

Schedules GDPR purge. Returns `202` with `purge_id`.

### `GET /v1/users/me/api-keys`

List (no secrets).

### `POST /v1/users/me/api-keys`

```json
{ "name": "CI bot", "scopes": ["investigations:read","investigations:write"] }
```

Returns plaintext key **once**: `"key": "argus_live_xxxxxxxx"`.

### `DELETE /v1/users/me/api-keys/{id}`

Revoke.

## 3. Investigations

### `POST /v1/investigations`

`Idempotency-Key` recommended.

```json
{
  "title": "Scan example.com",
  "target": {
    "kind": "domain",
    "value": "example.com",
    "meta": { "tld_guess": ["example.org","example.net"] }
  },
  "plugins": ["whois", "dns", "http_crawl"],
  "options": {
    "max_evidence": 1000,
    "max_duration_s": 600,
    "deep_scan": false
  }
}
```

Response `202`:

```json
{
  "id": "uuid",
  "status": "pending",
  "title": "Scan example.com",
  "target": { "kind": "domain", "value": "example.com" },
  "progress_pct": 0,
  "evidence_count": 0,
  "entity_count": 0,
  "relationship_count": 0,
  "created_at": "2026-06-27T10:00:00Z",
  "links": {
    "self": "/v1/investigations/uuid",
    "evidence": "/v1/investigations/uuid/evidence",
    "entities": "/v1/investigations/uuid/entities",
    "relationships": "/v1/investigations/uuid/relationships",
    "events": "/v1/investigations/uuid/events"
  }
}
```

Errors:

- `400 invalid_target` — value doesn't match kind.
- `402 quota_exceeded` — out of monthly investigations.
- `409 idempotency_conflict` — different payload with same key.
- `429 rate_limited`.

### `GET /v1/investigations`

Query params: `status`, `cursor`, `limit` (default 20, max 100),
`q` (free-text search on title and target.value).

```json
{
  "items": [ { "id": "uuid", ... } ],
  "next_cursor": "eyJpZCI6IjAwMCJ9",
  "has_more": true
}
```

### `GET /v1/investigations/{id}`

Full detail including progress.

### `POST /v1/investigations/{id}/pause`

### `POST /v1/investigations/{id}/resume`

### `POST /v1/investigations/{id}/cancel`

Cancels running plugin tasks, sets status `cancelled`. Idempotent.

### `GET /v1/investigations/{id}/events`

Server-Sent Events stream of investigation events. Bot uses this for
progress. Filters: `types=evidence.found,entity.found,status.changed`.

SSE message example:

```
event: evidence.found
id: 123
data: {"id":"uuid","kind":"dns_record","summary":{"host":"api.example.com"},"at":"2026-06-27T10:00:01Z"}
```

### `GET /v1/investigations/{id}/timeline`

Chronological list of significant events.

### `GET /v1/investigations/{id}/graph`

Returns Graphviz `dot` source for client rendering (bot converts to
PNG via headless `dot`).

## 4. Evidence

### `GET /v1/investigations/{id}/evidence`

Query: `cursor`, `limit`, `kind`, `plugin`, `since`, `until`.

### `GET /v1/evidence/{id}`

Full evidence with raw inline (if small) and signed download URL for
blob (if large).

### `POST /v1/investigations/{id}/evidence`

Used by plugins running in worker process via internal API key. Not
exposed to end-users. Body:

```json
{
  "plugin_run_id": "uuid",
  "kind": "dns_record",
  "source_url": null,
  "summary": { "host": "api.example.com", "type": "A", "value": "1.2.3.4" },
  "raw": null,
  "confidence": 1.0,
  "blob": {
    "content_type": "application/json",
    "content_b64": "eyJ..."
  }
}
```

If `blob` is present, API stores it in object store and sets
`storage_key`.

## 5. Entities & Relationships

### `GET /v1/investigations/{id}/entities`

Query: `type`, `cursor`, `limit`, `q`.

```json
{
  "items": [
    {
      "id": "uuid",
      "type": "domain",
      "value": "example.com",
      "aliases": ["example.com","example.com."],
      "attributes": { "registrar": "Reseller" },
      "first_seen_at": "2026-06-27T10:00:00Z",
      "last_seen_at": "2026-06-27T10:00:05Z",
      "evidence_count": 3
    }
  ],
  "next_cursor": "...",
  "has_more": true
}
```

### `GET /v1/investigations/{id}/relationships`

Query: `from`, `to`, `kind`.

### `GET /v1/entities/{id}/related`

BFS up to depth N (default 1, max 3).

## 6. Plugins

### `GET /v1/plugins`

Catalog. No auth required (public).

```json
{
  "items": [
    {
      "name": "whois",
      "description": "RDAP/WHOIS lookup",
      "version": "1.2.0",
      "target_kinds": ["domain","ip"],
      "required_caps": ["http"],
      "is_official": true,
      "icon_url": "..."
    }
  ]
}
```

### `GET /v1/plugins/{name}`

Full detail with manifest.

### `GET /v1/installations`

Per-tenant installed plugins.

### `POST /v1/installations`

```json
{ "plugin_name": "dns", "version": "1.0.0", "config": {} }
```

### `DELETE /v1/installations/{plugin_name}`

### `PATCH /v1/installations/{plugin_name}`

```json
{ "enabled": false, "config": { "...": "..." } }
```

## 7. Exports

### `POST /v1/investigations/{id}/exports`

```json
{ "format": "pdf", "options": { "include_raw": false } }
```

Response `202`:

```json
{
  "id": "uuid",
  "format": "pdf",
  "status": "pending",
  "expires_at": "2026-07-04T10:00:00Z",
  "links": { "self": "/v1/exports/uuid" }
}
```

### `GET /v1/exports/{id}`

Returns `status`, `size_bytes`, `download_url` when `ready`.

### `GET /v1/exports/{id}/download`

302 redirect to signed R2 URL. Valid for 5 minutes; re-fetch the
export to get a new URL.

## 8. Billing

### `GET /v1/billing/plans`

```json
{
  "items": [
    {
      "code": "free",
      "name": "Free",
      "monthly_price_cents": 0,
      "limits": {
        "investigations_per_month": 20,
        "concurrent_running": 1,
        "evidence_per_investigation": 1000,
        "export_max_mb": 25
      }
    },
    {
      "code": "pro",
      "name": "Pro",
      "monthly_price_cents": 1900,
      "limits": {
        "investigations_per_month": 500,
        "concurrent_running": 5,
        "evidence_per_investigation": 10000,
        "export_max_mb": 250
      }
    }
  ]
}
```

### `POST /v1/billing/checkout`

```json
{ "plan_code": "pro" }
```

Response:

```json
{ "checkout_url": "https://checkout.stripe.com/..." }
```

### `POST /v1/billing/webhook`

Stripe webhook receiver. Signature verified. Idempotent.

### `GET /v1/billing/subscription`

Current subscription.

### `POST /v1/billing/cancel`

## 9. Webhooks (outbound, future)

`POST /v1/webhooks` — register a URL to receive investigation events.
Optional in V1; plan for V2.

## 10. Health

### `GET /health`

Liveness. Always 200 unless process is broken.

### `GET /ready`

Readiness. Checks DB, Redis, object store.

```json
{
  "status": "ok",
  "checks": {
    "postgres": { "ok": true, "latency_ms": 12 },
    "redis": { "ok": true, "latency_ms": 3 },
    "object_store": { "ok": true, "latency_ms": 35 }
  },
  "version": "1.2.3",
  "commit": "a1b2c3d"
}
```

### `GET /metrics`

Prometheus format.

## 11. Common error format (RFC 7807)

```json
{
  "type": "https://docs.argus.saas/errors/invalid_target",
  "title": "Invalid target",
  "status": 400,
  "detail": "Domain value must match RFC 1035 hostname pattern",
  "instance": "/v1/investigations",
  "request_id": "uuid",
  "errors": [
    { "field": "target.value", "code": "pattern_mismatch", "message": "..." }
  ]
}
```

## 12. Error codes

Standard HTTP semantics. Plus argus-specific:

| Code | HTTP | Meaning |
|------|------|---------|
| `invalid_input` | 400 | Validation failed |
| `unauthenticated` | 401 | Missing/invalid token |
| `forbidden` | 403 | Not allowed by RBAC |
| `not_found` | 404 | Resource gone |
| `conflict` | 409 | State conflict |
| `idempotency_conflict` | 409 | Same key, different payload |
| `quota_exceeded` | 402 | Plan limit hit |
| `rate_limited` | 429 | Bucket empty |
| `upstream_unavailable` | 502 | Plugin upstream failed |
| `service_unavailable` | 503 | Internal failure |
| `internal_error` | 500 | Bug |

## 13. Idempotency

POST that creates a resource accepts `Idempotency-Key: <uuid>`.

- Same key + same payload within 24h → returns original response.
- Same key + different payload → `409 idempotency_conflict`.
- Stored in `identity.idempotency` table:

```sql
CREATE TABLE identity.idempotency (
    key          UUID PRIMARY KEY,
    user_id      UUID NOT NULL REFERENCES identity."user"(id) ON DELETE CASCADE,
    method       TEXT NOT NULL,
    path         TEXT NOT NULL,
    payload_hash BYTEA NOT NULL,
    response     JSONB NOT NULL,
    status_code  SMALLINT NOT NULL,
    created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    expires_at   TIMESTAMPTZ NOT NULL
);
CREATE INDEX idempotency_expires_idx ON identity.idempotency (expires_at);
```

Cleanup: Celery beat job deletes rows past `expires_at`.

## 14. Rate limits

Per-token bucket. Limits (default):

| Scope | Limit |
|-------|-------|
| Anonymous | 60 req/min |
| Authenticated | 600 req/min |
| Auth + write | 120 req/min |
| Investigation create | 6 req/min |
| Export create | 2 req/min |

Implementation: Redis token bucket via Lua script. Returns
`Retry-After` header on 429.

## 15. OpenAPI generation

`fastapi` generates `/openapi.json`. We commit `docs/openapi.json`
on every release. The CI test
`services/api/tests/contract/test_openapi.py` asserts no breaking
change vs. the previous tag without a `/v2` bump.

## 16. API versioning policy

- Additive (new optional field, new endpoint) → minor bump, no
  version bump.
- New required field, new required header, removed field → major
  bump, new `/v2` prefix.
- Old versions are supported for **6 months** after deprecation
  announcement.

## 17. CORS

- Browsers don't matter for V1 (no web client), but we set:
  - `Access-Control-Allow-Origin: *` for `/health`, `/ready`.
  - No CORS on `/v1` (bots only).
- Future web admin will get a tight allowlist.

## 18. Request lifecycle (full HTTP path)

1. Cloudflare terminates TLS.
2. Uvicorn accepts, parses HTTP.
3. Middleware order:
   1. `correlation_id` — generate or accept `X-Request-ID`.
   2. `security_headers` — set baseline.
   3. `errors` — install `Exception` handler that emits RFC 7807.
   4. `auth` — extract token, validate JWT, attach `user`.
   5. `ratelimit` — consume token; 429 if empty.
   6. `request_log` — log entry/exit.
4. Router dispatches to use case.
5. Use case coordinates domain + repos + bus + queue.
6. Response goes back through middleware in reverse.

Each step writes one structured log line with the same
`request_id` so a single request is fully traceable in Loki.
