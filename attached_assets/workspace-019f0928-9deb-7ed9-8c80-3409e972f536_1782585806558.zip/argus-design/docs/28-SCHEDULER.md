# 28 — Scheduler

> Watchlists, continuous monitoring, scheduled investigations,
> delta detection, alert generation, queue priorities, retry
> policies, and failure recovery. Worker-driven, Celery beat-driven.

---

## 0. Position

```
   Admin / User           API             Scheduler (28)        Worker
       │                   │                    │                  │
       │ POST watchlist    │                    │                  │
       ├──────────────────►│                    │                  │
       │                   │ persist watchlist  │                  │
       │                   │ register trigger   │                  │
       │                   ├───────────────────►│                  │
       │                   │                    │ (beat tick)      │
       │                   │                    │ dispatch         │
       │                   │                    ├─────────────────►│
       │                   │                    │                  │
       │                   │                    │   run planner    │
       │                   │                    │   diff baseline  │
       │                   │                    │   enqueue        │
       │                   │                    │                  │
       │                   │   events           │                  │
       │                   │ ◄──────────────────┴──────────────────┤
       │   alert           │                    │                  │
       │ ◄─────────────────┤                    │                  │
```

## 1. Watchlists

A `Watchlist` is a persistent collection of targets to monitor.

```sql
CREATE TABLE investigation.watchlist (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id       UUID NOT NULL REFERENCES identity.tenant(id) ON DELETE CASCADE,
    owner_id        UUID NOT NULL REFERENCES identity."user"(id),
    title           TEXT NOT NULL,
    description     TEXT,
    interval_s      INT NOT NULL,           -- 3600 = hourly
    enabled         BOOLEAN NOT NULL DEFAULT TRUE,
    plugins         TEXT[] NOT NULL,
    options         JSONB NOT NULL DEFAULT '{}',
    last_run_at     TIMESTAMPTZ,
    next_run_at     TIMESTAMPTZ NOT NULL,
    consecutive_failures INT NOT NULL DEFAULT 0,
    paused_until    TIMESTAMPTZ,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT watchlist_interval_chk CHECK (interval_s >= 60)
);
CREATE INDEX watchlist_next_run_idx
    ON investigation.watchlist (enabled, next_run_at)
    WHERE enabled = TRUE;
```

A watchlist contains zero or more **entries** (individual targets):

```sql
CREATE TABLE investigation.watchlist_entry (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    watchlist_id    UUID NOT NULL REFERENCES investigation.watchlist(id) ON DELETE CASCADE,
    target_kind     TEXT NOT NULL,
    target_value    TEXT NOT NULL,
    notes           TEXT,
    enabled         BOOLEAN NOT NULL DEFAULT TRUE,
    last_seen_at    TIMESTAMPTZ,
    last_changed_at TIMESTAMPTZ,
    UNIQUE (watchlist_id, target_kind, target_value)
);
```

## 2. Lifecycle — watchlist

```
   created ──► active ──► running ──► idle
                │           │          │
                │           │          └──► next_run_at reached
                │           │              └► running again
                │           └──► alerting (delta detected)
                └──► paused (manual / consecutive_failures)
                     │
                     └──► disabled (admin)
                     └──► deleted (GDPR)
```

## 3. Watchlist tick

Celery beat task runs every minute:

```python
@shared_task(name="argus.scheduler.tick")
def tick():
    due = WatchlistRepo.list_due(now=datetime.now(UTC))
    for w in due:
        if w.paused_until and w.paused_until > now:
            continue
        dispatch_watchlist.delay(str(w.id))
```

`dispatch_watchlist` then:

```python
@shared_task(name="argus.scheduler.dispatch_watchlist",
             bind=True, max_retries=2)
def dispatch_watchlist(self, watchlist_id: str):
    watchlist = WatchlistRepo.get(watchlist_id)
    try:
        # Schedule a sub-investigation per entry
        for entry in watchlist.entries:
            if not entry.enabled:
                continue
            investigation = InvestigationRepo.create_for_watchlist(
                watchlist, entry,
                title=f"{watchlist.title}: {entry.target_value}",
            )
            # Use Query Planner with prior state
            prior = InvestigationRepo.find_last_for_target(
                entry.target_kind, entry.target_value)
            plan = QueryPlanner.plan(target, prior, ...)
            for step in plan.steps:
                if step.skip_reason:
                    continue
                run_plugin.delay(str(investigation.id), ...)
    except Exception as e:
        watchlist.consecutive_failures += 1
        if watchlist.consecutive_failures >= 5:
            watchlist.paused_until = now + timedelta(hours=1)
            watchlist.consecutive_failures = 0
            audit.write("watchlist.auto_paused", ...)
        raise self.retry(exc=e)
    finally:
        watchlist.last_run_at = now
        watchlist.next_run_at = now + timedelta(seconds=watchlist.interval_s)
```

## 4. Delta detection

After each watchlist investigation completes, we diff against the
previous run's baseline.

```python
def detect_delta(investigation_id: str) -> list[Delta]:
    new = InvestigationRepo.get(investigation_id)
    prev = InvestigationRepo.get_last_for_target(new.target)
    if prev is None:
        return [Delta(kind="baseline_created", investigation_id=new.id)]

    deltas: list[Delta] = []
    # Evidence deltas
    new_hashes = {e.content_sha256 for e in new.evidence_list}
    prev_hashes = {e.content_sha256 for e in prev.evidence_list}
    deltas.append(Delta(kind="evidence_added",
                        count=len(new_hashes - prev_hashes)))
    deltas.append(Delta(kind="evidence_removed",
                        count=len(prev_hashes - new_hashes)))
    # Entity deltas
    new_entities = {(e.type, e.value) for e in new.entities}
    prev_entities = {(e.type, e.value) for e in prev.entities}
    deltas.append(Delta(kind="entity_added",
                        count=len(new_entities - prev_entities)))
    deltas.append(Delta(kind="entity_removed",
                        count=len(prev_entities - new_entities)))
    # Relationship deltas
    new_rels = {(r.from_entity_id, r.to_entity_id, r.kind) for r in new.rels}
    prev_rels = {(r.from_entity_id, r.to_entity_id, r.kind) for r in prev.rels}
    deltas.append(Delta(kind="relationship_added",
                        count=len(new_rels - prev_rels)))
    return deltas
```

### 4.1 Delta storage

Deltas are persisted:

```sql
CREATE TABLE investigation.delta (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    watchlist_id    UUID NOT NULL REFERENCES investigation.watchlist(id) ON DELETE CASCADE,
    investigation_id UUID NOT NULL REFERENCES investigation.investigation(id) ON DELETE CASCADE,
    previous_investigation_id UUID,
    kind            TEXT NOT NULL,
    count           INT NOT NULL DEFAULT 1,
    sample          JSONB,           -- e.g. up to 10 changed entities
    detected_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT delta_kind_chk CHECK (kind IN (
        'baseline_created','evidence_added','evidence_removed',
        'entity_added','entity_removed',
        'relationship_added','relationship_removed',
        'whois_changed','dns_changed'
    ))
);
CREATE INDEX delta_watchlist_idx
    ON investigation.delta (watchlist_id, detected_at DESC);
```

### 4.2 Alert thresholds

Watchlist defines thresholds:

```json
{
  "alert_on": ["entity_added", "evidence_added"],
  "min_count": 1,
  "ignore_kinds": ["breach_entry"]
}
```

When delta exceeds threshold, an alert fires.

## 5. Alert generation

```python
@shared_task(name="argus.scheduler.evaluate_alerts")
def evaluate_alerts(delta_id: str):
    delta = DeltaRepo.get(delta_id)
    watchlist = WatchlistRepo.get(delta.watchlist_id)
    if not watchlist_alerts_match(watchlist, delta):
        return
    # Find subscribers
    for sub in watchlist.subscribers:
        if sub.channel == "telegram":
            bot.send_message(sub.telegram_id, format_alert(watchlist, delta))
        elif sub.channel == "email":
            send_email(sub.email, ...)
        elif sub.channel == "webhook":
            http_post(sub.url, payload, ...)
```

### 5.1 Subscribers

```sql
CREATE TABLE investigation.watchlist_subscriber (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    watchlist_id    UUID NOT NULL REFERENCES investigation.watchlist(id) ON DELETE CASCADE,
    user_id         UUID REFERENCES identity."user"(id) ON DELETE CASCADE,
    telegram_id     BIGINT,
    email           CITEXT,
    webhook_url     TEXT,
    webhook_secret  TEXT,           -- HMAC secret
    channels        TEXT[] NOT NULL DEFAULT '{}',
    quiet_hours_start TIME,
    quiet_hours_end   TIME,
    min_interval_s  INT DEFAULT 300,  -- rate limit per subscriber
    enabled         BOOLEAN NOT NULL DEFAULT TRUE
);
```

### 5.2 Quiet hours

If subscriber has quiet hours and alert falls inside, queue the
alert and deliver at end of quiet hours (batched).

### 5.3 Rate limit per subscriber

`min_interval_s` enforces a floor between consecutive alerts. If
delta rate exceeds, alerts are coalesced.

## 6. Scheduled investigations (one-shot)

For "investigate this in 1 hour" without watchlist semantics:

```sql
CREATE TABLE investigation.scheduled (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id       UUID NOT NULL REFERENCES identity.tenant(id),
    user_id         UUID NOT NULL REFERENCES identity."user"(id),
    target_kind     TEXT NOT NULL,
    target_value    TEXT NOT NULL,
    plugins         TEXT[] NOT NULL,
    options         JSONB NOT NULL DEFAULT '{}',
    run_at          TIMESTAMPTZ NOT NULL,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    fired_at        TIMESTAMPTZ,
    result_investigation_id UUID REFERENCES investigation.investigation(id)
);
CREATE INDEX scheduled_due_idx
    ON investigation.scheduled (run_at) WHERE fired_at IS NULL;
```

Same `tick` task picks these up.

## 7. Queue priorities

Watchlist and scheduled tasks go to a dedicated queue
`argus.scheduler` with priority 4 (below interactive, above
maintenance). Within the queue, `run_at` is FIFO.

## 8. Retry policies

| Failure | Retry | Backoff |
|---------|-------|---------|
| Worker transient | yes | 2^n + jitter, max 60s |
| Plugin transient | per-plugin policy | (delegated) |
| Database down | yes | 30s |
| Watchlist consecutive failures ≥ 5 | auto-pause 1h | none |
| Auto-pause hits 3 times in 24h | disable + alert admin | none |

## 9. Failure recovery

```python
def on_watchlist_failure(watchlist, error):
    watchlist.consecutive_failures += 1
    if watchlist.consecutive_failures == 5:
        watchlist.paused_until = now + timedelta(hours=1)
        audit.write("watchlist.auto_paused", watchlist_id=watchlist.id)
    elif watchlist.consecutive_failures >= 10:
        watchlist.enabled = False
        audit.write("watchlist.disabled", watchlist_id=watchlist.id)
        alert_admin("watchlist.disabled", ...)
```

Manual recovery: user un-pauses via `/resume` (or API).

## 10. Sequence diagram — full tick

```
Beat             Scheduler.tick   Dispatch    Worker          Planner      Storage
  │                  │              │            │              │            │
  │ tick             │              │            │              │            │
  ├─────────────────►│              │            │              │            │
  │                  │ list_due     │            │              │            │
  │                  │              │            │              │            │
  │                  │ dispatch(w1) │            │              │            │
  │                  ├─────────────►│            │              │            │
  │                  │ dispatch(w2) │            │              │            │
  │                  ├─────────────►│            │              │            │
  │                  │              │ run_plugin │              │            │
  │                  │              ├───────────►│              │            │
  │                  │              │            │ plan         │            │
  │                  │              │            ├─────────────►│            │
  │                  │              │            │ deltas       │            │
  │                  │              │            │ ◄────────────┤            │
  │                  │              │            │ persist      │            │
  │                  │              │            ├───────────────────────────►│
  │                  │              │ evidence  │              │            │
  │                  │              │ ◄─────────┤              │            │
  │                  │              │            │ events       │            │
  │                  │              │            ├─────────────►│            │
```

## 11. State diagram — alert lifecycle

```
   detected ──► evaluated ──► dispatched ──► delivered
       │            │             │
       └──► suppressed (threshold)│
                    │             │
                    └──► throttled └─► queued
```

## 12. Public interface

```python
class SchedulerService(Protocol):
    async def create_watchlist(self, request: CreateWatchlistRequest) -> Watchlist: ...
    async def update_watchlist(self, id: UUID, request: UpdateWatchlistRequest) -> Watchlist: ...
    async def delete_watchlist(self, id: UUID) -> None: ...
    async def pause_watchlist(self, id: UUID, until: datetime | None) -> None: ...
    async def resume_watchlist(self, id: UUID) -> None: ...
    async def trigger_now(self, id: UUID) -> None: ...
    async def list_deltas(self, id: UUID, since: datetime) -> list[Delta]: ...
```

API endpoints (extends 04-API-SPEC):

```
POST   /v1/watchlists
GET    /v1/watchlists
GET    /v1/watchlists/{id}
PATCH  /v1/watchlists/{id}
DELETE /v1/watchlists/{id}
POST   /v1/watchlists/{id}/pause
POST   /v1/watchlists/{id}/resume
POST   /v1/watchlists/{id}/trigger
GET    /v1/watchlists/{id}/deltas
```

## 13. Failure modes

| Failure | Detection | Recovery |
|---------|-----------|----------|
| Scheduler tick missed | `last_run_at` too old | alert; manual trigger |
| Too many watchlists running | queue depth > threshold | throttle dispatch |
| Investigation produced no delta | every time | log; no alert |
| Subscribers unreachable | send fails | retry with backoff; mark failed |
| Quiet hours overflow | > 50 queued alerts | send summary instead |
| Beat process down | no ticks | restart beat; investigations unaffected |

## 14. Security

- Watchlists are tenant-scoped.
- Subscribers can only be added by users with `watchlist:write`
  scope.
- Webhook URLs are HMAC-signed.
- Webhook secrets are encrypted at rest.
- Alert contents honor evidence redaction rules.

## 15. Scalability

- 1M investigations / day = ~30k active watchlists (avg 30-day
  interval) → tick processes ~20 / second → trivial.
- Delta comparison is O(new + prev) per investigation, < 1 s for
  typical sizes.
- Alert dispatch is async; high fan-out doesn't block.

## 16. Free-tier compatibility

- Free tier: max 3 active watchlists per tenant.
- Free tier: max 1 alert channel per watchlist.
- Free tier: alerts are throttled to 10/day per watchlist.

## 17. Configuration

```bash
ARGUS_SCHEDULER_TICK_INTERVAL_S=60
ARGUS_SCHEDULER_MAX_CONSECUTIVE_FAILURES=5
ARGUS_SCHEDULER_AUTO_PAUSE_HOURS=1
ARGUS_SCHEDULER_AUTO_DISABLE_THRESHOLD=10
ARGUS_SCHEDULER_DELTA_ALERT_DEFAULT_KINDS=entity_added,evidence_added
```

## 18. Trade-offs and rationale

| Decision | Rationale | Trade-off |
|----------|-----------|-----------|
| Watchlist separate from scheduled | Different semantics | Two tables |
| Per-watchlist tick instead of batched | Easier retry per watchlist | Slight overhead |
| Quiet hours + rate limit | Don't spam users | Alerts may be delayed |
| Auto-pause on failures | Avoid alert storms | Manual recovery |
| Delta persisted | Audit trail | Storage growth |

## 19. References

- [24-PLANNER.md](24-PLANNER.md) — Plan generation
- [06-WORKERS.md](06-WORKERS.md) — Execution
- [23-INVESTIGATION-GRAPH.md](23-INVESTIGATION-GRAPH.md) — Delta subjects
- [29-EXPORT-PIPELINE.md](29-EXPORT-PIPELINE.md) — Alert exports
- [10-QUEUE-DESIGN.md](10-QUEUE-DESIGN.md) — Queue topology
