# 16 — Bash Helper Scripts

## 0. Why bash scripts, not Makefile

- Termux has bash, not always `make` (and `make` is unfamiliar to
  many).
- Bash scripts are easy to read and modify.
- They compose: a script can call other scripts.
- They work on macOS, Linux, proot-Debian, and Termux unchanged.
- They can be sourced to set env, not just executed.

We provide a complete `scripts/` directory.

## 1. Directory

```
scripts/
├── termux-bootstrap.sh     # one-time Termux setup
├── dev.sh                  # dev command router
├── serve.sh                # run API alone
├── bot.sh                  # run bot alone
├── worker.sh               # run worker alone
├── beat.sh                 # run beat alone
├── migrate.sh              # alembic wrapper
├── seed.sh                 # insert plan + plugin catalog
├── test.sh                 # pytest wrapper
├── lint.sh                 # ruff + mypy
├── format.sh               # auto-fix
├── typecheck.sh            # mypy only
├── tmux-dev.sh             # start full dev session
├── tmux-health.sh          # status dot printer
├── check-bot-boundaries.sh # CI guard for bot purity
├── deploy.sh               # deploy to staging/production
├── drain-dlq.sh            # manual DLQ drain
├── rotate-logs.sh          # log rotation
├── tail-logs.sh            # tail a service log
├── notify.sh               # Termux notification
└── wait-for.sh             # poll until a URL responds
```

## 2. `dev.sh` — the central router

```bash
#!/usr/bin/env bash
# scripts/dev.sh — central dev command router
set -euo pipefail
cd "$(dirname "$0")/.."

CMD="${1:-help}"; shift || true

ensure_venv() {
    [ -d .venv ] || uv venv --python 3.12 .venv
}

ensure_env() {
    [ -f .env ] || cp .env.example .env
}

case "$CMD" in
    bootstrap)
        ensure_venv
        ensure_env
        source .venv/bin/activate
        uv sync --all-extras
        uv run pre-commit install
        echo "✅ Bootstrap complete. Run: ./scripts/tmux-dev.sh start"
        ;;
    api)        exec scripts/serve.sh "$@" ;;
    bot)        exec scripts/bot.sh "$@" ;;
    worker)     exec scripts/worker.sh "$@" ;;
    beat)       exec scripts/beat.sh "$@" ;;
    migrate)    exec scripts/migrate.sh "$@" ;;
    test)       exec scripts/test.sh "$@" ;;
    lint)       exec scripts/lint.sh "$@" ;;
    format)     exec scripts/format.sh "$@" ;;
    typecheck)  exec scripts/typecheck.sh "$@" ;;
    seed)       exec scripts/seed.sh "$@" ;;
    shell)      source .venv/bin/activate && exec uv run python ;;
    ipython)    source .venv/bin/activate && exec uv run ipython ;;
    help|-h|--help)
        cat <<EOF
Argus dev script.

Usage: scripts/dev.sh <command> [args]

Commands:
  bootstrap    Install deps, generate .env, set up pre-commit
  api          Run API (uvicorn --reload)
  bot          Run bot
  worker       Run Celery worker
  beat         Run Celery beat
  migrate      Alembic (upgrade|downgrade|current|heads|revision)
  test         pytest with sane defaults
  lint         ruff + mypy
  format       ruff format (auto-fix)
  typecheck    mypy only
  seed         Insert plans + plugin catalog
  shell        Python REPL
  ipython      IPython REPL
EOF
        ;;
    *)
        echo "Unknown command: $CMD" >&2
        exit 1
        ;;
esac
```

## 3. Service scripts

### `serve.sh`

```bash
#!/usr/bin/env bash
# scripts/serve.sh
set -euo pipefail
cd "$(dirname "$0")/.."
source .venv/bin/activate

PORT="${PORT:-8080}"
HOST="${HOST:-0.0.0.0}"
WORKERS="${WORKERS:-1}"

if [ "$WORKERS" -gt 1 ]; then
    exec uvicorn argus_api.main:app \
        --host "$HOST" --port "$PORT" \
        --workers "$WORKERS" \
        --no-access-log
else
    exec uvicorn argus_api.main:app \
        --host "$HOST" --port "$PORT" \
        --reload
fi
```

### `bot.sh`

```bash
#!/usr/bin/env bash
# scripts/bot.sh
set -euo pipefail
cd "$(dirname "$0")/.."
source .venv/bin/activate

MODE="${1:-polling}"

case "$MODE" in
    polling)  exec python -m argus_bot ;;
    webhook)
        PORT="${PORT:-8081}"
        exec python -m argus_bot --webhook "$PORT"
        ;;
    *) echo "Usage: $0 {polling|webhook}"; exit 1 ;;
esac
```

### `worker.sh`

```bash
#!/usr/bin/env bash
# scripts/worker.sh
set -euo pipefail
cd "$(dirname "$0")/.."
source .venv/bin/activate

CONCURRENCY="${CONCURRENCY:-4}"
QUEUES="${QUEUES:-ctrl,plugins,evidence,entity,relationship,export,billing,maintenance}"

exec celery -A argus_worker.celery_app worker \
    --loglevel="${LOG_LEVEL:-INFO}" \
    --concurrency="$CONCURRENCY" \
    -Q "$QUEUES" \
    --max-tasks-per-child=200 \
    --max-memory-per-child=512000
```

### `beat.sh`

```bash
#!/usr/bin/env bash
# scripts/beat.sh
set -euo pipefail
cd "$(dirname "$0")/.."
source .venv/bin/activate

exec celery -A argus_worker.celery_app beat \
    --loglevel="${LOG_LEVEL:-INFO}" \
    --schedule=/tmp/celerybeat-schedule
```

## 4. `migrate.sh`

```bash
#!/usr/bin/env bash
# scripts/migrate.sh
set -euo pipefail
cd "$(dirname "$0")/.."
source .venv/bin/activate

CMD="${1:-help}"; shift || true

case "$CMD" in
    upgrade)
        TARGET="${1:-head}"
        exec alembic -c libs/argus_db/migrations/alembic.ini upgrade "$TARGET"
        ;;
    downgrade)
        TARGET="${1:- -1}"
        exec alembic -c libs/argus_db/migrations/alembic.ini downgrade "$TARGET"
        ;;
    current)
        exec alembic -c libs/argus_db/migrations/alembic.ini current
        ;;
    heads)
        exec alembic -c libs/argus_db/migrations/alembic.ini heads
        ;;
    revision)
        MSG="${1:-}"
        [ -n "$MSG" ] || { echo "Usage: $0 revision <message>"; exit 1; }
        exec alembic -c libs/argus_db/migrations/alembic.ini revision --autogenerate -m "$MSG"
        ;;
    history)
        exec alembic -c libs/argus_db/migrations/alembic.ini history --verbose
        ;;
    help|--help|-h)
        cat <<EOF
Usage: migrate.sh <command> [args]

Commands:
  upgrade [target]      Upgrade to target (default: head)
  downgrade [target]    Downgrade (default: -1)
  current               Show current revision
  heads                 Show head revisions
  revision <msg>        Autogenerate a new revision
  history               Show full migration history
EOF
        ;;
    *)
        echo "Unknown: $CMD" >&2; exit 1 ;;
esac
```

## 5. `test.sh`

```bash
#!/usr/bin/env bash
# scripts/test.sh
set -euo pipefail
cd "$(dirname "$0")/.."
source .venv/bin/activate

ARGS=()

# Default: run everything except load tests
if [ $# -eq 0 ]; then
    ARGS=(
        --strict-markers
        --strict-config
        -ra
        -q
        tests/ services/api/tests services/bot/tests services/worker/tests
        -m "not load"
        --cov=argus_api --cov=argus_bot --cov=argus_worker
        --cov=libs --cov=domain
        --cov-report=term-missing
        --cov-fail-under=70
    )
fi

exec pytest "${ARGS[@]}" "$@"
```

Markers:

- `unit` — fast, no I/O.
- `integration` — needs DB and/or Redis.
- `contract` — OpenAPI / event schema.
- `slow` — > 1 s per test.
- `load` — Locust-only; skipped by default.

## 6. `lint.sh` / `format.sh` / `typecheck.sh`

```bash
# scripts/lint.sh
#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
source .venv/bin/activate

echo "==> ruff"
uv run ruff check .
echo "==> mypy"
uv run mypy libs/argus_common libs/argus_db domain
echo "==> import-linter"
uv run lint-imports
echo "✅ lint clean"
```

```bash
# scripts/format.sh
#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
source .venv/bin/activate

uv run ruff check --fix .
uv run ruff format .
```

```bash
# scripts/typecheck.sh
#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
source .venv/bin/activate

uv run mypy --strict libs/argus_common libs/argus_db domain
uv run mypy services/api/src services/bot/src services/worker/src
```

## 7. `seed.sh`

```bash
#!/usr/bin/env bash
# scripts/seed.sh — insert plans and plugin catalog
set -euo pipefail
cd "$(dirname "$0")/.."
source .venv/bin/activate

exec python -m argus_db.seed
```

`argus_db.seed` reads `libs/argus_db/seed/*.yaml` and inserts/updates:

- Default plans (free, pro).
- Plugin catalog entries (whois, dns, http_crawl, social_x).

Uses `INSERT … ON CONFLICT DO UPDATE` so it's idempotent.

## 8. `check-bot-boundaries.sh`

```bash
#!/usr/bin/env bash
# scripts/check-bot-boundaries.sh
# Enforce: bot MUST NOT import SQLAlchemy / asyncpg / celery / redis / plugins.
set -euo pipefail
cd "$(dirname "$0")/.."

FORBIDDEN_REGEX='^(from|import)\s+(sqlalchemy|asyncpg|psycopg|aiosqlite|celery|redis|aiomcache|httpx\..*\.cookies|kafka|nats|pika|kombu|amqp)'

if grep -RnE "$FORBIDDEN_REGEX" services/bot/src; then
    echo "❌ Bot imports infrastructure module — forbidden"
    exit 1
fi

# Bot also MUST NOT import any plugin code
if grep -RnE '^(from|import)\s+argus_(whois|dns|http_crawl|social_x|email_hunt)' services/bot/src; then
    echo "❌ Bot imports plugin code — forbidden"
    exit 1
fi

# Bot MUST NOT import domain directly
if grep -RnE '^(from|import)\s+argus_domain' services/bot/src; then
    echo "❌ Bot imports domain — use API client instead"
    exit 1
fi

echo "✅ Bot boundary OK"
```

## 9. `deploy.sh`

```bash
#!/usr/bin/env bash
# scripts/deploy.sh
set -euo pipefail
cd "$(dirname "$0")/.."

ENV="${1:-staging}"

case "$ENV" in
    staging)
        echo "==> Deploying to staging"
        railway up --service argus-api --environment staging
        railway up --service argus-bot --environment staging
        railway up --service argus-worker --environment staging
        ;;
    production)
        echo "==> Deploying to production"
        railway up --service argus-api --environment production
        railway up --service argus-bot --environment production
        railway up --service argus-worker --environment production
        ;;
    koyeb)
        echo "==> Deploying to Koyeb"
        koyeb deploy -a argus-api ghcr.io/argus-saas/argus:latest \
            --build-arg SERVICE=api
        ;;
    northflank)
        echo "==> Deploying to Northflank"
        northflank deploy --project argus --service argus-api-bot
        northflank deploy --project argus --service argus-worker
        ;;
    *)
        echo "Usage: $0 {staging|production|koyeb|northflank}"
        exit 1
        ;;
esac

echo "✅ Deploy triggered. Watching logs:"
railway logs --service argus-api
```

## 10. `drain-dlq.sh`

```bash
#!/usr/bin/env bash
# scripts/drain-dlq.sh — manually drain Celery DLQ
set -euo pipefail
cd "$(dirname "$0")/.."
source .venv/bin/activate

exec python -m argus_worker.maintenance.drain_dlq --interactive
```

## 11. `wait-for.sh`

```bash
#!/usr/bin/env bash
# scripts/wait-for.sh — poll until URL responds 200
# Usage: wait-for.sh <url> [timeout-seconds]
set -euo pipefail

URL="${1:?usage: wait-for.sh <url> [timeout]}"
TIMEOUT="${2:-60}"

start=$(date +%s)
while true; do
    if curl -fsS -m 2 "$URL" >/dev/null 2>&1; then
        echo "✅ $URL is up"
        exit 0
    fi
    now=$(date +%s)
    if [ $((now - start)) -gt "$TIMEOUT" ]; then
        echo "❌ $URL not up after ${TIMEOUT}s"
        exit 1
    fi
    sleep 1
done
```

## 12. `tmux-health.sh`

```bash
#!/usr/bin/env bash
# scripts/tmux-health.sh — service health dots for tmux status
probe() {
    local name="$1" url="$2"
    if curl -fsS -m 1 "$url" >/dev/null 2>&1; then
        printf "#[fg=green]●%s" "$name"
    else
        printf "#[fg=red]○%s" "$name"
    fi
}

out=""
out+="$(probe api http://localhost:8080/health) "
out+="$(probe bot tcp://localhost:8081) "
out+="$(probe worker tcp://localhost:8082) "
out+="$(probe beat tcp://localhost:8083) "
echo "$out"
```

## 13. `notify.sh`

```bash
#!/usr/bin/env bash
# scripts/notify.sh — Termux notification (uses Termux:API)
# Usage: notify.sh "title" "content"
TITLE="${1:-Argus}"
CONTENT="${2:-}"

if command -v termux-notification >/dev/null 2>&1; then
    termux-notification --title "$TITLE" --content "$CONTENT" --id argus
else
    echo "[notify] $TITLE: $CONTENT"
fi
```

## 14. `rotate-logs.sh`

```bash
#!/usr/bin/env bash
# scripts/rotate-logs.sh
set -euo pipefail
cd "$(dirname "$0")/.."

MAX_SIZE_MB=10
KEEP=10

for f in logs/*.log; do
    [ -f "$f" ] || continue
    size_mb=$(( $(stat -c %s "$f") / 1024 / 1024 ))
    if [ "$size_mb" -gt "$MAX_SIZE_MB" ]; then
        ts=$(date +%Y%m%d-%H%M%S)
        mv "$f" "$f.$ts"
        gzip "$f.$ts"
        # Keep last N
        ls -1t "$f".*.gz 2>/dev/null | tail -n +$((KEEP+1)) | xargs -r rm --
    fi
done
```

## 15. `tail-logs.sh`

```bash
#!/usr/bin/env bash
# scripts/tail-logs.sh <service>
set -euo pipefail
cd "$(dirname "$0")/.."

SERVICE="${1:-api}"
LOG="logs/${SERVICE}.log"
[ -f "$LOG" ] || { echo "no log: $LOG"; exit 1; }

exec tail -F "$LOG" | jq -C -R 'fromjson? // .'
```

## 16. Permissions and execution

```bash
# In termux-bootstrap.sh:
chmod +x scripts/*.sh
```

All scripts are executable. We don't commit with executable bit set
to avoid filesystem weirdness across Windows clones; instead the
bootstrap fixes perms.

## 17. Common patterns

- **`set -euo pipefail`** — fail fast on errors and undefined vars.
- **`cd "$(dirname "$0")/.."`** — anchor to repo root.
- **`source .venv/bin/activate`** — activate venv first.
- **`exec uv run …`** — replace shell process so Ctrl-C reaches
  Python.
- **`case "$CMD" in`** — branching with help text.

## 18. CI usage

GitHub Actions calls the same scripts:

```yaml
- name: Lint
  run: ./scripts/lint.sh

- name: Test
  run: ./scripts/test.sh

- name: Bot boundaries
  run: ./scripts/check-bot-boundaries.sh
```

Same code on Termux, CI, and the developer's laptop. Zero drift.

## 19. What we don't do

- Long pipelines of `&&` chains. Each script does one thing.
- Hardcoded paths. Always use `$ROOT` or repo-relative.
- Background processes without PID files.
- Logs to stdout AND a file with different formats.
- Mixing bash and Python logic (Python stays in `*.py` files).

## 20. Adding a new script

1. Create `scripts/foo.sh`.
2. Shebang `#!/usr/bin/env bash`.
3. `set -euo pipefail`, `cd "$(dirname "$0")/.."`, `source .venv/bin/activate` if Python.
4. Add a line to `scripts/dev.sh` `case` to expose it.
5. Document in this file.
6. Add a CI step if appropriate.
