# 08 — Authentication

## 0. Three identity surfaces

Argus has three ways a request can be authenticated:

1. **Telegram user** (the bot, via Telegram Login Widget).
2. **API key** (CI, third-party integrations, webhooks).
3. **Service-to-service** (worker → API for internal actions).

All three converge on the same **JWT** with the same `ArgusClaims`
payload, signed with **RS256**. Public keys are rotated quarterly;
old keys stay valid for 7 days after rotation (overlap window).

## 1. The claims

```python
# libs/argus_common/auth/jwt.py
from typing import Literal
from datetime import datetime, timedelta, UTC
from uuid import UUID

import jwt
from pydantic import BaseModel, Field

class ArgusClaims(BaseModel):
    iss: Literal["argus.auth"]
    sub: str                       # user_id (uuid string)
    tid: str                       # tenant_id (uuid string)
    aud: Literal["argus.api"]
    exp: int                       # unix timestamp
    iat: int
    jti: str                       # unique token id
    role: Literal["owner", "admin", "member"]
    scopes: list[str] = Field(default_factory=list)
    telegram_id: int | None = None
    plan: Literal["free", "trial", "pro", "team"] = "free"

    @classmethod
    def for_user(cls, user, scopes=None, ttl=900) -> "ArgusClaims":
        now = datetime.now(UTC)
        return cls(
            iss="argus.auth",
            sub=str(user.id),
            tid=str(user.tenant_id),
            aud="argus.api",
            iat=int(now.timestamp()),
            exp=int((now + timedelta(seconds=ttl)).timestamp()),
            jti=str(uuid4()),
            role=user.role,
            scopes=scopes or default_scopes_for(user.role),
            telegram_id=user.telegram_id,
            plan=user.tenant.plan_code,
        )
```

Scopes:

| Scope | Granted to | Allows |
|-------|------------|--------|
| `investigation:read` | member | `GET /v1/investigations*`, evidence, entities |
| `investigation:write` | member | `POST/PATCH /v1/investigations*` |
| `investigation:cancel` | member | `POST /v1/investigations/{id}/cancel` |
| `plugin:read` | member | `GET /v1/plugins`, `/v1/installations` |
| `plugin:write` | admin | `POST/DELETE /v1/installations` |
| `billing:read` | member | `GET /v1/billing/*` |
| `billing:write` | owner | `POST /v1/billing/*` |
| `user:read` | member | `GET /v1/users/me` |
| `user:write` | member | `PATCH /v1/users/me` |
| `apikey:manage` | owner | `* /v1/users/me/api-keys` |
| `admin:all` | owner (tenant) | All of the above + admin |

## 2. Key management

```python
# libs/argus_common/auth/keys.py
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import rsa

def generate_keypair() -> tuple[bytes, bytes]:
    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    private = key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )
    public = key.public_key().public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo,
    )
    return private, public
```

Keys live in:

- **Production**: secrets manager (Railway env, Koyeb env). Private
  key in `ARGUS_JWT_PRIVATE_KEY` (PEM, single-line base64).
- **Public key** in `ARGUS_JWT_PUBLIC_KEY` (PEM). Also served from
  `/.well-known/jwks.json` for external verifiers.
- **Rotation**: 90 days. New key promoted; old key stays in JWKS for
  7 days. Implemented as a list of `(kid, public_pem)`.

## 3. JWKS endpoint

```
GET /.well-known/jwks.json
```

```json
{
  "keys": [
    {
      "kty": "RSA",
      "kid": "2026-04-01",
      "use": "sig",
      "alg": "RS256",
      "n": "base64url-encoded modulus",
      "e": "AQAB"
    },
    {
      "kid": "2026-01-01",
      "use": "sig",
      "alg": "RS256",
      "n": "...",
      "e": "AQAB"
    }
  ]
}
```

Verification uses `kid` header to pick the right key. If `kid` is
unknown, the token is rejected.

## 4. Telegram Login verification

```python
# libs/argus_common/auth/telegram.py
import hashlib
import hmac
import json
import time
from urllib.parse import parse_qsl

from argus_common.errors import InvalidTelegramDataError

def verify_telegram_login(init_data: str, bot_token: str,
                          max_age_seconds: int = 300) -> dict:
    """
    Verifies a Telegram Login Widget initData string per
    https://core.telegram.org/widgets/login
    """
    try:
        parsed = dict(parse_qsl(init_data, strict_parsing=True))
    except ValueError as e:
        raise InvalidTelegramDataError(str(e))

    if "hash" not in parsed:
        raise InvalidTelegramDataError("missing hash")

    received_hash = parsed.pop("hash")
    auth_date = int(parsed.get("auth_date", "0"))
    if time.time() - auth_date > max_age_seconds:
        raise InvalidTelegramDataError("expired")

    data_check_string = "\n".join(
        f"{k}={v}" for k, v in sorted(parsed.items())
    )
    secret_key = hashlib.sha256(bot_token.encode()).digest()
    calculated = hmac.new(secret_key, data_check_string.encode(),
                          hashlib.sha256).hexdigest()
    if not hmac.compare_digest(calculated, received_hash):
        raise InvalidTelegramDataError("bad signature")

    if "user" in parsed:
        parsed["user"] = json.loads(parsed["user"])

    return parsed
```

`initData` comes from the Telegram Login Widget (web) or from
`tg.initData` (Telegram Web Apps / Mini Apps). For pure bot flows,
we use the WebApp signature path or, simpler, an authenticated POST
from bot to API carrying the bot-internal token (HMAC of bot token).

## 5. End-to-end: Telegram user → JWT

```
[Bot]  User clicks /start
       Bot calls api.exchange_telegram_login(initData)
            │
            ▼
[API]  POST /v1/auth/telegram
       1. validate initData with bot token (HMAC + 5-min max age)
       2. upsert user + tenant
       3. issue access + refresh JWT
       4. audit.auth.login
            │
            ▼
[Bot]  Stores tokens encrypted in Redis FSM storage
       Shows main menu
```

If user is brand new, we auto-create a tenant (`slug = "t" + base32(telegram_id)`)
and set plan = `free`.

## 6. Refresh tokens

- **Refresh JWT**: longer TTL (30 days), single-use.
- Stored hashed in `identity.session.refresh_jti`.
- On refresh, old `refresh_jti` is marked revoked; new one issued.
- Reuse of a revoked refresh revokes the **entire session family**
  (defense against token theft).
- Logout revokes all sessions for the user.

```python
# libs/argus_common/auth/refresh.py
def rotate_refresh(user_id: UUID, presented_jti: str) -> tuple[str, str]:
    with session_scope() as s:
        sess = SessionRepo(s).get_by_jti(presented_jti)
        if sess is None or sess.revoked_at is not None:
            # Reuse → revoke all
            SessionRepo(s).revoke_family(user_id)
            raise RefreshReuseDetectedError()
        if sess.expires_at < datetime.now(UTC):
            raise RefreshExpiredError()
        sess.revoked_at = datetime.now(UTC)
        new_sess = SessionRepo(s).create(user_id)
        s.commit()
        return issue_jwt_pair(user_id, refresh_jti=new_sess.refresh_jti)
```

## 7. API key authentication

API keys are for non-Telegram clients. Format:

```
argus_live_<prefix>_<secret>
       ^^^^^^^^^^^^^
       key_prefix (8 chars, displayed in UI)
```

Example: `argus_live_abc12345_aBcD...xyz`.

Server stores only `key_hash = argon2id(secret)`. The full key is
shown to the user **once** at creation.

Auth flow:

```
[Client] Authorization: Bearer argus_live_abc12345_aBcD...xyz
[API]    Lookup by key_prefix → argon2 verify → load user → issue JWT
```

API key exchange gives a short-lived (1 hour) JWT with the key's
scopes baked in.

## 8. Service-to-service (worker → API)

Workers don't call the API; they share `libs/argus_db` directly. The
one exception: the **plugin runner** writes evidence through an
internal API endpoint using a service token:

```
ARGUS_SERVICE_TOKEN = "argus_svc_<random>"
```

Stored hashed. Service tokens have scope `internal:write`.

## 9. FastAPI dependency

```python
# services/api/src/argus_api/deps.py
from typing import Annotated
from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials

from argus_common.auth.jwt import ArgusClaims, decode_jwt
from argus_db.session import session_scope
from argus_db.repositories.user import UserRepo

bearer = HTTPBearer(auto_error=False)

async def current_user(
    creds: Annotated[HTTPAuthorizationCredentials | None, Depends(bearer)],
) -> tuple[ArgusClaims, User]:
    if creds is None or creds.scheme.lower() != "bearer":
        raise HTTPException(401, "unauthenticated")
    try:
        claims = decode_jwt(creds.credentials, audience="argus.api")
    except jwt.PyJWTError as e:
        raise HTTPException(401, "invalid_token")
    with session_scope() as s:
        user = UserRepo(s).get_by_id(UUID(claims.sub))
        if user is None or not user.is_active:
            raise HTTPException(401, "user_inactive")
    return claims, user

CurrentUser = Annotated[tuple[ArgusClaims, User], Depends(current_user)]
CurrentClaims = Annotated[ArgusClaims, Depends(current_user_claims_only)]
```

`require_scopes("investigation:write")` is a small helper used in
routers:

```python
def require_scopes(*required):
    async def dep(user: CurrentUser) -> CurrentUser:
        _, claims_user = user
        if "admin:all" in claims_user[0].scopes:
            return user
        if not all(s in claims_user[0].scopes for s in required):
            raise HTTPException(403, "forbidden")
        return user
    return dep
```

## 10. Bot storage of tokens

The bot stores the refresh token in Redis FSM storage, encrypted at
rest with Fernet:

```python
# services/bot/src/argus_bot/fsm/storage.py
from cryptography.fernet import Fernet
from aiogram.fsm.storage.redis import RedisStorage

class EncryptedTokenStorage:
    def __init__(self, redis, fernet: Fernet):
        self._redis = redis
        self._fernet = fernet

    async def put_token(self, user_id: int, payload: dict) -> None:
        ciphertext = self._fernet.encrypt(
            json.dumps(payload).encode())
        await self._redis.set(f"token:{user_id}", ciphertext, ex=60*60*24*30)

    async def get_token(self, user_id: int) -> dict | None:
        raw = await self._redis.get(f"token:{user_id}")
        if raw is None: return None
        return json.loads(self._fernet.decrypt(raw).decode())

    async def delete_token(self, user_id: int) -> None:
        await self._redis.delete(f"token:{user_id}")
```

`ARGUS_BOT_TOKEN_ENCRYPTION_KEY` is a Fernet key (`base64`). Rotate
by dual-keying for 7 days during overlap (old key first tries, then
new).

## 11. Password handling (web only)

V1 has no web login. Passwords are reserved for the future web
admin. We use **argon2id** with parameters
`time_cost=3, memory_cost=64MB, parallelism=2`. Helpers live in
`libs/argus_common/auth/password.py`.

## 12. Rate limit on auth endpoints

- `/v1/auth/telegram`: 30/min/IP, 10/min/IP per `auth_date`.
- `/v1/auth/refresh`: 60/min/user.
- `/v1/auth/api-key`: 10/min/IP.
- `/v1/auth/logout`: 60/min/user.

These are separate buckets from the main API bucket so abuse on auth
doesn't lock out the user.

## 13. Audit

Every auth event writes to `audit.event`:

| Action | Payload |
|--------|---------|
| `auth.login` | `{method, telegram_id?, api_key_prefix?, ip}` |
| `auth.refresh` | `{jti_old, jti_new}` |
| `auth.logout` | `{session_family}` |
| `auth.failed` | `{reason, ip}` |
| `auth.refresh_reuse` | `{family_revoked_count}` (alert) |

## 14. Threat model

| Threat | Mitigation |
|--------|------------|
| Stolen JWT | Short TTL (15 min); refresh rotation |
| Stolen refresh | Hash at rest; reuse detection |
| Stolen API key | Hash at rest; prefix lookup is fine |
| Bot token leak (HMAC) | Login flows are 5-min max age |
| Telegram impersonation | HMAC verified with bot token |
| MITM on bot↔API | TLS only; JWT signed (not just TLS-protected) |
| Replay | jti uniqueness + Redis tracking |
| Brute force | Argon2id; rate limit; lockout after 5 fails/15min |

## 15. Webhook signature verification (Stripe, future)

```python
def verify_stripe_signature(payload: bytes, header: str, secret: str):
    import stripe
    stripe.api_key = None
    try:
        stripe.Webhook.construct_event(payload, header, secret)
    except stripe.error.SignatureVerificationError as e:
        raise InvalidWebhookSignature(str(e))
```

## 16. Session lifecycle summary

```
/start
   │
   ▼
exchange_telegram_login ──▶ access(15m) + refresh(30d, hashed, stored)
                                              │
   ┌──── auto-refresh in middleware ──────────┘
   │
   ▼
click /logout ──▶ revoke refresh family
                  audit logout
                  bot deletes encrypted token
```

## 17. What is **not** in V1

- OAuth2 / OIDC (no third-party identity providers).
- SAML SSO.
- 2FA / TOTP.
- Passkeys / WebAuthn.
- Login by email + password (Telegram-only for V1).

All four are tracked for V2 and have schema headroom.
