# 09 — Event System

## 0. Why events

A single investigation fans out into dozens of plugin runs, hundreds
of evidence items, dozens of entities, and many relationships. We
need:

- A way for the bot to learn about progress without polling.
- A way for downstream tasks (entity extraction, relationship build)
  to be triggered.
- A way for analytics (dashboard, billing counters) to react.
- A way for external webhooks (V2) to subscribe.

Direct Celery task chains are too rigid; pub/sub on Redis Streams
gives us replay, ordering per key, and consumer groups.

## 1. Bus interface

```python
# libs/argus_common/events/bus.py
from typing import Protocol, AsyncIterator
from datetime import datetime
from uuid import UUID

class DomainEvent(BaseModel):
    event_id: UUID
    type: str                       # e.g. "investigation.created"
    occurred_at: datetime
    tenant_id: UUID
    actor_id: UUID | None
    payload: dict[str, Any]
    schema_version: int = 1

class EventBus(Protocol):
    async def publish(self, topic: str, event: DomainEvent) -> str: ...
    async def subscribe(self, group: str, topics: tuple[str, ...]) -> str: ...
    async def consume(self, group: str, consumer: str,
                      count: int = 16, block_ms: int = 5000) -> list[DomainEvent]: ...
    async def ack(self, group: str, ids: list[str]) -> None: ...
```

## 2. Redis Streams implementation

```python
# libs/argus_common/events/redis_bus.py
import json
import uuid
from datetime import datetime, UTC

import redis.asyncio as redis_async
from argus_common.events.bus import DomainEvent, EventBus

class RedisEventBus:
    def __init__(self, client: redis_async.Redis, stream_prefix="argus:events"):
        self._r = client
        self._prefix = stream_prefix

    def _stream(self, topic: str) -> str:
        return f"{self._prefix}:{topic}"

    async def publish(self, topic: str, event: DomainEvent) -> str:
        eid = await self._r.xadd(
            self._stream(topic),
            {"json": json.dumps(event.model_dump(mode="json"))},
            maxlen=10_000,   # cap stream length
            approximate=True,
        )
        return eid.decode()

    async def subscribe(self, group: str, topics: tuple[str, ...]) -> str:
        # Idempotent: OK if group already exists
        for topic in topics:
            try:
                await self._r.xgroup_create(
                    name=self._stream(topic),
                    groupname=group,
                    id="$",          # only new events
                    mkstream=True,
                )
            except redis_async.ResponseError as e:
                if "BUSYGROUP" not in str(e): raise
        return group

    async def consume(self, group, consumer, count=16, block_ms=5000):
        streams = {self._stream(t): ">" for t in self._group_topics[group]}
        resp = await self._r.xreadgroup(
            groupname=group,
            consumername=consumer,
            streams=streams,
            count=count,
            block=block_ms,
        )
        events: list[tuple[str, DomainEvent]] = []
        for stream, entries in resp:
            topic = stream.decode().removeprefix(self._prefix + ":")
            for eid, data in entries:
                payload = json.loads(data[b"json"])
                events.append((eid.decode(),
                               DomainEvent.model_validate(payload)))
        return events

    async def ack(self, group, ids):
        for topic in self._group_topics[group]:
            await self._r.xack(self._stream(topic), group, *ids)
```

## 3. Topics

Names are kebab-case, past tense:

| Topic | Producer | Consumers |
|-------|----------|-----------|
| `investigation.created` | API (StartInvestigation) | Analytics, Bot SSE forwarder |
| `investigation.planned` | Worker (plan) | Analytics |
| `investigation.progress` | Worker (per task) | Bot SSE forwarder |
| `investigation.completed` | Worker (chord body) | Billing counter, Bot SSE, Analytics |
| `investigation.failed` | Worker (DLQ) | Billing counter, Audit |
| `investigation.cancelled` | API/Worker | Billing counter |
| `plugin.started` | Worker (plugin_runner) | Analytics |
| `plugin.succeeded` | Worker (plugin_runner) | Analytics |
| `plugin.failed` | Worker (plugin_runner) | Analytics, DLQ |
| `evidence.found` | Worker (persist) | Bot SSE, Entity extractor trigger |
| `entity.found` | Worker (extract) | Bot SSE, Relationship trigger |
| `entity.updated` | Worker (extract) | Bot SSE |
| `relationship.found` | Worker (discover) | Bot SSE |
| `export.requested` | API | Worker enqueue |
| `export.ready` | Worker | Bot SSE, Notification |
| `export.failed` | Worker | Bot SSE |
| `billing.quota_exceeded` | API | Bot SSE |
| `auth.login` | API | Analytics, Audit |
| `auth.refresh_reuse` | API | Audit + alert |

## 4. Schemas

Every event has a Pydantic schema. Stored in
`libs/argus_common/events/schemas.py`:

```python
class InvestigationCreated(DomainEvent):
    type: Literal["investigation.created"]
    payload: InvestigationCreatedPayload

class InvestigationCreatedPayload(BaseModel):
    investigation_id: UUID
    title: str
    target_kind: str
    target_value: str
    plugins: list[str]

class EvidenceFound(DomainEvent):
    type: Literal["evidence.found"]
    payload: EvidenceFoundPayload

class EvidenceFoundPayload(BaseModel):
    investigation_id: UUID
    evidence_id: UUID
    kind: str
    summary: dict
    confidence: float
```

Topics are **contracts**: producers and consumers validate against
the schema at the boundary. Schema breaks are caught in tests via
the **event contract test** suite.

## 5. Producer code

```python
# libs/argus_common/events/publish.py
from argus_common.events.bus import DomainEvent, EventBus

class EventPublisher:
    def __init__(self, bus: EventBus, tenant_id, actor_id):
        self._bus = bus
        self._tenant_id = tenant_id
        self._actor_id = actor_id

    async def emit(self, topic: str, payload: BaseModel) -> str:
        event = DomainEvent(
            event_id=uuid.uuid4(),
            type=topic,
            occurred_at=datetime.now(UTC),
            tenant_id=self._tenant_id,
            actor_id=self._actor_id,
            payload=payload.model_dump(mode="json"),
        )
        return await self._bus.publish(topic, event)
```

Used like:

```python
publisher.emit("investigation.created",
               InvestigationCreatedPayload(
                   investigation_id=inv.id,
                   title=inv.title,
                   target_kind=inv.target.kind,
                   target_value=inv.target.value,
                   plugins=["whois","dns"],
               ))
```

## 6. Consumer code

```python
# libs/argus_common/events/consumer.py
import asyncio
import structlog
from argus_common.events.bus import EventBus

class EventConsumer:
    def __init__(self, bus: EventBus, group: str, topics: tuple[str, ...],
                 handler, name: str = "consumer"):
        self.bus = bus
        self.group = group
        self.topics = topics
        self.handler = handler
        self.name = name

    async def run_forever(self):
        await self.bus.subscribe(self.group, self.topics)
        log = structlog.get_logger()
        backoff = 1.0
        while True:
            try:
                events = await self.bus.consume(self.group, self.name)
                if not events:
                    backoff = 1.0
                    continue
                for eid, event in events:
                    try:
                        await self.handler(event)
                    except Exception as e:
                        log.error("event.handler_failed",
                                  event_id=eid, type=event.type, error=str(e))
                        # Don't ack; re-deliver next loop
                        continue
                    await self.bus.ack(self.group, [eid])
            except Exception as e:
                log.error("event.consume_failed", error=str(e))
                await asyncio.sleep(backoff)
                backoff = min(backoff * 2, 30.0)
```

## 7. SSE forwarder for the bot

The bot doesn't subscribe to Redis Streams directly (would tie its
lifecycle to consumer groups). Instead, the API exposes an SSE
endpoint that wraps Redis Streams:

```python
# services/api/src/argus_api/routers/investigations.py
@router.get("/investigations/{id}/events")
async def stream_events(
    id: UUID, user: CurrentUser, request: Request
):
    async def gen():
        group = f"bot:{user[0].sub}"
        consumer = f"bot-{user[0].sub}"
        await event_bus.subscribe(group, _topics_for_investigation(id))
        try:
            while True:
                if await request.is_disconnected():
                    break
                events = await event_bus.consume(group, consumer, count=10, block_ms=2000)
                for eid, event in events:
                    if not _relates_to(event, id): continue
                    yield f"event: {event.type}\nid: {eid}\ndata: {json.dumps(event.payload)}\n\n"
                    await event_bus.ack(group, [eid])
        finally:
            # Don't destroy the group; bots reconnect often.
            pass
    return StreamingResponse(gen(), media_type="text/event-stream")
```

The bot uses `httpx` with `stream()` and parses SSE:

```python
# services/bot/src/argus_bot/api_client.py
async def stream_events(self, access_token, investigation_id):
    async with self._client.stream(
        "GET", f"/v1/investigations/{investigation_id}/events",
        headers={"Authorization": f"Bearer {access_token}"},
        timeout=None,
    ) as r:
        async for line in r.aiter_lines():
            if line.startswith("event:"):
                event_type = line.split(":",1)[1].strip()
            elif line.startswith("data:"):
                payload = json.loads(line.split(":",1)[1].strip())
                yield EventDTO(type=event_type, payload=payload)
```

## 8. Ordering guarantees

- Redis Streams deliver events to a consumer group in the order
  they were appended.
- Each investigation's events are in their own topics (we use
  `investigation:{id}.events` for the bot-specific stream — see
  below).

Wait — single topic per investigation would explode Redis. So we
**partition**: the bot forwarder listens to the global topics but
filters by `investigation_id` in payload. Redis Streams guarantees
ordering within a stream key, not across keys. For our use case
(interactive bot updates), latest-wins is fine.

## 9. Backpressure

- Stream cap `MAXLEN ~ 10000` per topic. Old events age out.
- Consumer groups track their own position; if a consumer is slow,
  unacked events accumulate. We set `XAUTOCLAIM` with idle 60s to
  re-deliver stuck events to other consumers.
- Bot SSE has its own group per user; if the user is offline, events
  still land. On reconnect, bot gets events from its last acked
  position (forward only — no replay of missed bot progress).

## 10. Event contract tests

```python
# libs/argus_common/events/tests/test_contracts.py
import json
from pathlib import Path

SCHEMAS_DIR = Path(__file__).parent / "schemas"

@pytest.mark.parametrize("event_file", SCHEMAS_DIR.glob("*.json"))
def test_event_schema_validates(event_file):
    payload = json.loads(event_file.read_text())
    event = DomainEvent.model_validate(payload)
    assert event.schema_version >= 1
    assert event.type
```

Stored samples in `schemas/` are checked in and used in CI to detect
breaking changes.

## 11. Idempotency

Consumers must be idempotent. We include `event_id` (UUID) in every
event. Consumers maintain a small Redis SET of recently-seen ids
(rolling 1000 entries) to dedupe within their window.

## 12. Dead-letter handling

If a consumer handler raises persistently (3+ retries), the event is
moved to `argus:dlq:events:<original-topic>` with a `last_error`
field. A Celery beat job drains DLQ to `audit.event` for ops review.

## 13. Why not Kafka / NATS?

- Free-tier friendly (Redis is everywhere).
- We already have Redis for cache, broker, and rate limit. One
  component to operate.
- Streams are enough for our throughput (estimated peak 1k events/s).
- Migration path is open: swap `EventBus` impl to NATS in V2 if we
  outgrow Redis.

## 14. Migration to a stronger bus (V2+)

`EventBus` is a Protocol. Implementation is injected via DI. Swapping
to NATS or Pulsar is a one-line change in `lifespan.py`.

## 15. Observability

- Counter `argus_events_published_total{topic}`.
- Counter `argus_events_consumed_total{group,topic,result}`.
- Histogram `argus_event_handler_duration_seconds{group,topic}`.
- Gauge `argus_consumer_lag{group,topic}` from
  `XPENDING <stream> <group>`.

## 16. Common pitfalls

- Publishing before the consumer group exists → events dropped for
  that group. Solution: producer publishes; consumer `subscribe`
  uses `$` (new only). **Stale-event risk**: bots that come online
  later miss progress. Solution: bot SSE pulls current state from
  `GET /v1/investigations/{id}` on connect, then subscribes.
- Synchronous publish in API request path → latency. Solution: use
  a background task with `asyncio.create_task(publish(...))` for
  non-critical events; sync `await publish(...)` only for events
  that downstream tasks depend on.

## 17. Cross-service consistency

The event bus is the **only** mechanism for cross-service
notification. We do **not** share Postgres logical replication or
direct DB writes between services.

## 18. Schema evolution

- Adding fields: bump `schema_version`, ensure consumers use
  `payload.get("new_field", default)`.
- Removing fields: bump major; old consumers continue to work if
  they use `.get()`.
- Renaming fields: bump major; use aliases in Pydantic.
- New topic: free; just add a consumer.
