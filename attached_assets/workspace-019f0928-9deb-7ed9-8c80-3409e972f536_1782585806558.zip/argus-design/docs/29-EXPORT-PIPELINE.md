# 29 — Export Pipeline

> Export architecture for JSON, CSV, HTML, Markdown, PDF, and graph
> formats. Streaming exports, large dataset handling, artifact
> production. Replaces the brief mention in 04-API-SPEC §7 and
> 06-WORKERS §10.

---

## 0. Goals

1. Every investigation can be exported in at least one machine-
   readable and one human-readable format.
2. Bot can download exports ≤ 50 MB directly; larger goes via
   signed URL.
3. Exports are reproducible: same input → same output.
4. Streaming support for arbitrarily large investigations.
5. Versioned format specs.

## 2. Format catalog

| Format | MIME | Use |
|--------|------|-----|
| JSON | application/json | Canonical, machine-readable |
| CSV | text/csv | Spreadsheet ingestion |
| HTML | text/html | Interactive report, web share |
| Markdown | text/markdown | Gist / docs |
| PDF | application/pdf | Paginated report |
| DOT | text/vnd.graphviz | Graph source |
| GraphML | application/xml | Graph interchange |
| PNG/SVG | image/png, image/svg+xml | Graph render |

## 3. Public interface

```python
class ExportPipeline(Protocol):
    async def render(self, request: ExportRequest) -> ExportResult: ...
    async def list_formats(self) -> list[ExportFormatInfo]: ...
```

```python
@dataclass(slots=True, frozen=True)
class ExportRequest:
    investigation_id: UUID
    format: Literal["json","csv","html","markdown","pdf","dot","graphml","png","svg"]
    options: ExportOptions
    tenant_id: UUID
    user_id: UUID

@dataclass(slots=True, frozen=True)
class ExportOptions:
    include_raw: bool = False
    include_artifacts: bool = False        # embed PNG/PDF in archive
    include_timeline: bool = True
    redact_pii: bool = True
    watermark: bool = True                 # free-tier
    language: str = "en"
    graph_options: GraphOptions | None = None

@dataclass(slots=True, frozen=True)
class GraphOptions:
    layout: Literal["dot","neato","fdp","circo"] = "dot"
    max_nodes: int = 1000
    color_by_confidence: bool = True
    hide_disputed: bool = False
```

## 4. Render architecture

```
ExportRequest ──► FormatRenderer ──► byte stream ──► ArtifactStore
                          │
                          └──► EvidenceStore (read)
                          └──► GraphService (read)
                          └──► ArtifactStore (read for embedded)
```

Each format has a dedicated renderer in
`services/worker/src/argus_worker/exports/`:

```
exports/
├── __init__.py
├── json_renderer.py
├── csv_renderer.py
├── html_renderer.py
├── markdown_renderer.py
├── pdf_renderer.py
├── graph_renderer.py
├── templates/
│   ├── report.html.j2
│   ├── report.md.j2
│   └── report.tex.j2
└── streaming.py
```

## 5. JSON (canonical)

```python
def render_json(inv: Investigation) -> AsyncIterator[bytes]:
    yield b'{"schema_version":"1.0",'
    yield f'"investigation":{json.dumps(inv.summary)}'.encode()
    yield b',"entities":['
    first = True
    for e in inv.entities:
        if not first: yield b","
        first = False
        yield json.dumps(e.to_dict()).encode()
    yield b'],"relationships":['
    first = True
    for r in inv.relationships:
        if not first: yield b","
        first = False
        yield json.dumps(r.to_dict()).encode()
    yield b'],"evidence":['
    first = True
    for ev in inv.evidence:
        if not first: yield b","
        first = False
        yield json.dumps(ev.to_dict(include_raw=options.include_raw)).encode()
    yield b'],"timeline":['
    first = True
    for t in inv.timeline:
        if not first: yield b","
        first = False
        yield json.dumps(t.to_dict()).encode()
    yield b']}'
```

Streaming: we yield chunks as we iterate. Never build the full
JSON in memory.

Schema version is `1.0`. Bumping the version adds fields; never
removes. Old readers tolerate new fields; new readers tolerate
missing optional fields.

## 6. CSV

CSV is flat. We emit **one CSV per concept**, zipped:

```
investigation.csv        # one row
entities.csv
relationships.csv
evidence.csv
timeline.csv
```

```python
def render_csv(inv: Investigation) -> AsyncIterator[bytes]:
    buf = BytesIO()
    z = zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED)
    z.writestr("investigation.csv", _csv_one_row(inv.summary))
    z.writestr("entities.csv", _csv_iter(inv.entities, ENTITY_COLUMNS))
    z.writestr("relationships.csv", _csv_iter(inv.relationships, REL_COLUMNS))
    z.writestr("evidence.csv", _csv_iter(inv.evidence, EVIDENCE_COLUMNS))
    z.writestr("timeline.csv", _csv_iter(inv.timeline, TIMELINE_COLUMNS))
    z.close()
    yield buf.getvalue()
```

For very large investigations, we stream each CSV row by row
through a `csv.writer` writing to the zip member's stream.

## 7. HTML

Jinja2 template `report.html.j2`. Includes:

- Header with investigation title, target, status, dates.
- Summary statistics.
- Entity table (sortable client-side).
- Relationship graph (inline SVG).
- Evidence timeline.
- Source list with confidence badges.

```python
async def render_html(inv, options) -> AsyncIterator[bytes]:
    graph_svg = await render_graph_svg(inv, options.graph_options)
    template = env.get_template("report.html.j2")
    html = template.render(
        investigation=inv,
        graph_svg=graph_svg,
        generated_at=datetime.now(UTC),
        options=options,
    )
    yield html.encode("utf-8")
```

Self-contained: CSS inlined, JS inlined. No external requests.
This is critical for share-by-download.

## 8. Markdown

Jinja2 template `report.md.j2`. Sections:

- `# Investigation`
- Summary block.
- `## Entities` (table).
- `## Relationships` (table).
- `## Evidence` (table).
- `## Timeline` (list).
- `## Sources` (list).

```python
async def render_markdown(inv, options) -> AsyncIterator[bytes]:
    template = env.get_template("report.md.j2")
    yield template.render(inv, options).encode("utf-8")
```

## 9. PDF

Rendered via WeasyPrint (HTML → PDF) or ReportLab (programmatic).

WeasyPrint route (default for HTML-faithful rendering):

```python
async def render_pdf(inv, options) -> AsyncIterator[bytes]:
    html_stream = render_html(inv, options)
    html_bytes = b"".join([chunk async for chunk in html_stream])
    pdf_bytes = weasyprint.HTML(string=html_bytes.decode()).write_pdf()
    yield pdf_bytes
```

WeasyPrint has C dependencies (`libpango`, `libcairo`); we bundle
them in the Docker image. On Termux, PDF rendering is **disabled**
(V1); users export HTML and convert locally.

Watermark for free-tier:

```python
def add_watermark(pdf_bytes: bytes) -> bytes:
    pdf = PdfReader(BytesIO(pdf_bytes))
    out = PdfWriter()
    for page in pdf.pages:
        page.merge_page(watermark_page())
        out.add_page(page)
    return BytesIO(out.write()).getvalue()
```

## 10. Graph exports

### 10.1 DOT

```python
async def render_dot(inv, options) -> AsyncIterator[bytes]:
    g = graphviz.Digraph(format="dot")
    for e in inv.entities:
        attrs = {
            "label": e.value,
            "color": _confidence_color(e.confidence),
        }
        g.node(str(e.id), **attrs)
    for r in inv.relationships:
        g.edge(str(r.from_entity_id), str(r.to_entity_id),
               label=r.kind, penwidth=str(1 + r.weight))
    yield g.source.encode("utf-8")
```

### 10.2 GraphML

```python
async def render_graphml(inv, options) -> AsyncIterator[bytes]:
    # standard graph interchange; full XML
    ...
```

### 10.3 PNG / SVG

Use `graphviz.Source(...).pipe(format="png")` (requires graphviz
binary). Capped at 50 MB. Beyond that, fall back to DOT.

## 11. Streaming exports

For investigations with > 100k evidence rows, we stream:

```python
async def render_json_streaming(inv_id) -> AsyncIterator[bytes]:
    async with ExportStream(inv_id) as stream:
        async for chunk in stream.json_chunks():
            yield chunk
```

`ExportStream` reads evidence in batches of 1000, encodes, yields.
Memory bounded to a single batch.

Bot handles streaming via `httpx.AsyncClient.stream` and re-uploads
in parts.

## 12. Large dataset handling

### 12.1 Splitting

For exports > 50 MB (Telegram upload limit):

```
investigation-001-of-003.json
investigation-002-of-003.json
investigation-003-of-003.json
```

Each part is independently valid (header included). We bundle them
in a ZIP for download, plus individual links for streaming.

### 12.2 Compression

JSON and HTML are gzip-compressed when > 1 MB.

### 12.3 Pagination hint

For very large CSVs, we emit a `MANIFEST.csv` listing all part
files.

## 13. Lifecycle — export

```
   requested ──► rendering ──► uploading ──► ready
        │            │            │           │
        └──► failed (any stage) ──► retryable (max 3)
                                    │
                                    └──► failed (terminal)
                                                  │
                                                  └──► audited
```

## 14. Sequence diagram

```
User             API          Worker          Renderer       Store
  │                │             │               │            │
  │ POST export    │             │               │            │
  ├───────────────►│             │               │            │
  │                │ enqueue     │               │            │
  │                ├────────────►│               │            │
  │ 202            │             │               │            │
  │ ◄──────────────┤             │ render        │            │
  │                │             ├──────────────►│            │
  │                │             │               │ chunks     │
  │                │             │               │ ─────────►│
  │                │             │               │            │ PUT
  │                │             │               │            │
  │                │             │ complete      │            │
  │                │             │ ◄─────────────┤            │
  │                │ update row  │               │            │
  │ GET download   │             │               │            │
  ├───────────────►│             │               │            │
  │                │ signed URL  │               │            │
  │ 302 url        │             │               │            │
  │ ◄──────────────┤             │               │            │
  │ GET url        │             │               │            │
  ├─────────────────────────────────────────────────────────────►│
  │ 200 bytes                                                       │
  │ ◄──────────────────────────────────────────────────────────────┤
```

## 15. Failure modes

| Failure | Detection | Recovery |
|---------|-----------|----------|
| Investigation too large | size > 1 GB | split or refuse |
| Renderer OOM | process exit | retry with smaller batch |
| Template missing | load error | fail with `ExportTemplateMissing` |
| Pango missing (PDF) | binary not found | fall back to HTML |
| R2 upload fails | 5xx | retry 3× |
| Invalid options | validation | 400 |

## 16. Public interface versioning

```python
EXPORT_SCHEMA_VERSION = "1.0"
```

Each emitted JSON carries `"schema_version":"1.0"`. New fields
bump minor; never remove. CSV column order is stable; new columns
appended.

## 17. Security

- All exports are tenant-scoped.
- Redaction rules from 26-EVIDENCE-SCORING apply.
- Web share exports are scoped to authenticated URLs with TTL.
- Watermark includes tenant_id (subtle).
- PDF/A compliance (long-term archival).

## 18. Scalability

- Rendering happens in worker; never in API.
- Streaming JSON at 10 MB/s for typical hardware.
- 1 investigation export ≈ 200 KB JSON; 1M exports/day ≈ 200 GB
  egress.
- Cache rendered exports: same input → same output, hash-keyed.

## 19. Free-tier compatibility

- Free tier: PDF only via HTML conversion (no WeasyPrint on
  Termux).
- Free tier: PNG graph export capped at 1000 nodes (downsampled
  beyond).
- Free tier: HTML reports have watermark.

## 20. Configuration

```bash
ARGUS_EXPORT_MAX_INVESTIGATION_MB=1024
ARGUS_EXPORT_SPLIT_THRESHOLD_MB=50
ARGUS_EXPORT_GZIP_THRESHOLD_BYTES=1048576
ARGUS_EXPORT_PDF_ENGINE=weasyprint   # or reportlab
ARGUS_EXPORT_GRAPH_MAX_NODES=1000
ARGUS_EXPORT_TELEGRAM_LIMIT_BYTES=52428800  # 50 MB
```

## 21. Trade-offs and rationale

| Decision | Rationale | Trade-off |
|----------|-----------|-----------|
| Streaming JSON | Bounded memory | Slightly more code |
| ZIP CSV | Multi-table | One more step for users |
| WeasyPrint for PDF | HTML-faithful | Heavy dependency |
| DOT for graph | Toolchain standard | Not directly viewable |
| Split at 50 MB | Telegram limit | More files to manage |

## 22. References

- [27-ARTIFACT-STORAGE.md](27-ARTIFACT-STORAGE.md) — Storage target
- [23-INVESTIGATION-GRAPH.md](23-INVESTIGATION-GRAPH.md) — Source
- [26-EVIDENCE-SCORING.md](26-EVIDENCE-SCORING.md) — Confidence
- [06-WORKERS.md](06-WORKERS.md) — Worker integration
- [04-API-SPEC.md](04-API-SPEC.md) — Endpoints
