# 22 — Anti-Bot (Fingerprinting & Detection Avoidance)

> Fingerprint profiles, TLS/HTTP fingerprinting, browser identity,
> session persistence, header normalization, timing strategy, and
> adaptive risk-based execution. Pure logic — no proxy / browser
> state; integration via interfaces.

---

## 0. Scope and ethics

**In scope**

- Make Argus traffic look like real, varied human traffic.
- Pass standard anti-bot checks (Cloudflare basic, PerimeterX
  basic, DataDome basic).
- Reduce false-positive bans for legitimate investigations.

**Out of scope**

- CAPTCHA solving services (we let the target escalate to V2).
- Bypassing paywalls.
- Targeting sites under active court order (we have a blocklist).
- Impersonation of real humans or session forgery against accounts
  we don't own.

We assume operators use Argus for **legitimate security research,
brand protection, due diligence, journalism, and academic study**.
The system helps operators act like real users; it does not attack
defenses.

## 1. Layer position

```
                  ┌─────────────────────────────┐
                  │  Scraping Engine (19)       │
                  └────────────┬────────────────┘
                               │ uses
                  ┌────────────▼────────────────┐
                  │  Anti-Bot (THIS DOCUMENT)   │
                  │  - Fingerprint profiles     │
                  │  - TLS profile              │
                  │  - Header normalizer        │
                  │  - Risk scorer              │
                  │  - Adaptive executor        │
                  └────────────┬────────────────┘
                               │ consumes
                  ┌────────────▼────────────────┐
                  │  Domain Core                │
                  │  FingerprintProfile (frozen)│
                  └─────────────────────────────┘
```

Anti-Bot is **logic-only** — it returns decisions and profiles.
Browser Manager (20) and Proxy Manager (21) apply them.

## 2. Fingerprint profile

```python
@dataclass(slots=True, frozen=True)
class FingerprintProfile:
    profile_id: str                  # "win11-chrome-120-us"
    os_family: Literal["windows","macos","linux","android","ios"]
    os_version: str                  # "11", "14.5"
    browser_family: Literal["chrome","firefox","safari","edge"]
    browser_version: str
    user_agent: str
    viewport: tuple[int, int]
    color_depth: int
    device_pixel_ratio: float
    locale: str                      # "en-US"
    timezone: str                    # "America/Los_Angeles"
    languages: tuple[str, ...]       # ("en-US","en")
    platform: str                    # "Win32"
    hardware_concurrency: int        # 8
    device_memory_gb: int | None
    canvas_seed: int                 # for canvas noise
    audio_seed: int
    webgl_vendor: str
    webgl_renderer: str
    fonts: tuple[str, ...]
    plugins: tuple[str, ...]
    sec_ch_ua: str
    sec_ch_ua_platform: str
    sec_ch_ua_mobile: bool
    accept_language: str
    tls_profile: str                 # name from §3
    header_order: tuple[str, ...]    # exact header order
    created_at: datetime
    deprecated_after: datetime | None
```

Profiles are generated combinatorially with constraints:

- `os_family` ↔ `browser_family` ↔ `platform` consistent.
- `browser_version` plausible for date `created_at`.
- `viewport` consistent with `device_pixel_ratio`.
- `fonts` subset of OS-typical fonts.

We ship **~200 curated profiles**, regenerated monthly.

## 3. TLS / HTTP fingerprinting

TLS handshake reveals browser even when headers lie. We support two
strategies:

### 3.1 `curl_cffi` for HTTP path

`curl_cffi` emulates browser TLS + HTTP/2 fingerprints without
running a browser. We support profiles:

- `chrome_120`
- `chrome_119`
- `firefox_120`
- `safari_17`
- `edge_120`

Selection is driven by `FingerprintProfile.browser_family` +
`browser_version`.

### 3.2 Playwright CDP for browser path

When in browser mode, the real Chromium TLS fingerprint is used.
Fingerprint overrides applied at CDP level:

```python
await context.add_init_script("""
Object.defineProperty(navigator, 'webdriver', { get: () => undefined });
""")
```

See [20-BROWSER-MANAGER.md §6.4](20-BROWSER-MANAGER.md) for the
full override script.

### 3.3 Choosing strategy

```
if mode == "browser":       → Playwright CDP
elif target.is_known_easy:  → curl_cffi (chrome profile)
elif risk_score < 0.4:      → curl_cffi
else:                       → escalate to browser
```

## 4. Browser identity

Beyond TLS, browser APIs leak. We override:

- `navigator.webdriver` → `undefined`.
- `navigator.languages` → profile languages.
- `navigator.platform` → profile platform.
- `navigator.hardwareConcurrency` → profile value.
- `navigator.deviceMemory` → profile value.
- `navigator.plugins` → profile plugins (Chrome 120: usually empty
  array; we set realistic ones).
- `navigator.userAgent` → profile UA.
- `screen.width/height/colorDepth` → profile.
- `Intl.DateTimeFormat().resolvedOptions().timeZone` → profile TZ.
- Canvas fingerprint: add small deterministic noise from
  `canvas_seed` so two requests with same seed look identical but
  different seeds differ.
- WebGL: `UNMASKED_VENDOR_WEBGL` / `UNMASKED_RENDERER_WEBGL` →
  profile values.
- AudioContext fingerprint: add small noise from `audio_seed`.
- Fonts: enumerate only profile fonts (return others as undefined).

These overrides run via `Page.addScriptToEvaluateOnNewDocument` so
they apply before page scripts.

## 5. Session persistence

We persist:

- Cookies (per session, see [19 §7](19-SCRAPING-ENGINE.md)).
- `localStorage` and `sessionStorage` (persistent profiles only).
- `IndexedDB` (persistent profiles only, max 50 MB).

We **do not** persist:

- Service workers (re-registered per context).
- Cache API (per-context).
- Push subscriptions.

Persistence is encrypted at rest (Fernet) and TTL-bounded.

## 6. Header normalization

### 6.1 Header order matters

Many anti-bot checks look at the **order** of headers, not just
values. We emit headers in the exact order browsers use:

**Chrome 120 GET request:**

```
Host
Connection
sec-ch-ua
sec-ch-ua-mobile
sec-ch-ua-platform
Upgrade-Insecure-Requests
User-Agent
Accept
Sec-Fetch-Site
Sec-Fetch-Mode
Sec-Fetch-User
Sec-Fetch-Dest
Accept-Encoding
Accept-Language
Cookie (if any)
```

`FingerprintProfile.header_order` defines this for each profile.

### 6.2 Forbidden headers

- `X-Forwarded-For`, `Forwarded`: we **never** add. If a target
  relies on these, we fail rather than spoof.
- Custom Argus headers (`X-Argus-*`): always stripped before
  sending.
- `X-Requested-With: XMLHttpRequest` only if fingerprint profile
  says so.

### 6.3 Required headers

If `risk_score > 0.6` and the profile doesn't already include them,
we add:

- `Sec-Fetch-Site: same-origin` (for first-party requests)
- `Sec-Fetch-Mode: navigate` (for top-level)
- `Sec-Fetch-Dest: document`

These are derived from request context, not hard-coded.

## 7. Timing strategy

Real humans don't fire requests at constant rate. We inject jitter:

| Action | Base delay | Jitter |
|--------|------------|--------|
| Inter-request | 1.5 s | ± 800 ms |
| Page load | wait for `domcontentloaded` + 200 ms | ± 150 ms |
| Click | 300 ms hover, 100 ms down, 80 ms up | ± 50 ms |
| Scroll | 50 px / 80 ms | ± 20 ms |
| Form fill | 30 ms / char | ± 10 ms |

Jitter is drawn from `random.gauss(0, sigma)` where `sigma` is
configurable per `risk_tolerance`:

- `low`: small jitter, fast.
- `medium`: medium jitter.
- `high`: large jitter, slow.

Adaptive timing: when risk score increases (see §9), all timing
multipliers grow. When safe, they shrink.

## 8. Detection avoidance principles

We follow these rules in code and document them for plugin
authors:

1. **One fingerprint per session**. Switching UAs mid-session
   trips basic defenses.
2. **Headers match fingerprint**. A Chrome UA with Firefox
   `Accept-Language` order is a tell.
3. **TLS matches fingerprint**. Don't claim Chrome with Python's
   default TLS.
4. **Cookie behavior matches flow**. Don't accept cookies then
   not send them.
5. **No impossible geography**. Locale `en-US` + TZ `Asia/Tokyo`
   raises flags; we never combine these.
6. **Respect robots.txt** when explicitly required by tenant
   policy. Anti-bot is not the same as robots-violation.
7. **No persistent unusual headers**. Custom debug headers
   (`X-Debug`, `X-Trace`) are stripped.
8. **Volume limits**. Stay below target's published rate limit
   even when we could go faster.

## 9. Risk scoring

A real-time score per `(tenant, domain)` pair, updated on each
request outcome:

```python
def compute_risk(
    domain_signals: list[float],
    recent_blocks: int,
    recent_captchas: int,
    recent_403s: int,
    target_difficulty: float,
) -> float:
    score = (
        0.30 * mean(domain_signals) +
        0.25 * sigmoid(recent_blocks - 2) +
        0.20 * sigmoid(recent_captchas - 1) +
        0.15 * sigmoid(recent_403s - 3) +
        0.10 * target_difficulty
    )
    return clamp(score, 0, 1)
```

`domain_signals` come from:

- Target returns 403, 429, or challenge HTML.
- Target's HTML contains anti-bot script URLs (Cloudflare
  challenge, hCaptcha, etc.).
- TLS handshake is unusual (mismatch between advertised and
  observed).

`sigmoid(x) = 1 / (1 + exp(-x))` keeps the term in [0,1].

Score thresholds:

| Score | Action |
|-------|--------|
| 0.0–0.3 | normal |
| 0.3–0.6 | slow down, swap fingerprint |
| 0.6–0.8 | switch to browser mode, residential proxy |
| 0.8–1.0 | back off, alert tenant, suggest manual |

## 10. Adaptive execution policies

Per `(tenant, domain)`, we keep a policy state:

```python
@dataclass(slots=True)
class ExecutionPolicy:
    tenant_id: UUID
    domain: str
    risk_score: float
    preferred_mode: Literal["http","browser"]
    preferred_proxy_type: str
    preferred_fingerprint_profile: str | None
    timing_multiplier: float          # 1.0 = normal
    max_concurrent_requests: int
    cooldown_until: datetime | None
    last_updated: datetime
```

On each fetch:

1. Look up policy.
2. If `risk_score` increased since last fetch → downgrade
   parameters (browser mode, residential, slower).
3. If decreased → cautiously upgrade.

Transitions:

```
normal ──score↑──► cautious ──score↑──► defensive ──score↑──► backoff
   ▲                  │                     │                     │
   └───score↓─────────┴─────score↓──────────┴─────score↓──────────┘
```

`backoff` state sets `cooldown_until` and pauses all requests to
that domain for that tenant for 600 s.

## 11. Integration with scraping engine

The Scraping Engine calls Anti-Bot at three points:

### 11.1 Preflight

Before launching:

```python
async def preflight(req: ScrapeRequest) -> ExecutionPolicy:
    profile = await profile_picker.pick(req)
    proxy_type = await proxy_decider.decide(req, profile)
    return ExecutionPolicy(... profile, proxy_type ...)
```

### 11.2 Per-request

Headers applied to outgoing request; fingerprint overrides applied
to context.

### 11.3 Postflight

```python
async def postflight(req, result: ScrapeResult) -> None:
    signals = extract_signals(result)
    await risk_scorer.record(req.tenant_id, parse_domain(req.url), signals)
    await policy_updater.adjust(req.tenant_id, parse_domain(req.url), signals)
```

### 11.4 Event emission

Each preflight/postflight emits `scraping.policy.adjusted` to the
event bus (see [09-EVENT-SYSTEM.md](09-EVENT-SYSTEM.md)) so other
subscribers (analytics, alerting) see it.

## 12. Failure modes

| Failure | Detection | Recovery |
|---------|-----------|----------|
| curl_cffi profile doesn't exist | import error | fall back to default; warn |
| Profile is deprecated | `deprecated_after < now` | pick fresh profile; log |
| Browser override script fails | evaluate returns wrong value | retry once; if persistent, recreate context |
| Risk score stuck at 1.0 | backoff active | expire cooldown; manual review |
| All fingerprints flagged | acquire returns None | use safest profile (lowest score) |

## 13. Security considerations

- Anti-bot is **not** an attack tool. Profiles are designed to look
  human, not to impersonate specific individuals.
- We do not store PII from the anti-bot process beyond what's in
  standard browser headers.
- Tenant `geo_allowlist` is enforced by Anti-Bot (we won't select a
  fingerprint whose geo doesn't match tenant policy).
- We log: `profile_id`, `risk_score`, `signals`. We do **not** log
  the `canvas_seed` or `audio_seed` (could be used to fingerprint
  Argus itself).

## 14. Abuse prevention

- A tenant running with `risk_tolerance=high` for many domains
  rapidly is throttled (31-COST-CONTROLLER).
- Persistent profiles are gated by user consent + per-tenant cap
  (default 10).
- Domains in the global blocklist (court orders, our own
  policies) cannot have fingerprints generated for them.
- Anti-bot does not bypass captchas — it surfaces them so the
  Scheduler (28) can route to human review.

## 15. Scalability

- Profile selection is O(1) lookup in a Redis sorted set.
- Risk scorer is per-tenant per-domain, written async to Redis.
- Policy state is small (< 1 KB per pair). 100k pairs ≈ 100 MB.
- Profile regeneration (monthly) is a one-shot Celery beat task.

## 16. Free-tier compatibility

- Free-tier tenants get a **default profile** (chrome_120_win11).
- They cannot opt into aggressive risk avoidance.
- Persistent profiles are paid-only.

## 17. Configuration

```bash
# .env additions
ARGUS_ANTIBOT_ENABLED=1
ARGUS_ANTIBOT_RISK_LOW=0.3
ARGUS_ANTIBOT_RISK_MEDIUM=0.6
ARGUS_ANTIBOT_RISK_HIGH=0.8
ARGUS_ANTIBOT_BACKOFF_S=600
ARGUS_ANTIBOT_PROFILE_REGEN_CRON="0 3 1 * *"
ARGUS_ANTIBOT_GLOBAL_BLOCKLIST=""
```

## 18. Trade-offs and rationale

| Decision | Rationale | Trade-off |
|----------|-----------|-----------|
| `curl_cffi` over raw httpx | Avoid TLS tells | Extra dependency |
| ~200 profiles, regenerated monthly | Enough variety without sprawl | Maintenance cost |
| Risk-based adaptive execution | Fewer false-positive bans | Slower for safe sites |
| No captcha solving | Ethics, cost | Some sites unreachable |
| Per-tenant geo allowlist | GDPR / compliance | Fewer options for some tenants |

## 19. References

- [19-SCRAPING-ENGINE.md](19-SCRAPING-ENGINE.md) — Primary consumer
- [20-BROWSER-MANAGER.md](20-BROWSER-MANAGER.md) — Browser identity
- [21-PROXY-MANAGER.md](21-PROXY-MANAGER.md) — Proxy selection
- [31-COST-CONTROLLER.md](31-COST-CONTROLLER.md) — Cost caps
- [28-SCHEDULER.md](28-SCHEDULER.md) — Manual fallback
