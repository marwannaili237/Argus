# 36 — Search Strategies

> Standard investigation playbooks. Email, username, domain, company,
> phone, IP, ASN, cryptocurrency, image, and social media strategies.
> Each defines plugin ordering, parallel execution plans, confidence
> calculation, cost estimation, stop conditions, and escalation
> policies. Consumed by the Planner (24) and executed by the Workflow
> Engine (35).

---

## 0. Position

```
   User / Scheduler / Bot          Planner (24)
       │                              │
       │ start investigation          │
       │                              │ load Strategy (36)
       │                              │ build Plan
       │                              │
       │                              ▼
       │                       Workflow Engine (35)
       │                              │
       │                              ▼
       │                       Plugin Runtime (33) → Sources (34)
       │                              │
       │                              ▼
       │                       Investigation Graph (23)
```

A **Strategy** is a typed playbook that the Planner consults. It
is the bridge between user intent ("investigate this email") and
the DAG that runs.

## 1. Goals

1. Reusable playbooks for common investigation types.
2. Standardized plugin ordering so re-runs (28) diff cleanly.
3. Cost and confidence budgets per strategy.
4. Stop conditions that prevent runaway runs.
5. Escalation policies that route to manual review when needed.

## 2. Public interface

```python
class StrategyRegistry(Protocol):
    async def get(self, kind: TargetKind, variant: str | None = None) -> Strategy: ...
    async def list_kinds(self) -> list[TargetKind]: ...
    async def list_variants(self, kind: TargetKind) -> list[str]: ...
```

```python
@dataclass(slots=True, frozen=True)
class Strategy:
    strategy_id: str
    kind: TargetKind
    variant: str                          # "default","deep","legal_safe",...
    display_name: str
    description: str
    phases: tuple[Phase, ...]
    cost_estimate: CostEstimate
    confidence_target: float
    stop_conditions: tuple[StopCondition, ...]
    escalation_policy: EscalationPolicy
    legal_constraints: tuple[str, ...]
    schema_version: int = 1

@dataclass(slots=True, frozen=True)
class Phase:
    phase_id: str
    name: str
    parallel: bool
    steps: tuple[StrategyStep, ...]
    on_failure: Literal["continue","stop","escalate"]
    timeout_s: float

@dataclass(slots=True, frozen=True)
class StrategyStep:
    step_id: str
    source_id: str                        # from 34
    inputs_from: tuple[str, ...]          # phase_id or step_id refs
    depends_on_phase: str | None
    mandatory: bool
    confidence_contribution: float

@dataclass(slots=True, frozen=True)
class StopCondition:
    when: str                             # DSL
    action: Literal["stop","escalate","continue"]

@dataclass(slots=True, frozen=True)
class EscalationPolicy:
    triggers: tuple[str, ...]             # conditions
    routes_to: Literal["manual_review","admin","bot_alert"]
    sla_minutes: int
```

### 2.1 Versioning

```python
STRATEGY_SCHEMA_VERSION = "1.0"
```

Bumped on incompatible changes. Strategies with older versions are
re-mapped by the registry.

## 3. Built-in strategies

| Strategy ID | Kind | Default variant | Tier |
|-------------|------|-----------------|------|
| `email.default` | email | default | free |
| `email.deep` | email | deep | pro |
| `email.legal_safe` | email | legal_safe | all |
| `username.default` | username | default | free |
| `username.cross_platform` | username | cross_platform | pro |
| `domain.default` | domain | default | free |
| `domain.deep_recon` | domain | deep_recon | pro |
| `company.default` | company | default | free |
| `company.comprehensive` | company | comprehensive | team |
| `phone.default` | phone | default | free |
| `ip.default` | ip | default | free |
| `ip.threat_intel` | ip | threat_intel | pro |
| `asn.default` | asn | default | pro |
| `crypto.btc` | crypto | btc | free |
| `crypto.eth` | crypto | eth | free |
| `image.reverse` | image | reverse | free |
| `social.person` | social | person | free |
| `social.company` | social | company | pro |

## 4. Strategy anatomy (example: email.default)

```yaml
strategy_id: email.default
kind: email
variant: default
display_name: Default Email Investigation
description: |
  Verify email deliverability, find breaches, locate social profiles.
phases:
  - phase_id: p1_validate
    name: Validate Email
    parallel: false
    on_failure: stop
    timeout_s: 30
    steps:
      - step_id: s1_smtp_verify
        source_id: argus.email_verify
        inputs_from: []
        mandatory: true
        confidence_contribution: 0.3

  - phase_id: p2_breaches
    name: Check Breach Databases
    parallel: true
    on_failure: continue
    timeout_s: 60
    steps:
      - step_id: s2_breach_public
        source_id: argus.breach_aggregator
        inputs_from: [p1_validate]
        mandatory: false
        confidence_contribution: 0.2

  - phase_id: p3_social
    name: Find Social Profiles
    parallel: true
    on_failure: continue
    timeout_s: 120
    steps:
      - step_id: s3_social_search
        source_id: argus.social_x
        inputs_from: [p1_validate]
        mandatory: false
        confidence_contribution: 0.15
      - step_id: s3_github_search
        source_id: argus.github
        inputs_from: [p1_validate]
        mandatory: false
        confidence_contribution: 0.1
      - step_id: s3_reddit_search
        source_id: argus.reddit
        inputs_from: [p1_validate]
        mandatory: false
        confidence_contribution: 0.05
confidence_target: 0.6
stop_conditions:
  - when: "evidence_count > 50"
    action: stop
  - when: "elapsed_s > 180"
    action: stop
escalation_policy:
  triggers:
    - "no_evidence_in_phase(p1_validate)"
    - "suspicious_target_indicator"
  routes_to: bot_alert
  sla_minutes: 60
legal_constraints:
  - "GDPR Article 6 lawful basis required for non-public sources"
  - "No minors"
```

## 5. Email strategy

### 5.1 Default (`email.default`)

**Goal:** verify the email and find public footprint.

**Phases:**

1. **p1_validate**: SMTP RCPT TO check via `argus.email_verify`.
2. **p2_breaches**: Public breach lists via `argus.breach_aggregator`.
3. **p3_social**: Search X, GitHub, Reddit for the email handle.

**Confidence target:** 0.6 (medium confidence).

**Cost:** ~8 credits.

### 5.2 Deep (`email.deep`)

Adds:

- `hunter` (Hunter.io API, paid).
- `virustotal` (domain reputation).
- `clearbit` (company enrichment).

**Confidence target:** 0.85.

**Cost:** ~25 credits.

### 5.3 Legal-safe (`email.legal_safe`)

For internal/HR investigations where GDPR compliance is critical.
Excludes paid sources and limits retention.

**Phases:** Same as default but only public sources.

**Stop conditions:** Investigation halts immediately on
`lawful_basis_missing` flag.

## 6. Username strategy

### 6.1 Default (`username.default`)

**Phases:**

1. **p1_normalize**: normalize handle (per 25-NORMALIZATION).
2. **p2_platforms** (parallel):
   - `argus.social_x`
   - `argus.github`
   - `argus.reddit`
3. **p3_correlate**: build co-occurrence graph (per 23 §8).

**Stop conditions:** 30 platforms checked, OR user-discovered
matching platforms > 5 with high-confidence profiles.

**Cost:** ~6 credits.

### 6.2 Cross-platform (`username.cross_platform`)

Adds 30+ platforms via a generic HTTP crawl with profile
detection heuristics. **Team tier only**.

**Cost:** ~50 credits.

## 7. Domain strategy

### 7.1 Default (`domain.default`)

**Phases:**

1. **p1_dns** (parallel):
   - `argus.dns` (A, MX, TXT, NS)
   - `argus.cert_transparency`
2. **p2_whois**: `argus.whois` (RDAP).
3. **p3_subdomain_enum** (parallel):
   - `argus.dns_subdomain_enum`
4. **p4_http_crawl**:
   - `argus.http_crawl` (only if DNS succeeded).

**Confidence target:** 0.7.

**Cost:** ~12 credits.

### 7.2 Deep recon (`domain.deep_recon`)

Adds:

- `shodan` (port scan).
- `censys` (cert + host).
- Historical WHOIS (`whois_history`).

**Cost:** ~60 credits.

## 8. Company strategy

### 8.1 Default (`company.default`)

**Phases:**

1. **p1_discover** (parallel):
   - `argus.whois` (domain from company name)
   - `argus.public_records_eu`
2. **p2_enrich**:
   - `argus.http_crawl` (homepage + about)
3. **p3_employees** (parallel, optional):
   - `argus.social_x` (employees tag search)
   - `argus.social_x` (executive names search)

**Confidence target:** 0.65.

**Cost:** ~15 credits.

### 8.2 Comprehensive (`company.comprehensive`)

Adds `clearbit` and `linkedin` (paid). 6 phases. Cost ~120 credits.

## 9. Phone strategy

### 9.1 Default (`phone.default`)

**Phases:**

1. **p1_normalize**: E.164 (25-NORMALIZATION §2.3).
2. **p2_carrier**:
   - `argus.phone_carrier` (free local lookup).
3. **p3_social**:
   - `argus.social_x` (search for phone).

**Cost:** ~5 credits.

### 9.2 Deep (paid)

Adds `twilio_lookup` and HLR-based geolocation.

## 10. IP strategy

### 10.1 Default (`ip.default`)

**Phases:**

1. **p1_geo**:
   - `argus.ip_geo` (MaxMind GeoLite2).
2. **p2_asn**:
   - `argus.asn` (Team Cymru).
3. **p3_reverse_dns**:
   - `argus.dns` (PTR records).

**Cost:** ~3 credits.

### 10.2 Threat intel (`ip.threat_intel`)

Adds `shodan`, `censys`, `virustotal`, `abuseipdb` (paid).
**Pro tier only**.

## 11. ASN strategy

### 11.1 Default (`asn.default`)

**Phases:**

1. **p1_resolve**: get prefix list from `argus.asn`.
2. **p2_prefix_scan** (parallel): scan each /24 prefix.
3. **p3_org_lookup**: `argus.public_records_eu`.

**Cost:** ~30 credits.

## 12. Cryptocurrency strategy

### 12.1 BTC (`crypto.btc`)

**Phases:**

1. **p1_validate**: check address format.
2. **p2_balance**:
   - `argus.crypto_btc` (blockchain.info).
3. **p3_tx_history** (parallel):
   - last 10 transactions.
4. **p4_cluster**: identify likely owner via cluster analysis.

**Cost:** ~10 credits.

### 12.2 ETH (`crypto.eth`)

Similar to BTC, uses Etherscan-style APIs.

## 13. Image strategy

### 13.1 Default (`image.reverse`)

**Phases:**

1. **p1_upload** (browser): upload to TinEye, Yandex.
2. **p2_match** (parallel):
   - exact matches.
   - similar images.
3. **p3_correlate**: map matches to source URLs → entities.

**Cost:** ~8 credits. Browser required.

## 14. Social media strategy

### 14.1 Person (`social.person`)

**Phases:**

1. **p1_input**: name (or username).
2. **p2_search** (parallel):
   - `argus.social_x`
   - `argus.github`
   - `argus.reddit`
3. **p3_correlate**: identity graph (23 §8).

**Cost:** ~6 credits.

### 14.2 Company (`social.company`)

Same as person but searches company handles and tags.

## 15. Plugin ordering

Order is determined by:

1. **Mandatory phase first.** Validation/identification phases
   always run before enrichment.
2. **Cost-first vs confidence-first.** Strategies optimize for one
   or the other. Default is balance.
3. **Capability-aware.** If target has email AND username, prefer
   email source first (more reliable identification).
4. **Tier-gated.** Pro plugins skipped for free tier (Planner
   uses 31-COST-CONTROLLER + 34-DATA-SOURCE-REGISTRY).

## 16. Parallel execution plans

Phases marked `parallel: true` execute steps concurrently.
The engine (35) uses tenant concurrency + plugin-specific caps.

```python
# Example: email.default phase 3
phases:
  - phase_id: p3_social
    parallel: true
    on_failure: continue
    timeout_s: 120
    steps:
      - step_id: s3_social_search    # X
      - step_id: s3_github_search    # GitHub
      - step_id: s3_reddit_search    # Reddit
```

These 3 run in parallel. Tenant concurrency cap may force
sequential.

## 17. Confidence calculation

Per step:

```python
confidence_contribution = (
    source_reliability_score *           # from 34
    extractor_base_confidence *          # from 19 §12.4
    freshness_factor                    # from 26 §3
)
```

Investigation confidence:

```python
confidence = 1 - prod(1 - c for c in step_contributions)
# (probability of at least one source being correct)
```

Capped at 1.0. Reported on investigation completion.

## 18. Cost estimation

Each strategy declares per-phase cost estimate:

```python
cost_estimate = sum(
    step.source.cost_model.cost_per_call_credits
    for phase in phases
    for step in phase.steps
)
```

The Planner uses this for budget pre-check (31 §5).

## 19. Stop conditions

Stop conditions use a small DSL:

```yaml
when: "evidence_count > 50"             # numeric comparisons
when: "elapsed_s > 180"
when: "no_evidence_in_phase(p1)"        # helper
when: "cost_credits_used > 50"
when: "target_appears_in_blocklist"
when: "manual_stop"                     # user-triggered
```

Action:

- `stop`: cancel remaining steps; mark investigation `completed`.
- `escalate`: route to escalation policy.
- `continue`: log and continue (default).

## 20. Escalation policies

When triggered, the strategy routes to:

- `manual_review`: admin bot queue. SLA `sla_minutes`.
- `admin`: direct admin notification.
- `bot_alert`: user-facing message ("review needed").

Triggers include:

- `no_evidence_in_phase(<mandatory_phase>)`.
- `low_confidence_after_all_phases`.
- `target_appears_in_blocklist`.
- `cost_exceeded_budget`.
- `suspicious_target_indicator`.

The escalation is implemented as a special step type in the
workflow engine (35):

```yaml
- step_id: escalate
  type: escalate
  policy: escalation_policy
```

## 21. Custom strategies

Users can define custom strategies (Pro tier):

```yaml
# saved by user via /strategy create
strategy_id: my_due_diligence
kind: company
variant: my_org
phases:
  - phase_id: p1_initial
    steps: [...]
```

Stored in `strategy.user_strategy` table.

## 22. Strategy execution flow

```
   User              Planner            Workflow           Plugin
     │                  │                Engine            Runtime
     │ /new             │                │                   │
     │ scan X           │                │                   │
     ├─────────────────►│                │                   │
     │                  │ resolve target.kind
     │                  │ load strategy  │                   │
     │                  │ build plan     │                   │
     │                  │                │                   │
     │                  │ execute plan   │                   │
     │                  ├───────────────►│                   │
     │                  │                │ dispatch steps   │
     │                  │                ├──────────────────►│
     │                  │                │ run plugin       │
     │                  │                │ ◄─────────────────┤
     │                  │                │ aggregate        │
     │                  │ ◄──────────────┤                   │
     │ complete         │                │                   │
     │ ◄────────────────┤                │                   │
```

## 23. Failure modes

| Failure | Detection | Recovery |
|---------|-----------|----------|
| Strategy not found | registry raises | fallback to default |
| Mandatory step fails | phase `on_failure: stop` | mark investigation failed |
| Cost exceeded | pre-flight | reject |
| Confidence never reaches target | end of strategy | mark `low_confidence` |
| Stop condition hits | monitor | execute stop action |
| Escalation target unreachable | retry | alert ops |

## 24. Security

- Strategy loaded by trusted code; user custom strategies go
  through validation (24 §6).
- Escalation policies must include a lawful basis check.
- Blocklisted targets (GDPR minors, court orders) are filtered
  at strategy level.
- Strategy output never includes raw third-party tokens.

## 25. Scalability

- Strategy registry: O(strategies) ≈ 50 entries.
- Plan from strategy: O(steps) ≈ 12 steps.
- One investigation → one strategy → one plan → one workflow.

## 26. Free-tier / Termux compatibility

- Free tier: only `*.default` strategies; paid-only variants
  refused.
- Termux dev: strategies are pure YAML; easy to author.

## 27. Data model

```sql
CREATE TABLE strategy.playbook (
    strategy_id          TEXT PRIMARY KEY,
    kind                 TEXT NOT NULL,
    variant              TEXT NOT NULL,
    display_name         TEXT NOT NULL,
    description          TEXT NOT NULL,
    definition           JSONB NOT NULL,            -- full Strategy
    cost_estimate        INT NOT NULL,
    confidence_target    REAL NOT NULL,
    is_builtin           BOOLEAN NOT NULL DEFAULT TRUE,
    author_id            UUID,
    is_active            BOOLEAN NOT NULL DEFAULT TRUE,
    created_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
    schema_version       INT NOT NULL DEFAULT 1,
    CONSTRAINT strategy_unique UNIQUE (kind, variant)
);
CREATE INDEX playbook_kind_idx ON strategy.playbook (kind);
```

## 28. Configuration

```bash
ARGUS_STRATEGY_REGISTRY_PATH=libs/argus_intelligence/strategies/builtin
ARGUS_STRATEGY_DEFAULT_VARIANT=default
ARGUS_STRATEGY_USER_STRATEGIES_ENABLED=1     # Pro tier
ARGUS_STRATEGY_ESCALATION_DEFAULT_SLA_M=60
```

## 29. Trade-offs and rationale

| Decision | Rationale | Trade-off |
|----------|-----------|-----------|
| Strategy as YAML | Easy to author | Less type-safe |
| DSL for stop conditions | Expressive | Custom parser |
| Per-target-kind strategies | Predictable | More strategies to maintain |
| Confidence formula: 1-prod(1-p) | Simple, well-known | Inflates for many sources |
| Escalation to bot_alert | User-visible | May annoy users |

## 30. References

- [24-PLANNER.md](24-PLANNER.md) — Strategy → Plan
- [35-WORKFLOW-ENGINE.md](35-WORKFLOW-ENGINE.md) — Plan execution
- [34-DATA-SOURCE-REGISTRY.md](34-DATA-SOURCE-REGISTRY.md) — Sources
- [33-PLUGIN-RUNTIME.md](33-PLUGIN-RUNTIME.md) — Plugin execution
- [25-NORMALIZATION.md](25-NORMALIZATION.md) — Target normalization
- [31-COST-CONTROLLER.md](31-COST-CONTROLLER.md) — Cost budget
- [26-EVIDENCE-SCORING.md](26-EVIDENCE-SCORING.md) — Confidence
- [23-INVESTIGATION-GRAPH.md](23-INVESTIGATION-GRAPH.md) — Result graph
- [28-SCHEDULER.md](28-SCHEDULER.md) — Re-runs use strategies
- [11-ERROR-HANDLING.md](11-ERROR-HANDLING.md) — Escalation errors
