# 12 — Logging Strategy

## 0. Goals

1. JSON logs to stdout. Always.
2. One line = one event. Multi-line traces only via `exc_info`.
3. Every log line carries: `timestamp`, `level`, `service`, `env`,
   `request_id`, plus event-specific keys.
4. No `print()`. Linter enforces.
5. Cheap to operate on a free-tier log sink (Grafana Loki 50 GB/mo
   free).

## 1. The library

We use **structlog** for ergonomics, **stdlib logging** for
compatibility (uvicorn, sqlalchemy, celery, aiogram all use stdlib).

```python
# libs/argus_common/logging.py
import logging
import sys
import contextvars
import uuid

import structlog
from structlog.types import EventDict, Processor

# ── Context variables ──────────────────────────────────────────────
request_id_var = contextvars.ContextVar("request_id", default="-")
tenant_id_var  = contextvars.ContextVar("tenant_id", default="-")
user_id_var    = contextvars.ContextVar("user_id", default="-")
service_var    = contextvars.ContextVar("service", default="-")

def bind_request_id(value: str | None = None) -> str:
    rid = value or str(uuid.uuid4())
    request_id_var.set(rid)
    return rid

# ── Processors ─────────────────────────────────────────────────────
def add_context(_: Processor, __: str, event_dict: EventDict) -> EventDict:
    event_dict.setdefault("request_id", request_id_var.get())
    event_dict.setdefault("tenant_id",  tenant_id_var.get())
    event_dict.setdefault("user_id",    user_id_var.get())
    event_dict.setdefault("service",    service_var.get())
    return event_dict

def drop_color(_, __, event_dict):
    return {k: v for k, v in event_dict.items() if not k.startswith("_")}

def censor_sensitive(_, __, event_dict):
    """Mask well-known sensitive keys."""
    sensitive = {"authorization", "cookie", "init_data", "api_key",
                 "password", "token", "refresh_token", "secret"}
    def walk(obj):
        if isinstance(obj, dict):
            return {k: ("[REDACTED]" if k.lower() in sensitive else walk(v))
                    for k, v in obj.items()}
        if isinstance(obj, (list, tuple)):
            return [walk(x) for x in obj]
        return obj
    for k, v in list(event_dict.items()):
        if isinstance(v, (dict, list)):
            event_dict[k] = walk(v)
    return event_dict

def utc_timestamper(_, __, event_dict):
    import datetime as _dt
    event_dict["timestamp"] = _dt.datetime.now(_dt.UTC).isoformat(timespec="milliseconds")
    return event_dict

# ── Public API ─────────────────────────────────────────────────────
def configure_logging(service: str, level: str = "INFO", json: bool = True):
    service_var.set(service)

    shared_processors = [
        structlog.contextvars.merge_contextvars,
        structlog.processors.add_log_level,
        utc_timestamper,
        add_context,
        censor_sensitive,
        structlog.processors.StackInfoRenderer(),
        structlog.processors.format_exc_info,
    ]

    if json:
        renderer = structlog.processors.JSONRenderer()
    else:
        renderer = structlog.dev.ConsoleRenderer(colors=False)

    structlog.configure(
        processors=shared_processors + [
            structlog.stdlib.ProcessorFormatter.wrap_for_formatter,
        ],
        logger_factory=structlog.stdlib.LoggerFactory(),
        wrapper_class=structlog.stdlib.BoundLogger,
        cache_logger_on_first_use=True,
    )

    formatter = structlog.stdlib.ProcessorFormatter(
        processor=renderer,
        foreign_pre_chain=shared_processors,
    )

    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(formatter)

    root = logging.getLogger()
    root.handlers.clear()
    root.addHandler(handler)
    root.setLevel(level)

    # Quiet noisy libs
    for noisy in ("httpx", "httpcore", "asyncio", "uvicorn.access",
                  "celery.beat", "botocore", "s3transfer", "urllib3"):
        logging.getLogger(noisy).setLevel("WARNING")

    # Uvicorn: keep our format
    for name in ("uvicorn", "uvicorn.error", "uvicorn.access"):
        lg = logging.getLogger(name)
        lg.handlers.clear()
        lg.propagate = True

# ── Convenience logger ────────────────────────────────────────────
def get_logger(name: str | None = None):
    return structlog.get_logger(name)
```

## 2. Log levels — when to use what

| Level | When | Examples |
|-------|------|----------|
| DEBUG | Per-request detail, only when `LOG_LEVEL=DEBUG` | `plugin.lookup`, `redis.get` |
| INFO | Lifecycle events | `investigation.created`, `auth.login` |
| WARNING | Recoverable issues, retries | `plugin.transient`, `db.reconnect` |
| ERROR | Failed operations, sent to Sentry | `task.failed`, `api.error_5xx` |
| CRITICAL | Process / data integrity | `audit.chain_broken`, `dlq.overflow` |

## 3. Event keys — naming

- Lowercase, snake_case, dotted for sub-objects:
  `investigation.created`, `evidence.found`.
- Past tense for completed actions: `auth.login`, `export.ready`.
- Present tense for in-progress: `plugin.running`.
- Failure → suffix `.failed` or `.error`.
- Avoid generic keys: `event`, `data`, `payload` (use specific
  names).

## 4. Standard keys per request

Every log line in a request scope includes:

```json
{
  "timestamp": "2026-06-27T10:00:00.123Z",
  "level": "info",
  "service": "api",
  "env": "production",
  "release": "v1.2.3",
  "request_id": "8e0a...",
  "tenant_id": "uuid",
  "user_id": "uuid",
  "method": "POST",
  "path": "/v1/investigations",
  "status": 202,
  "duration_ms": 42,
  "event": "request.completed"
}
```

## 5. Sampling

We don't sample V1 logs (volume is low). For V2 if logs exceed
10 GB/day:

- `DEBUG` always sampled 0% in production.
- Per-route sampling: noisy `/health` at 1%.
- Keep 100% of `WARNING` and above.

Implementation: structlog processor that drops events based on
rate.

## 6. Redaction

`censor_sensitive` masks well-known keys recursively. Additional
explicit redaction in:

- `Authorization` header → never logged.
- `initData` (Telegram) → never logged.
- API key plaintext → never logged.
- JWT tokens → never logged (only `jti`).
- User passwords → never logged.
- IP addresses of users from EU → logged truncated (`xxx.xxx.xxx.0`).

Sentry `before_send` does additional scrubbing.

## 7. Per-service log shape

### API

```python
log.info("request.start", method=r.method, path=r.url.path)
log.info("request.completed", method=r.method, path=r.url.path,
         status=response.status_code, duration_ms=duration)
log.warning("auth.invalid_token", path=r.url.path)
log.error("api.unhandled", exc_info=True)
```

### Bot

```python
log.info("update.received", update_id=u.update_id, user_id=u.from_user.id)
log.info("handler.completed", handler=handler.__name__, duration_ms=...)
log.warning("update.throttled", user_id=...)
log.error("api.error", code=err.code, status=err.status)
```

### Worker

```python
log.info("task.start", task=task_name, args_preview=str(args)[:200])
log.info("task.completed", task=task_name, duration_ms=duration)
log.warning("task.retry", task=task_name, attempt=..., error=...)
log.error("task.failed", task=task_name, exc_info=True)
log.info("plugin.stdout", line="...")  # forward plugin output
```

## 8. Request lifecycle log lines

A single user action produces:

```
[bot]  update.received
[bot]  api.request.start          (correlates via request_id)
[bot]  api.request.completed
[api]  auth.verify.ok
[api]  investigation.create.start
[api]  investigation.create.commit
[api]  task.enqueue               (argus.investigation.plan)
[api]  event.publish              (investigation.created)
[bot]  update.edit                (Telegram message edit)
[wrk]  task.start                 (plan)
[wrk]  event.publish              (investigation.planned)
[wrk]  task.start                 (plugin.run x6)
[wrk]  plugin.stdout              (per-line)
[wrk]  event.publish              (evidence.found x200)
[wrk]  task.start                 (entity.extract x200)
[wrk]  event.publish              (entity.found x50)
[wrk]  task.start                 (relationship.discover)
[wrk]  task.completed             (chord body)
[wrk]  event.publish              (investigation.completed)
[bot]  update.edit                (final screen)
```

All carry the same `request_id` so Grafana Loki can stitch them.

## 9. Integration with stdlib loggers

uvicorn, sqlalchemy, celery, aiogram all use stdlib. They emit via
`logging.getLogger("uvicorn.access")`. Our processor chain
(`foreign_pre_chain` in `ProcessorFormatter`) automatically applies
structlog's processors to these — they get contextvars, JSON
format, redaction. No library-specific setup needed.

To attach contextvars to background work (Celery), use:

```python
@worker_process_init.connect
def on_init(**_):
    configure_logging("worker")
    # Ensure contextvars are reset per task
```

In each task:

```python
@shared_task(bind=True)
def my_task(self):
    bind_request_id(self.request.id)
    log = get_logger()
    log.info("task.start")
    ...
```

## 10. Loki shipping

On Railway, Railway's built-in log drain pushes stdout to a Loki
endpoint (free 30-day retention). On Koyeb, logtail or syslog. We
emit JSON, so any sink parses natively.

Recommended Grafana queries:

- `service="api" | level="error"` — error rate.
- `request_id="..."` — single request trace.
- `json | tenant_id="..."` — tenant drill-down.
- `json | event="plugin.failed" | count by(plugin_name)` —
  unreliable plugins.

## 11. Local dev logging

`LOG_FORMAT=text` env makes logs human-readable on Termux:

```
2026-06-27 10:00:00.123 INFO api request.completed method=POST path=/v1/investigations status=202 duration_ms=42
```

`LOG_LEVEL=DEBUG` enables verbose. `tail -f` on the tmux pane is the
primary debug interface (see [15-TMUX-LAYOUT.md](15-TMUX-LAYOUT.md)).

## 12. Tail / search helpers

`scripts/tail-logs.sh` opens tmux panes filtered to a service:

```bash
#!/usr/bin/env bash
# services=api,bot,worker,beat
service="${1:-api}"
case "$service" in
  api)    docker compose -f ops/local.yml logs -f api    2>/dev/null \
          || journalctl -u argus-api -f                   2>/dev/null \
          || tail -f logs/api.log ;;
  bot)    tail -f logs/bot.log ;;
  worker) tail -f logs/worker.log ;;
  beat)   tail -f logs/beat.log ;;
  *) echo "unknown service: $service"; exit 1 ;;
esac
```

In our PaaS setup, `railway logs -s api` or `koyeb logs -a argus-api`
replaces this.

## 13. What we never log

- Full HTTP request bodies (only summary: `payload_keys=[...]`).
- Full HTTP response bodies.
- Full plugin stdout (we log a tail).
- User passwords, plaintext tokens, initData.
- Internal-only errors with sensitive context.

A pre-commit hook greps for `log.*(.*Authorization.*)` and
`log.*(.*password.*=.*)` to catch accidental leaks.

## 14. Retention

- Hot: 7 days in Loki (searchable).
- Cold: 30 days in R2 (compressed JSON.gz, searchable via
  `zcat | jq | grep`).
- Audit logs: 1 year (regulatory).
- After retention: deleted.

## 15. PII minimization

- We don't log user input text beyond what's needed (e.g. target
  value IS logged because it's required for debug).
- We hash user identifiers when not needed: `user_hash =
  sha256(user_id)` for analytics.
- We never share raw logs with third parties.
