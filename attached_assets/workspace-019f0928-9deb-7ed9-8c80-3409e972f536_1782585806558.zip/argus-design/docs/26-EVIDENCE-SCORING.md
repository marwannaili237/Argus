# 26 — Evidence Scoring

> Confidence, source reliability, freshness, verification status,
> calculations, auditability, manual overrides, and score propagation
> to entities and relationships. Pure domain logic.

---

## 0. Goals

1. Every piece of evidence has a numeric confidence in [0, 1].
2. Confidence combines multiple factors deterministically.
3. Operators can manually override scores with full audit trail.
4. Scores propagate to derived entities and relationships.
5. Scores decay over time (freshness).

## 1. Score components

```python
@dataclass(slots=True, frozen=True)
class EvidenceScore:
    base: float                  # from extractor
    source_reliability: float    # from tier
    freshness: float             # decay function
    verification: float          # verified/unverified/disputed
    cross_reference: float       # bonus for multi-source
    manual_override: float | None = None

    def combined(self) -> float:
        if self.manual_override is not None:
            return self.manual_override
        # weighted geometric mean
        parts = [self.base, self.source_reliability, self.freshness,
                 self.verification, self.cross_reference]
        log_sum = sum(math.log(max(p, 1e-6)) for p in parts)
        return math.exp(log_sum / len(parts))
```

All inputs in [0, 1]. Output in [0, 1].

## 2. Source reliability tiers

```python
SOURCE_RELIABILITY = {
    # Tier A: primary authoritative sources
    "rdap.org":              0.95,
    "iana.org":              0.95,
    "arin.net":              0.95,
    "ripe.net":              0.95,
    "apnic.net":              0.95,
    "letsencrypt.org":       0.90,
    "google.com":            0.85,        # search results
    "twitter.com":           0.75,
    "linkedin.com":          0.80,
    "github.com":            0.85,
    "wikipedia.org":         0.85,
    # Tier B: secondary
    "reddit.com":            0.65,
    "facebook.com":          0.70,
    # Tier C: low
    "pastesite.com":         0.40,
    "unknown":               0.30,
}

def source_reliability_for(domain: str) -> float:
    for d, r in SOURCE_RELIABILITY.items():
        if domain.endswith(d):
            return r
    return SOURCE_RELIABILITY["unknown"]
```

Plugins can override per-evidence via `evidence.source_reliability`
explicit field.

## 3. Freshness decay

```python
def freshness(observed_at: datetime, now: datetime,
              half_life_days: float = 30.0) -> float:
    age_days = (now - observed_at).total_seconds() / 86400
    return 0.5 ** (age_days / half_life_days)
```

Default `half_life_days` is 30. Plugins declare their own:

- WHOIS: 14 days.
- DNS: 1 day.
- HTTP page: 7 days.
- Breach entry: 365 days.

`half_life_days` is per `evidence.kind`.

## 4. Verification status

| Status | Score | Set by |
|--------|-------|--------|
| `verified` | 1.0 | Two+ independent sources agree |
| `unverified` | 0.7 | Single source |
| `disputed` | 0.4 | Sources disagree |
| `untrusted` | 0.2 | Source blacklisted |
| `manual_verified` | 1.0 | Operator override (manual) |

Status transitions:

```
unverified ─verified─► verified
     │                   │
     └─disputed─► disputed ─resolved─► verified
                                     │
                                     └─► unverified (if more sources appear)
```

`verified` is auto-set when two independent sources for the same
canonical entity agree on a non-trivial attribute. "Independent"
means different `plugin_name`.

## 5. Cross-reference bonus

When the same canonical entity receives the same value from N
independent sources:

```python
def cross_reference_bonus(observation_count: int,
                          distinct_plugin_count: int) -> float:
    if distinct_plugin_count >= 3:
        return 1.0
    if distinct_plugin_count == 2:
        return 0.85
    return 0.5 + min(observation_count, 5) * 0.05
```

Capped at 1.0. The bonus reflects "more eyes" without overfitting.

## 6. Confidence calculations

### 6.1 On evidence insert

```python
def score_evidence(evidence: Evidence) -> Evidence:
    base = evidence.extractor_confidence  # from 19-SCRAPING-ENGINE §12.4
    src = source_reliability_for(parse_domain(evidence.source_url))
    fresh = freshness(evidence.observed_at, datetime.now(UTC),
                      half_life_days=evidence.kind.half_life_days)
    verif = 0.7  # unverified by default
    cross = cross_reference_bonus(1, 1)
    s = EvidenceScore(base=base, source_reliability=src,
                      freshness=fresh, verification=verif,
                      cross_reference=cross)
    evidence.confidence = round(s.combined(), 3)
    evidence.verification_status = "unverified"
    return evidence
```

### 6.2 On every observation

Re-run cross_reference_bonus with new counts; recompute.

### 6.3 On manual override

```python
evidence.manual_override_confidence = new_value
evidence.override_reason = reason
evidence.overridden_by = user_id
evidence.overridden_at = datetime.now(UTC)
```

## 7. Auditability

Every confidence change writes an audit row:

```sql
CREATE TABLE investigation.evidence_audit (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    evidence_id     UUID NOT NULL REFERENCES investigation.evidence(id) ON DELETE CASCADE,
    action          TEXT NOT NULL,       -- 'insert','recompute','override','dispute'
    actor_kind      TEXT NOT NULL,       -- 'system','user'
    actor_id        UUID,
    old_confidence  REAL,
    new_confidence  REAL NOT NULL,
    old_status      TEXT,
    new_status      TEXT,
    reason          TEXT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX evidence_audit_evidence_idx
    ON investigation.evidence_audit (evidence_id, created_at DESC);
```

Audits are append-only and queryable via API:

```
GET /v1/evidence/{id}/audit
```

## 8. Manual overrides

### 8.1 API

```
POST /v1/evidence/{id}/override
{
  "confidence": 0.95,
  "verification_status": "verified",
  "reason": "Confirmed by phone call to source",
}
```

### 8.2 Authorization

- `evidence:override` scope required.
- Role: admin or owner.

### 8.3 Effect

- `evidence.manual_override_confidence` set.
- `evidence_audit` row appended.
- Score recomputed downstream (entities, relationships).
- Bot and UI show "analyst-verified" badge.

### 8.4 Bot UX

In the bot, the override is exposed only to admins via `/admin
override <evidence_id> <score>`.

## 9. Score propagation

### 9.1 To entities

```python
def entity_confidence(entity: Entity, evidence_list: list[Evidence]) -> float:
    if not evidence_list:
        return entity.manual_override_confidence or 0.5
    # Confidence-weighted average
    total = sum(e.confidence for e in evidence_list)
    weighted = sum(e.confidence * e.confidence for e in evidence_list)
    return round(weighted / total, 3)
```

### 9.2 To relationships

```python
def relationship_confidence(rel: Relationship) -> float:
    evidence = EvidenceRepo.list_by_ids(rel.evidence_ids)
    if not evidence:
        return 0.3
    return round(sum(e.confidence for e in evidence) / len(evidence), 3)
```

### 9.3 To derived evidence

When a new piece of evidence is derived from existing ones
(e.g. entity extraction from a page):

```python
derived.confidence = min(e.confidence for e in source_evidence) * 0.9
```

`0.9` is the "derivation discount".

## 10. Disputes

When a new evidence disagrees with existing:

```python
def on_conflict(new: Evidence, existing: Evidence):
    if abs(new.confidence - existing.confidence) < 0.2:
        # soft conflict — both kept
        new.verification_status = "disputed"
        existing.verification_status = "disputed"
        timeline_event("evidence.disputed", [new.id, existing.id])
    else:
        # hard conflict — keep higher-confidence
        winner = max([new, existing], key=lambda e: e.confidence)
        loser = min([new, existing], key=lambda e: e.confidence)
        winner.verification_status = "verified"
        loser.verification_status = "disputed"
        timeline_event("evidence.resolved", winner=winner.id, loser=loser.id)
```

Manual dispute resolution:

```
POST /v1/evidence/disputes/{id}/resolve
{
  "winner_evidence_id": "...",
  "reason": "..."
}
```

## 11. Lifecycle — evidence confidence

```
   inserted (score) ──► re-scored (cross-ref) ──► stable
        │                  │                          │
        └──► disputed ─────┴──► resolved ──────────►│
             │                  │                   │
             └─► manual_override (any time) ────────┘
```

## 12. Failure modes

| Failure | Detection | Recovery |
|---------|-----------|----------|
| Source reliability not found | fallback | use `unknown` tier |
| Freshness negative (future timestamp) | cap to 1.0 | log; clamp |
| Override by unauthorized user | 403 | reject |
| All evidence in dispute | investigation marked disputed | alert |

## 13. Security

- Overrides require authenticated admin.
- Audit is append-only and tenant-scoped.
- We do not allow raising confidence above source tier cap unless
  manually overridden (so a "disputed" source can't auto-promote).

## 14. Scalability

- Score recomputation is O(evidence_count) per entity. Triggered
  on insert; for large investigations batched via Celery.
- Source reliability lookup is O(1) (dict).
- Freshness is O(1) per call.
- Cross-reference bonus is O(distinct_plugin_count); capped at 3.

## 15. Configuration

```bash
ARGUS_SCORING_DEFAULT_HALF_LIFE_DAYS=30
ARGUS_SCORING_KIND_HALF_LIFE_DAYS=whois_record:14,dns_record:1,http_page:7
ARGUS_SCORING_VERIFIED_THRESHOLD=2     # distinct plugins
ARGUS_SCORING_DERIVATION_DISCOUNT=0.9
```

## 16. Trade-offs and rationale

| Decision | Rationale | Trade-off |
|----------|-----------|-----------|
| Weighted geometric mean | Penalizes any single low score | Less forgiving than arithmetic |
| Hard-coded source tiers | Curated, opinionated | Maintenance burden |
| Manual override always wins | Operator trust | Possible abuse |
| Decay by kind | Each kind has different shelf life | More config |

## 17. References

- [19-SCRAPING-ENGINE.md](19-SCRAPING-ENGINE.md) — Base confidence source
- [23-INVESTIGATION-GRAPH.md](23-INVESTIGATION-GRAPH.md) — Propagation target
- [25-NORMALIZATION.md](25-NORMALIZATION.md) — Cross-plugin reconciliation
- [29-EXPORT-PIPELINE.md](29-EXPORT-PIPELINE.md) — Surfaces scores
