# 27 — Artifact Storage

> Object storage abstraction for HTML snapshots, screenshots, PDFs,
> binary evidence. Includes metadata, retention, versioning, and
> integrity verification. Replaces and extends the brief mention in
> 19-SCRAPING-ENGINE.

---

## 0. Why a dedicated artifact layer

The Scraping Engine (19) produces raw bytes (HTML, PNG, PDF) and
metadata (URL, captured_at, headers). Where do they live?

- **Postgres bytea**: works for small blobs, but blows up the DB at
  scale and complicates backups.
- **Filesystem on the worker**: dies with the worker.
- **Object store (S3 / R2)**: the right answer for blobs.

We centralize all blob storage behind a single `ArtifactStore`
abstraction. Every subsystem (Scraping, Exports, Plugins) goes
through it.

## 1. Storage backends

We support:

| Backend | Use |
|---------|-----|
| Cloudflare R2 | Production (S3-compatible) |
| AWS S3 | Production (paid) |
| Local disk | Dev, Termux, fallback |
| In-memory | Tests |

Abstraction:

```python
class ArtifactStore(Protocol):
    async def put(self, key: str, body: bytes | AsyncIterator[bytes],
                  content_type: str, metadata: Mapping[str, str]) -> "ArtifactRef": ...
    async def get(self, key: str) -> AsyncIterator[bytes]: ...
    async def head(self, key: str) -> "ArtifactMetadata": ...
    async def delete(self, key: str) -> None: ...
    async def signed_url(self, key: str, ttl_s: int = 300) -> str: ...
    async def list(self, prefix: str) -> AsyncIterator["ArtifactRef"]: ...
```

`ArtifactRef`:

```python
@dataclass(slots=True, frozen=True)
class ArtifactRef:
    artifact_id: UUID
    storage_key: str                 # e.g. "evidence/<inv_id>/<ev_id>.html.gz"
    sha256: bytes                    # 32 bytes
    size: int
    content_type: str
    backend: str                     # "r2","s3","local","memory"
    created_at: datetime
    metadata: Mapping[str, str]
    signed_url: str | None           # populated on demand
```

## 2. Artifact types

| Type | MIME | Source |
|------|------|--------|
| `html_snapshot` | `text/html` (+ `.gz`) | 19 |
| `screenshot_png` | `image/png` | 19 |
| `screenshot_webp` | `image/webp` | 19 |
| `pdf` | `application/pdf` | 19 (browser) / 29 (export) |
| `binary_evidence` | varies | 19 / plugins |
| `export_json` | `application/json` | 29 |
| `export_csv` | `text/csv` | 29 |
| `export_html` | `text/html` | 29 |
| `export_markdown` | `text/markdown` | 29 |
| `export_pdf` | `application/pdf` | 29 |
| `export_graph_dot` | `text/vnd.graphviz` | 29 |
| `export_graph_png` | `image/png` | 29 |

Each artifact has a strongly-typed record in
`investigation.artifact` (existing in 03 with extensions below).

## 3. Schema extensions

```sql
CREATE TABLE investigation.artifact (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    investigation_id UUID NOT NULL REFERENCES investigation.investigation(id) ON DELETE CASCADE,
    evidence_id     UUID REFERENCES investigation.evidence(id) ON DELETE SET NULL,
    export_id       UUID REFERENCES investigation.export(id) ON DELETE SET NULL,
    kind            TEXT NOT NULL,
    storage_key     TEXT NOT NULL,
    backend         TEXT NOT NULL,
    sha256          BYTEA NOT NULL,
    size_bytes      BIGINT NOT NULL,
    content_type    TEXT NOT NULL,
    metadata        JSONB NOT NULL DEFAULT '{}',
    captured_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
    expires_at      TIMESTAMPTZ,
    retention_class TEXT NOT NULL DEFAULT 'default',
    version         INT NOT NULL DEFAULT 1,
    previous_version UUID REFERENCES investigation.artifact(id),
    CONSTRAINT artifact_kind_chk CHECK (kind IN (
        'html_snapshot','screenshot_png','screenshot_webp','pdf',
        'binary_evidence','export_json','export_csv','export_html',
        'export_markdown','export_pdf','export_graph_dot','export_graph_png'
    )),
    CONSTRAINT artifact_backend_chk CHECK (backend IN ('r2','s3','local','memory'))
);
CREATE INDEX artifact_investigation_idx
    ON investigation.artifact (investigation_id, kind);
CREATE INDEX artifact_sha256_idx ON investigation.artifact (sha256);
CREATE INDEX artifact_expires_idx ON investigation.artifact (expires_at)
    WHERE expires_at IS NOT NULL;
```

## 4. Key layout

```
argus/
├── evidence/<investigation_id>/<evidence_id>/<kind>-v<n>.<ext>
├── screenshots/<investigation_id>/<evidence_id>-v<n>.<ext>
├── exports/<investigation_id>/<export_id>/<format>-v<n>.<ext>
└── temp/<run_id>/<random>             # 24h TTL
```

`temp/` is for in-flight uploads that may be cancelled; cleaned
nightly.

## 5. Integrity verification

### 5.1 On write

```python
sha256 = hashlib.sha256(body).digest()
```

Stored alongside the artifact. Upload failure aborts the operation.

### 5.2 On read

Periodically (Celery beat daily) we re-verify a sample of artifacts:

```python
async def verify_integrity(artifact_id: UUID):
    head = await store.head(key)
    stream = store.get(key)
    h = hashlib.sha256()
    async for chunk in stream:
        h.update(chunk)
    if h.digest() != head.sha256:
        await audit.write("artifact.corruption", artifact_id=artifact_id)
        await alert_ops(f"Artifact {artifact_id} corrupted")
```

Sample rate: 1% per day, prioritized by size and age.

### 5.3 On upload

Multipart upload computes checksums per part. If any part fails,
we abort the multipart upload to avoid orphaned parts.

## 6. Retention

### 6.1 Retention classes

| Class | Default retention | Override |
|-------|-------------------|----------|
| `evidence_html` | 90 days | tenant setting |
| `evidence_screenshot` | 30 days | tenant setting |
| `evidence_binary` | 365 days | tenant setting |
| `export` | 7 days | tenant setting |
| `audit_log` | 365 days | not overridable |
| `temp` | 24 hours | not overridable |

### 6.2 Celery beat job

```python
@shared_task(name="argus.maintenance.cleanup_artifacts")
def cleanup_artifacts():
    with session_scope() as s:
        for a in ArtifactRepo(s).list_expired():
            try:
                store.delete(a.storage_key)
            except NotFound:
                pass
            s.delete(a)
```

Runs at 03:30 UTC daily (separate from export cleanup at 03:00).

### 6.3 GDPR

When a user requests deletion, artifacts tied to their
investigations are deleted immediately:

- `DELETE /v1/users/me` → Celery task `argus.maintenance.purge_user`
- For each investigation owned: delete all artifacts.
- Then delete the investigation row.
- Audit row retained (anonymized).

## 7. Versioning

Re-capturing an HTML snapshot of the same URL produces a **new
version** of the artifact, not a replacement.

```python
def put_versioned(kind: str, evidence_id: UUID, body: bytes, ...) -> ArtifactRef:
    existing = ArtifactRepo.find_latest(evidence_id=evidence_id, kind=kind)
    version = (existing.version + 1) if existing else 1
    key = f"evidence/{inv_id}/{evidence_id}/{kind}-v{version}.html.gz"
    ref = store.put(key, body, ...)
    if existing:
        existing.superseded_at = now()
    return ref
```

`superseded_at` is set on the previous version. Listing returns
the latest non-superseded by default; `?all=1` returns the full
history.

`version` is a monotonic integer per `(evidence_id, kind)`.

## 8. Compression

- HTML: gzip level 6 by default.
- JSON: gzip level 9 (smaller).
- PNG: stored as-is (already compressed).
- PDF: stored as-is.

Compression is decided by the producer; we don't recompress on
storage.

## 9. Encryption

- Server-side: R2 / S3 default SSE-S3.
- Client-side: not used in V1 (artifacts are not end-to-end
  encrypted).
- Sensitive artifacts (e.g. breach entries with PII) get a
  per-tenant KMS key in V2.

## 10. Failure modes

| Failure | Detection | Recovery |
|---------|-----------|----------|
| Upload to R2 fails (5xx) | retry 3× exp | fall back to local disk |
| R2 quota exceeded | 4xx | mark tenant over-quota; alert |
| Local disk full | ENOSPC | upload to R2 only; warn |
| Corruption detected | hash mismatch | re-fetch from source if possible |
| Signed URL expired | 403 on fetch | re-issue URL |
| Concurrent writes | ETag conflict | retry with backoff |

## 11. Lifecycle — artifact

```
   created ──► stored ──► available ──► superseded (new version)
       │           │           │
       │           │           └──► deleted (TTL/GDPR)
       │           └──► corrupted ──► quarantine
       └──► upload_failed ──► retry ──► failed
```

## 12. Sequence diagram — upload + reference

```
Engine           ArtifactStore    ObjectStore    Repo
   │                  │               │            │
   │ put(body, meta)  │               │            │
   ├─────────────────►│               │            │
   │                  │ PUT /key      │            │
   │                  ├──────────────►│            │
   │                  │ 200 OK + etag │            │
   │                  │ ◄─────────────┤            │
   │                  │ insert row    │            │
   │                  ├──────────────────────────►│
   │ ArtifactRef      │               │            │
   │ ◄────────────────┤               │            │
```

## 13. Sequence diagram — download via signed URL

```
Bot / Client     API            ArtifactStore    ObjectStore
   │                │                │               │
   │ GET /exports/x │                │               │
   ├───────────────►│                │               │
   │                │ generate signed URL            │
   │                ├───────────────►│               │
   │                │                │ presign       │
   │                │                ├──────────────►│
   │                │                │ url           │
   │                │                │ ◄─────────────┤
   │                │ ◄──────────────┤               │
   │ 302 url         │               │               │
   │ ◄───────────────┤               │               │
   │ GET url         │               │               │
   ├───────────────────────────────────────────────►│
   │ 200 bytes       │               │               │
   │ ◄───────────────────────────────────────────────┤
```

## 14. Public interface versioning

```python
ARTIFACT_STORE_SCHEMA_VERSION = "1.0"
```

Bumped on breaking changes to `ArtifactRef` or `ArtifactStore`.
Compatible additions (new fields) bump minor.

## 15. Security

- All uploads require authenticated worker context.
- Signed URLs are tenant-scoped and time-bounded.
- Artifact metadata is sanitized before storage (strip control
  chars, truncate headers).
- Path traversal: keys are constructed by code, never from user
  input directly.
- Backups: R2 versioning enabled; daily `pg_dump` covers artifact
  metadata.

## 16. Abuse prevention

- Per-tenant artifact quota (default 5 GB; configurable).
- Per-artifact size cap (default 100 MB).
- Per-tenant monthly bytes-in cap.

## 17. Scalability

- R2 free tier: 10 GB storage, 10M reads, 1M writes/mo.
- Throughput: ~100 puts/sec per worker, ~1000 gets/sec.
- For 1M investigations/day, ~50M artifacts/day → 500 puts/sec
  peak. Need 5 workers.
- Local disk fallback for free tier is per-worker, capped at
  1 GB.

## 18. Configuration

```bash
ARGUS_ARTIFACT_STORE_BACKEND=r2
ARGUS_ARTIFACT_LOCAL_DIR=/var/lib/argus/artifacts
ARGUS_ARTIFACT_RETENTION_HTML_DAYS=90
ARGUS_ARTIFACT_RETENTION_SCREENSHOT_DAYS=30
ARGUS_ARTIFACT_RETENTION_EXPORT_DAYS=7
ARGUS_ARTIFACT_RETENTION_TEMP_HOURS=24
ARGUS_ARTIFACT_MAX_SIZE_BYTES=104857600  # 100 MB
ARGUS_ARTIFACT_GZIP_MIN_BYTES=1024
ARGUS_ARTIFACT_INTEGRITY_SAMPLE_RATE=0.01
```

## 19. Trade-offs and rationale

| Decision | Rationale | Trade-off |
|----------|-----------|-----------|
| Always through ArtifactStore | Single point of audit and policy | More code per producer |
| Versioning per evidence | Never lose history | Storage cost |
| Daily integrity sample | Cheap detection | Won't catch all corruption |
| Local fallback | Free-tier works | Less durable |
| Gzip HTML/JSON | Cheaper storage | CPU overhead |

## 20. References

- [19-SCRAPING-ENGINE.md](19-SCRAPING-ENGINE.md) — Primary producer
- [29-EXPORT-PIPELINE.md](29-EXPORT-PIPELINE.md) — Export producer
- [13-DEPLOYMENT.md](13-DEPLOYMENT.md) — Backend selection
- [03-DATABASE-SCHEMA.md](03-DATABASE-SCHEMA.md) — Base schema
- [28-SCHEDULER.md](28-SCHEDULER.md) — Cleanup coordination
