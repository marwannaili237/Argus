# 07 — Plugin SDK

## 0. Goals

A plugin author can:

1. Author a plugin in plain Python.
2. Declare capabilities in a manifest.
3. Submit it for review.
4. Have it run inside Argus without touching core code.

A plugin **cannot**:

- Access the host filesystem beyond its workdir.
- Make arbitrary outbound HTTP (only declared endpoints).
- Spawn processes, fork, or use sockets.
- Read env vars except a whitelist.
- Import arbitrary Python packages (only `argus_plugin_sdk` and the
  packages listed in its `[dependencies]` section of the manifest).
- Crash the worker.

## 1. Plugin package layout

```
plugin_dns/
├── pyproject.toml              # build config + plugin metadata
├── argus.toml                  # Argus-specific manifest
├── src/
│   └── argus_dns/
│       ├── __init__.py
│       ├── __main__.py         # CLI entrypoint
│       └── runner.py           # implements the contract
└── tests/
    └── test_runner.py
```

The plugin is built as a regular Python wheel via `python -m build`,
then uploaded to the Argus plugin registry.

## 2. Manifest (`argus.toml`)

```toml
[plugin]
name        = "dns"
version     = "1.0.0"
description = "Subdomain discovery and DNS record enumeration"
author      = "Argus Team <team@argus.saas>"
homepage    = "https://github.com/argus-saas/plugin-dns"
license     = "Apache-2.0"
entrypoint  = "argus_dns.__main__:main"

[plugin.target]
kinds = ["domain", "subdomain"]

[plugin.capabilities]
http      = ["https://*"]            # any HTTPS
dns       = ["8.8.8.8", "1.1.1.1"]  # upstream resolvers
storage   = "rw"                     # read-write to its workdir
no_network = false

[plugin.runtime]
python          = ">=3.12,<3.13"
memory_mb       = 256
cpu_seconds     = 120
network_egress_mb = 50

[plugin.dependencies]
requests = ">=2.31"
dnspython = ">=2.5"

[plugin.outputs]
evidence_kinds = ["dns_record", "subdomain"]

[plugin.signature]
# Filled in at submit time by registry
public_key = "..."
algorithm  = "ed25519"
```

The manifest is parsed at load time and verified against the
registry's signature before any code runs.

## 3. The plugin contract

```python
# plugins/_sdk/src/argus_plugin_sdk/contract.py
from typing import Protocol, AsyncIterator
from dataclasses import dataclass

@dataclass
class Evidence:
    kind: str
    summary: dict
    raw: dict | None = None
    source_url: str | None = None
    confidence: float = 1.0
    blob: tuple[bytes, str] | None = None  # (content, content_type)

class Plugin(Protocol):
    def setup(self, ctx: "Context") -> None: ...
    def run(self, ctx: "Context", input: dict) -> AsyncIterator[Evidence]: ...
    def teardown(self, ctx: "Context") -> None: ...
```

Plugin authors implement this Protocol in their `runner.py`. The
SDK auto-discovers it.

## 4. The SDK surface (`argus_plugin_sdk`)

```python
# plugins/_sdk/src/argus_plugin_sdk/__init__.py
from .ctx import ctx, Context
from .http import http
from .dns import dns
from .emit import emit_evidence, emit_log, emit_metric
from .db import db_read, db_write
from .ratelimit import ratelimit
from .errors import (
    PluginError, PluginInputError, PluginTransientError,
    PluginPermanentError, PluginTimeoutError,
)

__version__ = "1.0.0"
```

### `ctx`

```python
@dataclass
class Context:
    investigation_id: str
    plugin_run_id: str
    target: TargetSpec
    workdir: str
    locale: str

ctx: Context   # populated by SDK at startup
```

### `http`

```python
class HttpClient:
    def get(self, url: str, *, timeout: float = 30.0, headers: dict | None = None) -> Response: ...
    def post(self, url: str, *, json: dict | None = None, **kw) -> Response: ...
    def head(self, url: str, **kw) -> Response: ...
    def stream(self, url: str, **kw) -> Iterator[bytes]: ...

http: HttpClient
```

Internally uses `httpx`. Capability check: domain of `url` must
match `[plugin.capabilities.http]`. Proxy rotation handled by the
SDK based on user-configured settings (Tor/SOCKS for OSINT work).

### `dns`

```python
class DnsClient:
    def resolve(self, name: str, *, kind: str = "A") -> list[str]: ...
    def reverse(self, ip: str) -> list[str]: ...
    async def resolve_async(...): ...

dns: DnsClient
```

Wraps `dnspython`. Resolvers limited to those listed in manifest.

### `emit_evidence`

```python
def emit_evidence(
    *,
    kind: str,
    summary: dict,
    raw: dict | None = None,
    source_url: str | None = None,
    confidence: float = 1.0,
    blob: tuple[bytes, str] | None = None,
) -> None: ...
```

Bufferred and flushed at end of run, or every 50 items.

### `db_read` / `db_write`

Read-only access to a curated view of `investigation.evidence` for
the **current** investigation. Plugins cannot read other
investigations or other tables. `db_write` is a convenience that
wraps `emit_evidence` with a `kind="other"` default.

### `ratelimit`

```python
@ratelimit(calls=10, period=60.0)
def expensive_call():
    ...
```

Plugin-declared rate limit. The SDK enforces it. Backed by Redis,
key includes plugin name.

### `errors`

| Error | When | Plugin runner action |
|-------|------|----------------------|
| `PluginInputError` | Bad input from upstream | Mark plugin_run failed, don't retry |
| `PluginTransientError` | Network blip | Retry up to 3 with backoff |
| `PluginPermanentError` | Bug | Mark failed, don't retry, audit |
| `PluginTimeoutError` | CPU/clock timeout | Kill subprocess |

## 5. CLI entrypoint (`__main__.py`)

```python
# plugins/plugin_dns/src/argus_dns/__main__.py
import argparse
import asyncio
import json
import sys

from argus_plugin_sdk import ctx
from argus_plugin_sdk.runner import run_plugin_cli

from argus_dns.runner import DnsPlugin

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--in", dest="input", required=True)
    parser.add_argument("--out", dest="output", required=True)
    parser.add_argument("--log", dest="log", required=True)
    parser.add_argument("--ctx", dest="ctx_json", required=True)
    args = parser.parse_args()
    run_plugin_cli(DnsPlugin(), args)

if __name__ == "__main__":
    main()
```

`run_plugin_cli` handles:

- Loading context from `--ctx`.
- Calling `setup()`.
- Iterating `run()`.
- Writing JSONL evidence to `--out`.
- Writing logs to `--log`.
- Calling `teardown()`.
- Exit code 0 on success, 1 on `PluginInputError`, 2 on transient,
  3 on permanent.

## 6. Sample plugin (`plugin_dns`)

```python
# plugins/plugin_dns/src/argus_dns/runner.py
import asyncio
from argus_plugin_sdk import (
    ctx, http, dns, emit_evidence, emit_log,
    PluginTransientError,
)

# Curated subdomain wordlist, 500 entries, ~ 200 KB.
WORDLIST_PATH = "/usr/lib/argus/dns/wordlist.txt"

class DnsPlugin:
    def setup(self):
        with open(WORDLIST_PATH) as f:
            self.wordlist = [w.strip() for w in f if w.strip()]
        emit_log("dns.setup", wordlist_size=len(self.wordlist))

    async def run(self):
        target = ctx.target.value
        for word in self.wordlist:
            host = f"{word}.{target}"
            try:
                answers = dns.resolve(host, kind="A")
            except TimeoutError:
                continue
            except Exception as e:
                emit_log("dns.error", host=host, error=str(e))
                continue
            if answers:
                emit_evidence(
                    kind="subdomain",
                    summary={"host": host, "ips": answers, "parent": target},
                    source_url=None,
                )

    def teardown(self):
        emit_log("dns.teardown")
```

## 7. Subprocess startup

When the worker spawns the plugin, the SDK takes these steps before
running `setup()`:

1. Parse `argus.toml`. Verify signature.
2. Check declared dependencies are present in the plugin venv (built
   at submit time, frozen).
3. Apply Python `sys.modules` whitelist:
   - Allowed: `argus_plugin_sdk`, declared deps, stdlib.
   - Removed: `os` (replace with a tiny allowlisted subset),
     `subprocess`, `socket`, `asyncio.subprocess`, `multiprocessing`,
     `ctypes`, `importlib` (after load).
4. Apply rlimits.
5. Set up Python `audit` hooks to block forbidden calls.
6. Apply network namespace restrictions (Linux only — best-effort).
7. Set env from a whitelist.

## 8. Plugin loader

```python
# services/worker/src/argus_worker/plugin_runtime/loader.py
import importlib.util
import sys
from pathlib import Path
import tomllib
from dataclasses import dataclass

@dataclass(slots=True)
class LoadedPlugin:
    name: str
    version: str
    entrypoint: Path
    python: str
    manifest: dict

_REGISTRY: dict[tuple[str, str], LoadedPlugin] = {}

def load_plugin(name: str, version: str) -> LoadedPlugin:
    key = (name, version)
    if key in _REGISTRY:
        return _REGISTRY[key]
    base = Path(settings.plugin_storage_dir) / name / version
    if not (base / "argus.toml").exists():
        raise PluginNotFoundError(name, version)
    manifest = tomllib.loads((base / "argus.toml").read_text())
    verify_signature(manifest, base)
    py = manifest["plugin"]["runtime"].get("python", "3.12")
    entry = _resolve_entrypoint(base, manifest["plugin"]["entrypoint"])
    plugin = LoadedPlugin(name, version, entry, py, manifest)
    _REGISTRY[key] = plugin
    return plugin

def warm_plugin_cache():
    """Load all installed plugins at worker startup."""
    for install in InstalledPluginRepo().list_all():
        try:
            load_plugin(install.name, install.version)
        except Exception as e:
            logger.error("plugin.load_failed", name=install.name, error=str(e))
```

## 9. Signature verification

```python
# services/worker/src/argus_worker/plugin_runtime/signature.py
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

REGISTRY_PUBLIC_KEY = serialization.load_pem_public_key(
    settings.plugin_registry_public_key.encode()
)

def verify_signature(manifest: dict, base: Path):
    sig_block = manifest["plugin"]["signature"]
    if not sig_block.get("public_key"):
        raise PluginUnsignedError()
    pub = serialization.load_pem_public_key(sig_block["public_key"].encode())
    if not isinstance(pub, Ed25519PublicKey):
        raise PluginSignatureError("not ed25519")
    # Sign everything except [plugin.signature]
    body = _manifest_bytes_without_signature(manifest)
    sig = (base / "argus.toml.sig").read_bytes()
    pub.verify(sig, body)

def _manifest_bytes_without_signature(manifest: dict) -> bytes:
    cleaned = {**manifest}
    cleaned["plugin"] = {k:v for k,v in cleaned["plugin"].items()
                         if k != "signature"}
    return tomli_w.dumps(cleaned).encode()
```

## 10. Submission flow

```
Plugin author
   │
   ▼
argus plugin build              # → wheel + .toml + .toml.sig
   │
   ▼
argus plugin submit <wheel>     # → POST /v1/admin/plugin-submissions
   │
   ▼
[API] store blob in R2, enqueue review task
   │
   ▼
[Admin bot] owner approves / rejects
   │
   ▼
[DB] plugin.installation created for requesting tenant
       or plugin.plugin registered globally
```

## 11. Per-tenant config

`plugin.installation.config` is a JSONB column. Plugins can read it
via `ctx.config` (injected into `Context`).

Example for `plugin_dns`:

```json
{
  "wordlist": "default",
  "max_subdomains": 500,
  "timeout_per_lookup_s": 5
}
```

The plugin accesses `ctx.config["max_subdomains"]`. Schema is
declared in the manifest under `[plugin.config_schema]` and validated
by Pydantic before the plugin starts.

## 12. Outputs → evidence

Plugin emits evidence via `emit_evidence(...)`. The SDK validates:

- `kind` is in `[plugin.outputs.evidence_kinds]`.
- `summary` and `raw` are JSON-serializable.
- `confidence ∈ [0,1]`.
- `blob` ≤ 5 MB (else raise `PluginInputError`).

The runner accumulates records into a list, writes them as JSONL to
the output file, and the worker reads them back into evidence rows.

## 13. Plugin author testing

We ship `argus-plugin-sdk` as a standalone package so authors can
test locally:

```bash
pip install argus-plugin-sdk
```

```python
# plugins/plugin_dns/tests/test_runner.py
from argus_plugin_sdk.testing import FakeContext, capture_evidence
from argus_dns.runner import DnsPlugin

def test_subdomain_emits_evidence():
    ctx = FakeContext(target={"kind":"domain","value":"example.com"})
    plugin = DnsPlugin()
    with capture_evidence() as evidence:
        plugin.setup()
        # monkeypatch dns.resolve
        ...
        asyncio.run(plugin.run())
        plugin.teardown()
    assert any(e.summary["host"].endswith(".example.com") for e in evidence)
```

`FakeContext` and `capture_evidence` ship with the SDK testing
module.

## 14. Versioning

Plugins follow **SemVer**:

- Major: target schema change.
- Minor: new evidence kinds (additive).
- Patch: bug fixes.

Argus will run only patches automatically. Major/minor upgrades
require admin approval per tenant.

## 15. Why this SDK and not a DSL

- Python is the lingua franca of OSINT.
- Author can reuse existing OS libraries (`dnspython`, `requests`,
  `BeautifulSoup`).
- Type checking with `mypy` is free.
- No new toolchain to learn.

The cost is the sandbox. We pay it in V1 with subprocess + rlimits,
accepting that escape is possible (we monitor for it).

## 16. Plugin telemetry

Each plugin emits `argus_plugins_total{name,status}` counter and
`argus_plugin_duration_seconds{name}` histogram. Sandboxed plugins
also emit custom metrics via `emit_metric(name, value)`.

## 17. Marketplace (V2)

The plugin registry will host community plugins. V1 only ships
first-party plugins in `plugins/`. Registry API is internal; a public
version is post-launch.
