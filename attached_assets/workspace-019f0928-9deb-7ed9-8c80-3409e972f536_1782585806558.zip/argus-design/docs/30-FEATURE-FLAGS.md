# 30 — Feature Flags

> Feature flag system for gradual rollout, plugin enablement, beta
> features, operational kill switches. Lightweight, hot-reloadable,
> tenant-scoped.

---

## 0. Why feature flags

A feature flag is **a switch that controls code path at runtime**
without redeploy. We use them for:

- Gradual rollout of new capabilities (10% → 50% → 100%).
- Tenant-specific opt-in for beta features.
- Plugin enablement per tenant.
- Operational kill switches (turn off a noisy feature fast).
- A/B experiments (with 31-COST-CONTROLLER attribution).

## 1. Position

```
   API request           FeatureFlagService     Config source
       │                       │                     │
       │ is_enabled("foo")     │                     │
       ├──────────────────────►│                     │
       │                       │ cache lookup        │
       │                       │                     │
       │                       │ refresh from Redis  │
       │                       ├────────────────────►│
       │ bool                  │                     │
       │ ◄─────────────────────┤                     │
```

The flag service is read on the hot path. We never block waiting
for a network call inside a request.

## 2. Flag types

```python
class FlagType(str, Enum):
    BOOLEAN = "boolean"
    PERCENTAGE = "percentage"        # 0-100, hash-keyed rollout
    TENANT_LIST = "tenant_list"      # explicit allowlist/blocklist
    VARIANT = "variant"              # A/B/n experiment

@dataclass(slots=True, frozen=True)
class Flag:
    key: str                         # "investigation.deep_scan"
    type: FlagType
    default: Any
    description: str
    owner: str                       # team
    expires_at: datetime | None      # auto-disable
    metadata: Mapping[str, str]
```

Examples:

- `investigation.deep_scan` — percentage, default 0%.
- `plugin.social_x.beta` — tenant_list, default empty.
- `kill_switch.proxy_brightdata` — boolean, default false.
- `experiment.export_layout` — variant, default "v1".

## 3. Storage

Flags live in:

- **Code defaults** (always available): `libs/argus_common/flags.py`.
- **Postgres** (`argus.flags`) for managed flags.
- **Redis** (read-through cache) for hot path.

```sql
CREATE TABLE argus.flag (
    key             TEXT PRIMARY KEY,
    type            TEXT NOT NULL,
    default_value   JSONB NOT NULL,
    current_value   JSONB NOT NULL,
    description     TEXT,
    owner           TEXT,
    expires_at      TIMESTAMPTZ,
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_by      UUID,
    metadata        JSONB NOT NULL DEFAULT '{}'
);
CREATE INDEX flag_expires_idx ON argus.flag (expires_at)
    WHERE expires_at IS NOT NULL;
```

## 4. Evaluation algorithm

```python
def evaluate(flag: Flag, ctx: EvalContext) -> Any:
    if flag.expires_at and flag.expires_at < ctx.now:
        return flag.default
    value = flag.current_value

    if flag.type == FlagType.BOOLEAN:
        return bool(value)
    if flag.type == FlagType.PERCENTAGE:
        return _percentage(value, ctx.tenant_id)
    if flag.type == FlagType.TENANT_LIST:
        if ctx.tenant_id in value.get("allow", []):
            return True
        if ctx.tenant_id in value.get("block", []):
            return False
        return bool(value.get("default", False))
    if flag.type == FlagType.VARIANT:
        bucket = _bucket(ctx.tenant_id, flag.key, len(value["variants"]))
        return value["variants"][bucket]
    return flag.default

def _percentage(value: dict, tenant_id: UUID) -> bool:
    pct = int(value.get("percent", 0))
    if pct <= 0: return False
    if pct >= 100: return True
    h = hashlib.sha256(f"{tenant_id}".encode()).hexdigest()
    bucket = int(h[:8], 16) % 100
    return bucket < pct
```

## 5. Public interface

```python
class FeatureFlags(Protocol):
    def is_enabled(self, key: str, *, tenant_id: UUID | None = None) -> bool: ...
    def variant(self, key: str, *, tenant_id: UUID | None = None) -> str: ...
    def get(self, key: str, *, tenant_id: UUID | None = None) -> Any: ...
    def refresh(self) -> None: ...
    def status(self) -> list[FlagStatus]: ...
```

### 5.1 Usage in code

```python
if feature_flags.is_enabled("investigation.deep_scan",
                             tenant_id=ctx.tenant_id):
    plan = planner.plan(target, options=PlanOptions(deep_scan=True))
else:
    plan = planner.plan(target, options=PlanOptions(deep_scan=False))
```

### 5.2 Plugin gating

```python
def run_plugin(plugin_name, ...):
    flag_key = f"plugin.{plugin_name}.enabled"
    if not feature_flags.is_enabled(flag_key, tenant_id=tenant_id):
        raise PluginDisabledError(plugin_name)
    ...
```

Plugins declare themselves in the catalog; the flag is auto-
provisioned (default false; admin enables per tenant).

## 6. API endpoints

```
GET    /v1/admin/flags                  # list (admin only)
POST   /v1/admin/flags                  # create
PATCH  /v1/admin/flags/{key}            # update value / metadata
DELETE /v1/admin/flags/{key}            # remove (falls back to default)
GET    /v1/admin/flags/{key}/audit      # audit log
```

`PATCH` requires admin scope.

## 7. Caching and refresh

- In-process LRU cache, 1000 entries.
- Refresh every 60s via background task (configurable).
- Hot-reload: SIGHUP to API process triggers immediate refresh
  (admin "reload flags" command).
- Per-tenant override changes propagate within 60s.

```python
class FlagService:
    def __init__(self, redis, pg):
        self._cache = {}
        self._last_refresh = 0
        self._lock = asyncio.Lock()

    async def is_enabled(self, key, *, tenant_id=None) -> bool:
        if time.monotonic() - self._last_refresh > 60:
            await self.refresh()
        flag = self._cache.get(key)
        if flag is None:
            return False
        return evaluate(flag, EvalContext(tenant_id=tenant_id, now=now()))
```

## 8. Gradual rollout pattern

```
1. Flag created at default 0%.
2. Internal team tests at 100% for tenant_id = internal tenant.
3. Canary: 5% of production tenants (hash-keyed, deterministic).
4. 25% — monitor metrics for 24h.
5. 50% — monitor for 48h.
6. 100% — flag becomes permanent; remove via cleanup task.
```

Each percentage change is recorded in `argus.flag_audit`:

```sql
CREATE TABLE argus.flag_audit (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    flag_key        TEXT NOT NULL,
    old_value       JSONB,
    new_value       JSONB NOT NULL,
    actor_id        UUID,
    reason          TEXT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);
```

## 9. Operational kill switches

Flags with type=BOOLEAN and `metadata.kill_switch=true` are
audited separately and paged on activation.

Examples:

- `kill_switch.proxy_brightdata` — turn off paid provider if
  costs spike.
- `kill_switch.scraping_browser` — turn off browser path if
  crash loop detected.
- `kill_switch.plugin.social_x` — turn off a misbehaving plugin.

Activation requires `admin:kill_switch` scope and triggers
immediate Telegram alert to ops.

## 10. Beta features

Tenants can opt into beta features:

```json
{
  "key": "experiment.ai_summary",
  "type": "tenant_list",
  "default": false,
  "allow": ["tenant_uuid_internal", "tenant_uuid_beta_tester"]
}
```

Beta tester onboarding is via admin bot command:

```
/beta enable ai_summary
```

## 11. Plugin enablement

Each plugin has a corresponding flag:

```
plugin.whois.enabled
plugin.dns.enabled
plugin.http_crawl.enabled
plugin.social_x.enabled
plugin.email_hunt.enabled
plugin.shodan.enabled          # paid
plugin.censys.enabled          # paid
```

Default false; admin enables per tenant. Free-tier tenants have
free plugins only (whois, dns, http_crawl, social_x basic).

## 12. Lifecycle — flag

```
   draft (in code) ──► created (in DB) ──► enabled ──► deprecated ──► removed
        │                  │                │           │
        │                  │                │           └─► auto-deleted after 30d
        │                  │                └─► kill_switch activated
        │                  └─► audited (every change)
        └──► never persisted (pure code default)
```

## 13. State diagram — evaluation cache

```
   cold ──► warming ──► hot ──► refreshing ──► hot
             │           │            │
             └──► error  └──► stale   └──► cold (refresh failed)
```

## 14. Failure modes

| Failure | Detection | Recovery |
|---------|-----------|----------|
| Postgres down | connection error | fall back to code defaults; alert |
| Redis down | connection error | use in-memory cache |
| Flag key collision on create | unique violation | reject |
| Tenant not in `allow` | normal | use default |
| Auto-refresh fails | exception | keep last good cache; retry next interval |
| Expired flag | check at eval | use default |

## 15. Security

- `/v1/admin/flags` requires `admin:flags` scope.
- `kill_switch` activation requires `admin:kill_switch` (separate
  scope, dual approval for production).
- Audit is append-only.
- No PII in flag values.

## 16. Scalability

- Eval is O(1) per flag (hash + dict lookup).
- Cache holds 1000 entries ≈ 200 KB.
- Refresh every 60s reads 1000 rows ≈ 50 ms.
- 1M evaluations/sec handled by single API process.

## 17. Configuration

```bash
ARGUS_FLAGS_CACHE_SIZE=1000
ARGUS_FLAGS_REFRESH_INTERVAL_S=60
ARGUS_FLAGS_DEFAULT_KILL_SWITCH_AUDIT_CHAT=
```

## 18. Trade-offs and rationale

| Decision | Rationale | Trade-off |
|----------|-----------|-----------|
| In-process cache | Hot path performance | 60s propagation lag |
| Postgres as source of truth | Durability | One more query at refresh |
| Hash-based percentage rollout | Deterministic, no per-user state | Can't revert cleanly per-user |
| Kill switches as flags | Same mechanism | Need clear naming convention |

## 19. References

- [31-COST-CONTROLLER.md](31-COST-CONTROLLER.md) — Cost attribution
- [32-OBSERVABILITY.md](32-OBSERVABILITY.md) — Metrics per flag
- [13-DEPLOYMENT.md](13-DEPLOYMENT.md) — SIGHUP reload
- [07-PLUGIN-SDK.md](07-PLUGIN-SDK.md) — Plugin enablement
