# 23 — Investigation Graph

> The core intelligence model: how investigations, cases, entities,
> evidence, relationships, and timelines combine into a coherent,
> queryable, conflict-resolved graph. Extends the existing
> investigation schema (03-DATABASE-SCHEMA.md) with graph semantics.

---

## 0. Why a graph model

OSINT is fundamentally relational. A domain has WHOIS contacts;
those contacts have emails; emails appear in breaches; breach entries
link to usernames. Answering "who is behind example.com?" requires
walking these edges.

The existing schema (03) has tables for entities and relationships.
This document adds:

- **Cases** — workspace concept grouping multiple investigations.
- **Timelines** — chronological event stream per investigation.
- **Graph construction algorithm** — deterministic, idempotent.
- **Correlation engine** — heuristic linkers.
- **Merge rules** — when two nodes are the same thing.
- **Conflict resolution** — when two sources disagree.
- **Graph queries** — typed, versioned.

## 1. Domain model

```
                ┌──────────┐
                │  Tenant  │
                └─────┬────┘
                      │ owns
                ┌─────▼────┐         contains   ┌─────────────┐
                │   Case   │───────────────►    │ Investigation│
                └─────┬────┘                    └──────┬──────┘
                      │                                 │ produces
                      │ groups                          │
                      │ across investigations           │
                      │                                 ▼
                      │                          ┌──────────────┐
                      └──────────────────────────┤   Evidence   │
                                                 └──────┬───────┘
                                                        │ supports
                                                        ▼
                ┌──────────────┐              ┌──────────────────┐
                │   Entity     │◄─────────────┤   Relationship   │
                └──────────────┘              └──────────────────┘
                       ▲                              │
                       └────── cited by ──────────────┘
                                                          │
                                                          ▼
                                                 ┌──────────────┐
                                                 │   Timeline   │
                                                 └──────────────┘
```

## 2. Case

A `Case` is a long-running workspace that can span multiple
investigations, plugins, and time windows. Use cases:

- "Due diligence on Acme Corp" → case with 5 investigations over
  6 months.
- "Background check on candidate X" → case with email + social +
  breach investigations.
- "Brand protection for argus.saas" → case with continuous
  monitoring.

```sql
CREATE TABLE investigation.case (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id       UUID NOT NULL REFERENCES identity.tenant(id),
    owner_id        UUID NOT NULL REFERENCES identity."user"(id),
    title           TEXT NOT NULL,
    description     TEXT,
    status          TEXT NOT NULL DEFAULT 'open',
    tags            TEXT[] NOT NULL DEFAULT '{}',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    closed_at       TIMESTAMPTZ,
    CONSTRAINT case_status_chk CHECK (status IN ('open','closed','archived'))
);
CREATE INDEX case_tenant_idx ON investigation.case (tenant_id, status);
```

A case has a shared **entity pool**. Entities discovered in any
investigation within the case are visible to all. This is the
"merge" feature across investigations.

## 3. Entity

Extends the existing `investigation.entity` with:

- `case_id` (nullable) — for cross-investigation merging.
- `tenant_entity_id` — links to a canonical per-tenant entity
  (see §6 Merge).
- `aliases` — historical names.
- `last_seen_at`, `first_seen_at` (already exist).
- `confidence` (already on evidence; new on entity).

```sql
ALTER TABLE investigation.entity
    ADD COLUMN case_id UUID REFERENCES investigation.case(id) ON DELETE SET NULL,
    ADD COLUMN tenant_entity_id UUID,
    ADD COLUMN confidence REAL NOT NULL DEFAULT 1.0 CHECK (confidence BETWEEN 0 AND 1);
CREATE INDEX entity_case_idx ON investigation.entity (case_id);
CREATE INDEX entity_tenant_entity_idx ON investigation.entity (tenant_entity_id);
```

## 4. Evidence

Already defined in schema. We extend with:

- `extracted_from_url` (already exists as `source_url`).
- `captured_by_plugin` (already on plugin_run).
- `verification_status` — see 26-EVIDENCE-SCORING.
- `conflict_with` — list of evidence IDs that disagree.

## 5. Relationship

Already defined. We extend with:

- `case_id` (nullable).
- `tenant_relationship_id` — for cross-investigation merge.
- `derivation` — `direct` (one source says so), `inferred`
  (heuristic), `cross-investigation` (linked from another case).

## 6. Timeline

A timeline is a chronologically-ordered stream of events for an
investigation or case.

```sql
CREATE TABLE investigation.timeline_event (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    investigation_id UUID REFERENCES investigation.investigation(id) ON DELETE CASCADE,
    case_id         UUID REFERENCES investigation.case(id) ON DELETE CASCADE,
    occurred_at     TIMESTAMPTZ NOT NULL,
    event_type      TEXT NOT NULL,           -- 'evidence.found','entity.merged',...
    summary         TEXT NOT NULL,
    payload         JSONB NOT NULL DEFAULT '{}',
    confidence      REAL NOT NULL DEFAULT 1.0,
    CONSTRAINT timeline_event_type_chk CHECK (event_type IN (
        'investigation.created','investigation.completed',
        'evidence.found','evidence.disputed',
        'entity.found','entity.merged','entity.disputed',
        'relationship.found','relationship.disputed',
        'plugin.finished','plugin.failed',
        'manual.note','manual.override'
    )),
    CONSTRAINT timeline_belongs_to_chk CHECK (
        (investigation_id IS NOT NULL)::int + (case_id IS NOT NULL)::int = 1
    )
);
CREATE INDEX timeline_event_investigation_idx
    ON investigation.timeline_event (investigation_id, occurred_at DESC);
CREATE INDEX timeline_event_case_idx
    ON investigation.timeline_event (case_id, occurred_at DESC);
```

`manual.note` and `manual.override` are analyst annotations;
visibility is admin/owner only by default.

## 7. Graph construction

The graph is built **incrementally** as evidence arrives. Algorithm:

```
on evidence.found(payload):
    e = upsert_entity(payload.canonical_value, payload.kind)
    for attr in payload.attributes:
        if attr is entity-like (email, domain, ip, ...):
            child = upsert_entity(attr.value, attr.kind)
            upsert_relationship(e, child, attr.relation, weight=1.0, evidence=[ev.id])
    timeline.append('evidence.found', payload)
    emit('entity.found', {...}) if new
    emit('relationship.found', {...}) if new
```

`upsert_entity` is idempotent — within an investigation, the same
`(type, value)` tuple produces one row. See §9 Merge for cross-
investigation behavior.

## 8. Correlation engine

The CorrelationEngine applies **heuristic rules** that suggest
additional edges the plugins didn't directly observe. All inferred
edges are marked `derivation='inferred'` and have lower default
confidence (0.6).

Rules:

| Rule | When | Edge |
|------|------|------|
| WHOIS contact → email | WHOIS registrant_email | `contact → email` `has_email` |
| WHOIS contact → org | WHOIS registrant_org | `contact → org` `member_of` |
| DNS A record → IP | DNS A response | `domain → ip` `resolves_to` |
| DNS MX → email provider | DNS MX response | `domain → org` `uses_mail` |
| Email → username | Email local part | `email → username` `has_username` |
| Breach entry → person | Breach contains email | `breach_entry → email` `leaked` |
| Subdomain → parent | DNS hierarchy | `subdomain → domain` `subdomain_of` |
| Same phone → person | Phone in two profiles | merges (see §9) |
| Same ASN → org | Two domains same ASN | `domain → org` `hosted_by` |

Adding a new rule: register in `correlation_rules.yaml` with a
test fixture. Rules are deterministic and pure (no IO).

## 9. Merge rules

When two entities might be the same thing, we merge them. The
merge rule is **canonicalization + fuzzy match**.

### 9.1 Canonicalization (per type)

| Type | Canonical form |
|------|----------------|
| email | lowercase, strip `+tag` |
| domain | lowercase, strip trailing dot, IDN → punycode |
| subdomain | lowercase, strip trailing dot |
| url | lowercase scheme + host, strip fragment, sort query keys |
| phone | E.164 format |
| ip | canonical (no leading zeros) |
| username | lowercase, strip surrounding whitespace |
| person | lowercase full_name, remove punctuation |
| organization | lowercase, strip legal suffixes (`LLC`, `Inc`, `GmbH`) |

See [25-NORMALIZATION.md](25-NORMALIZATION.md) for the full
normalizer.

### 9.2 Fuzzy match

After canonicalization, fuzzy match uses:

- Email: exact match.
- Domain / subdomain: exact match.
- Phone: exact (E.164).
- IP: exact.
- Username: exact + Levenshtein ≤ 2 on longer strings.
- Person: Levenshtein ≤ 3 + token overlap ≥ 0.6 on first/last.
- Organization: token Jaccard ≥ 0.7.

When match succeeds within an investigation, the second entity is
**merged** into the first: a single row with `aliases` updated.

### 9.3 Cross-investigation merge (Case mode)

If a case spans investigations, entities with the same canonical
form are merged across the case. We use `tenant_entity_id` to
point to a per-tenant canonical row.

### 9.4 Merge auditability

Every merge writes a `timeline_event` of type `entity.merged` with
the source IDs and the resulting canonical ID. **Merges are not
silently destructive.**

## 10. Conflict resolution

When two sources disagree:

| Conflict | Resolution |
|----------|------------|
| Same person, different name spelling | Keep both as aliases; canonical = most recent |
| Same domain, different WHOIS | Keep all WHOIS records; `evidence_count` per source |
| Same email, different breach lists | All breaches kept; confidence is union (max) |
| Same phone, different country code | Pick E.164 with most evidence |
| Same IP, different ASNs | Pick most recent; flag for analyst review |
| A says X registered by Y, B says X registered by Z | Both kept with their evidence; mark `disputed` |
| Same relationship, different weight | Weighted average |

Disputed relationships get `confidence = 0.5` and a
`timeline_event.entity.disputed`. Analyst can resolve via manual
override (26-EVIDENCE-SCORING §8).

## 11. Graph queries

V1 supports:

### 11.1 `GET /v1/investigations/{id}/graph?depth=N&from=...&to=...`

Returns DOT source (for Graphviz rendering) plus optional JSON
adjacency list.

### 11.2 `GET /v1/entities/{id}/related?depth=N&kinds=...`

BFS up to `depth=N` (max 3). Returns entities + edges with weights.

### 11.3 `GET /v1/cases/{id}/graph`

Case-level graph: union of all investigation graphs, merged.

### 11.4 `POST /v1/investigations/{id}/graph/query`

A small query language:

```json
{
  "find": "shortest_path",
  "from": {"type": "person", "value": "Alice"},
  "to":   {"type": "domain", "value": "example.com"},
  "max_depth": 5
}
```

V1 supports `shortest_path`, `neighbors`, `common_neighbors`.
More in V2.

### 11.5 Streaming for large graphs

Graphs with > 1000 nodes return as Server-Sent Events, one node
per event, so the bot (or web) can render progressively.

## 12. State diagrams

### 12.1 Entity lifecycle

```
   discovered ──► normalized ──► merged ──► stable
        │              │           │          │
        └─► disputed ──┘           └─► retired (GDPR)
```

### 12.2 Relationship lifecycle

```
   proposed ──► confirmed ──► stable
        │           │           │
        └──► disputed ◄────────┘
                  │
                  └──► manually_resolved
```

## 13. Failure modes

| Failure | Detection | Recovery |
|---------|-----------|----------|
| Merge produces too many aliases | aliases > 100 | quarantine entity; alert |
| Fuzzy match returns false positive | manual dispute | split entity; rollback aliases |
| Graph query exceeds recursion | depth > 3 | refuse query |
| Cross-investigation merge exceeds budget | merge cost > limit | split case |

## 14. Security

- Graph queries are tenant-scoped. Cross-tenant queries refused.
- Manual overrides are role-gated (admin/owner) and audited.
- Entity merges do not delete source rows; original evidence
  remains queryable.

## 15. Scalability — millions of investigations

- Graph storage is per-investigation, partitioned by month
  (already).
- Cross-investigation merge runs in a Celery task per case.
- DOT generation is O(V + E); for V1 we cap at 5,000 nodes per
  investigation. Beyond that, we deliver a sampled subgraph.
- Graph queries use indexed lookups (entity.type + entity.value).

Per-investigation size budget: 5,000 entities, 10,000 relationships.
Beyond that we recommend splitting into a case.

## 16. Configuration

```bash
ARGUS_GRAPH_MAX_NODES_PER_INVESTIGATION=5000
ARGUS_GRAPH_MAX_RELATIONSHIPS=10000
ARGUS_GRAPH_MAX_DEPTH=3
ARGUS_GRAPH_MERGE_FUZZY_THRESHOLD=0.7
ARGUS_GRAPH_STREAM_THRESHOLD=1000
```

## 17. Trade-offs and rationale

| Decision | Rationale | Trade-off |
|----------|-----------|-----------|
| Case is workspace, not entity | Better UX for long-running OSINT | One more table |
| Heuristic correlation rules | Discover hidden links | False positives |
| Merge is audit, not delete | Compliance + debugging | More rows |
| Tenant canonical entities | Cross-investigation merge | Storage cost |
| DOT output for graph | Easy rendering in Telegram | Not JSON-native |

## 18. References

- [03-DATABASE-SCHEMA.md](03-DATABASE-SCHEMA.md) — Base schema
- [24-PLANNER.md](24-PLANNER.md) — Produces entities
- [25-NORMALIZATION.md](25-NORMALIZATION.md) — Canonicalization
- [26-EVIDENCE-SCORING.md](26-EVIDENCE-SCORING.md) — Confidence
- [29-EXPORT-PIPELINE.md](29-EXPORT-PIPELINE.md) — Graph export
- [28-SCHEDULER.md](28-SCHEDULER.md) — Case-driven monitoring
