# 17 — Testing Strategy

## 0. Goals

- Tests run in CI on every PR.
- Tests run on Termux (`./scripts/test.sh`).
- Fast feedback: unit tests < 10 s total.
- Integration tests use a real Postgres + Redis (testcontainers or
  local).
- Bot is tested as a black box (mocked API client).
- Worker is tested against a real Redis and a stubbed plugin runtime.
- Domain is tested with property-based tests (`hypothesis`).
- Load tests are opt-in (`-m load`).

## 1. Pytest layout

```
pyproject.toml
conftest.py                       # repo-root fixtures
pytest.ini
tests/
├── conftest.py
├── fixtures/
│   ├── plugins/
│   │   └── stub_plugin.py
│   └── data/
│       └── plugin_manifest.toml
├── e2e/
│   ├── test_full_investigation.py
│   └── test_auth_flow.py
└── load/
    ├── locustfile.py
    └── scenarios.py
services/
├── api/tests/
│   ├── conftest.py
│   ├── test_auth.py
│   ├── test_investigations.py
│   ├── test_evidence.py
│   ├── test_plugins.py
│   ├── test_exports.py
│   └── contract/
│       ├── test_openapi.py
│       └── test_error_codes.py
├── bot/tests/
│   ├── conftest.py
│   ├── test_handlers.py
│   ├── test_renderers.py
│   ├── test_callbacks.py
│   └── test_i18n.py
└── worker/tests/
    ├── conftest.py
    ├── test_tasks.py
    ├── test_plugin_runtime.py
    └── test_planner.py
domain/tests/
├── conftest.py
├── test_investigation.py
├── test_evidence.py
├── test_entities.py
└── test_relationships.py
libs/
├── argus_common/tests/
│   ├── conftest.py
│   ├── test_jwt.py
│   ├── test_ratelimit.py
│   └── test_events.py
└── argus_db/tests/
    ├── conftest.py
    └── test_repositories.py
```

## 2. Markers

Defined in `pytest.ini`:

```ini
[pytest]
markers =
    unit: pure logic, no I/O
    integration: needs DB or Redis
    contract: API/event contract
    slow: takes > 1 s
    load: load tests, opt-in
addopts = -ra --strict-markers
asyncio_mode = auto
testpaths = tests services domain libs
```

By default, `./scripts/test.sh` runs everything **except load**:

```
pytest tests/ services/api/tests services/bot/tests services/worker/tests \
       -m "not load"
```

## 3. Test database

A throwaway Postgres is created per test session:

```python
# conftest.py
import os
import pytest_asyncio
from sqlalchemy.ext.asyncio import create_async_engine

@pytest_asyncio.fixture(scope="session")
async def pg_engine():
    url = os.environ["TEST_DATABASE_URL"]
    engine = create_async_engine(url, echo=False, pool_size=5)
    async with engine.begin() as conn:
        from argus_db.models import Base
        await conn.run_sync(Base.metadata.create_all)
    yield engine
    await engine.dispose()

@pytest_asyncio.fixture
async def pg_session(pg_engine):
    async with pg_engine.begin() as conn:
        async with conn.begin_nested() as txn:
            yield conn
            await txn.rollback()
```

`TEST_DATABASE_URL` points to a local Postgres in dev (`proot`) or
to a Neon branch in CI. We **never** share dev DB.

## 4. Test Redis

```python
# conftest.py
import pytest_asyncio
import redis.asyncio as aioredis

@pytest_asyncio.fixture
async def redis_client():
    r = aioredis.from_url(os.environ["TEST_REDIS_URL"])
    await r.flushdb()
    yield r
    await r.flushdb()
    await r.aclose()
```

## 5. Auth fixture

```python
@pytest.fixture
def jwt_factory():
    from argus_common.auth.jwt import ArgusClaims, encode_jwt
    def make(user_id, tenant_id, scopes=("investigation:read",),
             role="member", ttl=900):
        claims = ArgusClaims(
            sub=str(user_id), tid=str(tenant_id),
            role=role, scopes=list(scopes),
            iss="argus.auth", aud="argus.api",
            iat=int(time.time()),
            exp=int(time.time()) + ttl,
            jti=str(uuid.uuid4()),
            telegram_id=12345,
            plan="free",
        )
        return encode_jwt(claims)
    return make
```

## 6. API tests (httpx AsyncClient)

```python
# services/api/tests/test_investigations.py
import pytest

@pytest.mark.integration
async def test_create_investigation(client, jwt_factory, user, tenant):
    token = jwt_factory(user.id, tenant.id)
    r = await client.post(
        "/v1/investigations",
        headers={"Authorization": f"Bearer {token}"},
        json={"title": "Scan x",
              "target": {"kind": "domain", "value": "example.com"},
              "plugins": ["whois"]},
    )
    assert r.status_code == 202
    body = r.json()
    assert body["status"] == "pending"
    assert body["target"]["value"] == "example.com"

@pytest.mark.integration
async def test_create_invalid_target(client, jwt_factory, user, tenant):
    token = jwt_factory(user.id, tenant.id)
    r = await client.post(
        "/v1/investigations",
        headers={"Authorization": f"Bearer {token}"},
        json={"title": "x",
              "target": {"kind": "domain", "value": "not a domain"},
              "plugins": ["whois"]},
    )
    assert r.status_code == 400
    body = r.json()
    assert body["code"] == "invalid_input"

@pytest.mark.contract
async def test_openapi_published(client):
    r = await client.get("/openapi.json")
    assert r.status_code == 200
    spec = r.json()
    assert "/v1/investigations" in {p: ... for p in spec["paths"]}
```

`client` fixture:

```python
# services/api/tests/conftest.py
import pytest_asyncio
from httpx import AsyncClient, ASGITransport
from argus_api.main import create_app

@pytest_asyncio.fixture
async def client(pg_engine, redis_client):
    app = create_app()
    async with AsyncClient(
        transport=ASGITransport(app=app),
        base_url="http://test",
    ) as client:
        yield client
```

## 7. Bot tests (aiogram TestClient)

We don't run a real bot. We call handlers directly with a mocked
`Bot`, `Dispatcher`, and `ArgusApiClient`.

```python
# services/bot/tests/test_handlers.py
import pytest
from unittest.mock import AsyncMock
from aiogram.methods import SendMessage, EditMessageText
from argus_bot.handlers.menu import on_menu
from argus_bot.callbacks import MenuAction

@pytest.mark.asyncio
async def test_main_menu_renders():
    bot = AsyncMock()
    cb = AsyncMock()
    cb.from_user.id = 12345
    cb.message = AsyncMock()
    cb.message.edit_text = AsyncMock()
    cb.answer = AsyncMock()
    cb.data = MenuAction(action="new").pack()

    fake_api = AsyncMock()
    fake_api.me.return_value = UserDTO(id="...", telegram_id=12345,
                                        full_name="Alice", locale="en")

    state = AsyncMock()
    await on_menu(cb, callback_data=MenuAction(action="new"),
                  state=state, api=fake_api, user=UserDTO(...))

    cb.message.edit_text.assert_awaited_once()
    text = cb.message.edit_text.await_args.args[0]
    assert "New Investigation" in text or "new_investigation" in text
```

## 8. Worker tests

We test task functions directly. Plugin runtime tests use a stub
plugin in `tests/fixtures/plugins/stub_plugin.py`.

```python
# services/worker/tests/test_plugin_runtime.py
import pytest
from argus_worker.plugin_runtime.loader import load_plugin
from argus_worker.plugin_runtime.sandbox import Sandbox

@pytest.mark.integration
async def test_stub_plugin_emits_evidence():
    plugin = load_plugin("stub", "0.1.0")
    sandbox = Sandbox(
        plugin=plugin,
        capabilities={"dns": ["8.8.8.8"], "storage": "rw"},
        timeout=30,
    )
    records = []
    async for record in sandbox.run({"target": "example.com"}):
        records.append(record)
    assert any(r["type"] == "evidence" for r in records)
```

## 9. Domain property tests

```python
# domain/tests/test_investigation.py
from hypothesis import given, strategies as st
from argus_domain.investigations.aggregate import Investigation
from argus_domain.investigations.target import Target

@given(
    kind=st.sampled_from(["domain","email","ip"]),
    value=st.text(min_size=1, max_size=100),
)
def test_investigation_invariants(kind, value):
    t = Target(kind=kind, value=value)
    inv = Investigation(target=t, title="x", owner_id=uuid.uuid4(),
                        tenant_id=uuid.uuid4())
    assert inv.status == "pending"
    assert inv.progress_pct == 0
    inv.start()
    assert inv.status == "running"
    inv.add_evidence(kind="dns_record")
    assert inv.evidence_count == 1
```

## 10. Event contract tests

Stored event samples in `libs/argus_common/events/tests/samples/*.json`.
Each sample is a real event captured from a running dev environment.

```python
@pytest.mark.parametrize("sample",
                         sorted(Path("samples").glob("*.json")))
def test_event_sample_validates(sample):
    event = DomainEvent.model_validate_json(sample.read_text())
    # round-trip
    assert event.model_dump_json() == sample.read_text().strip()
```

Plus a **producer/consumer schema drift** test:

```python
def test_produced_event_matches_schema():
    event = build_investigation_created(...)
    schema = load_schema("investigation.created")
    validate(event, schema)
```

## 11. Plugin SDK tests (plugin authors)

```python
# plugins/plugin_dns/tests/test_runner.py
import pytest
from argus_plugin_sdk.testing import FakeContext, capture_evidence
from argus_dns.runner import DnsPlugin

@pytest.mark.asyncio
async def test_subdomain_emitted():
    ctx = FakeContext(target={"kind":"domain","value":"example.com"})
    plugin = DnsPlugin()
    plugin.setup()
    with capture_evidence() as ev:
        await plugin.run()
    assert any(e.summary["host"].endswith(".example.com") for e in ev)
```

The SDK ships `FakeContext`, `capture_evidence`, `fake_http`,
`fake_dns` so authors don't need a live Argus.

## 12. Coverage

Coverage configuration in `pyproject.toml`:

```toml
[tool.coverage.run]
source = ["argus_api","argus_bot","argus_worker","libs","domain"]
branch = true
omit = ["*/tests/*","*/migrations/*"]

[tool.coverage.report]
show_missing = true
skip_covered = false
fail_under = 70
```

Thresholds:

| Area | Target |
|------|--------|
| Domain | 95% |
| API services | 85% |
| Bot | 80% |
| Worker | 80% |
| Plugins | 60% (author responsibility) |

## 13. E2E tests (Playwright + Telegram test API)

V1 doesn't use Playwright. E2E runs against a real Telegram test
account:

```python
# tests/e2e/test_full_investigation.py
@pytest.mark.e2e
async def test_full_investigation_via_bot():
    bot_token = os.environ["TEST_BOT_TOKEN"]
    test_chat_id = os.environ["TEST_CHAT_ID"]
    # Send /start, then "Scan example.com"
    # Wait for "completed" message
    # Assert evidence count > 0
```

Marked `@pytest.mark.slow`. Run on staging deploys.

## 14. Load tests (Locust)

```python
# tests/load/locustfile.py
from locust import HttpUser, task, between

class ArgusUser(HttpUser):
    wait_time = between(1, 5)
    token: str

    def on_start(self):
        # exchange API key for JWT
        r = self.client.post("/v1/auth/api-key",
                             json={"api_key": "argus_live_..."})
        self.token = r.json()["access_token"]

    @task(3)
    def list_investigations(self):
        self.client.get("/v1/investigations",
                        headers={"Authorization": f"Bearer {self.token}"})

    @task(1)
    def create_investigation(self):
        self.client.post("/v1/investigations",
            headers={"Authorization": f"Bearer {self.token}"},
            json={"title":"load","target":{"kind":"domain","value":"example.com"},
                  "plugins":["whois"]})

    @task(2)
    def get_investigation(self):
        # use a known id from setUp
        ...
```

Run: `locust -f tests/load/locustfile.py -u 100 -r 10 --host https://staging.argus.saas`

## 15. What we test for

- **Correctness**: handler does the right thing.
- **Errors**: error paths return correct code/status.
- **Concurrency**: two parallel `start_investigation` don't double-charge quota.
- **Idempotency**: same key + same payload returns cached response.
- **Auth**: missing/bad/expired tokens all return correct 401.
- **Quotas**: at-limit, beyond-limit.
- **Rate limit**: 6th `start_investigation` in 60 s returns 429.
- **Pagination**: cursor encoding round-trip.
- **Audit**: every state change writes `audit.event`.
- **Idempotency on tasks**: same task twice → same effect.

## 16. What we don't test

- UI rendering details (manual).
- Telegram-side delivery (manual via real test chat).
- Vendor plugin correctness (plugin author's responsibility).

## 17. Flaky test policy

A test is flaky if it fails < 1% of runs without code change.

- Mark `@pytest.mark.flaky(reruns=3, reruns_delay=2)`.
- File an issue to fix root cause within 2 weeks.
- Tests that remain flaky for a month are deleted or quarantined
  (`-m flaky` only on demand).

## 18. CI integration

CI runs:

```yaml
- name: Lint
  run: ./scripts/lint.sh

- name: Unit
  run: pytest -m "unit" -q

- name: Integration
  run: pytest -m "integration" -q

- name: Contract
  run: pytest -m "contract" -q

- name: Coverage
  run: ./scripts/test.sh --no-cov-fail-under
```

Branch protection: merge to main only if all green.

## 19. Test data

- Sample plugin output fixtures in `tests/fixtures/`.
- Sample user JWTs in `tests/fixtures/jwt/`.
- DB seed YAML in `libs/argus_db/seed/`.
- Plugin manifests in `tests/fixtures/plugins/`.

## 20. The "test pyramid" we maintain

```
        ╱╲
       ╱  ╲      E2E       (slow, run on staging)
      ╱────╲
     ╱      ╲    Integration (real DB+Redis, run in CI)
    ╱────────╲
   ╱          ╲  Contract    (OpenAPI, event schemas)
  ╱────────────╲
 ╱              ╲ Unit       (pure logic, run on save)
╱────────────────╲
```

We invest most in **unit** (fast feedback), then **integration**
(real environment), then **contract** (compatibility), then a thin
**E2E** layer.
