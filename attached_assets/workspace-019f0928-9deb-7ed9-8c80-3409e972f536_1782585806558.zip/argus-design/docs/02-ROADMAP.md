# 02 — Development Roadmap

## 0. Constraints that drive the plan

- **One developer, one Android phone.** Anything that requires multiple
  humans to coordinate is bad. Anything that can be batched into a
  long tmux session is good.
- **Free-tier deploy from day one.** We cannot lean on a paid staging
  environment. The first deploy must be the cheapest viable deploy.
- **No skipping steps.** Authentication, logging, error handling, and
  tests are foundational — building features before them creates
  debt we cannot afford at solo-dev velocity.
- **Vertical slices.** Each phase ships end-to-end (API + Bot + Worker
  + DB + test) for one capability. Horizontal layers ("first build
  the whole DB") is slower feedback.

## 1. Phase overview

| # | Phase | Goal | Duration | Exit criterion |
|---|-------|------|----------|----------------|
| 0 | Bootstrap | Repo, deps, CI, deploy skeleton, observability | 3 days | `tmux-dev.sh start` shows `/health` returning 200 on Railway |
| 1 | Identity & Auth | User, tenant, JWT, Telegram login, API keys | 4 days | Bot `/start` issues JWT; API rejects bad tokens |
| 2 | Investigation Core | Plan → run → evidence → entities → relations | 7 days | One end-to-end OSINT scan completes via bot command |
| 3 | Plugin SDK & Runtime v1 | Plugin authoring + sandboxed execution | 5 days | `plugin_whois` runs in subprocess; third-party can build `plugin_dns` |
| 4 | Bot UX | All menu items live, message editing, progress | 5 days | Bot drives a full investigation without `/help` |
| 5 | Exports | JSON, CSV, PDF render in worker; bot downloads | 4 days | User exports a real investigation, file opens |
| 6 | Billing | Stripe, quotas, upgrade flow, free tier | 5 days | Paying user can run 500 investigations/month |
| 7 | Hardening | Load tests, SLOs, runbooks, on-call | 5 days | Sustained 100 concurrent investigations pass soak test |
| 8 | Intelligence Engine | Scraping, browser pool, proxy, anti-bot, scoring, graph | 12 days | Full OSINT investigation on real target via browser path |
| 9 | Runtime Hardening | Plugin runtime isolation, capability model, secrets, upgrades | 5 days | Third-party plugin runs with declared caps; quarantine works |
| 10 | Source Registry & Workflow | Central source catalog, DAG execution, resumable investigations | 5 days | 5 strategies implemented; investigation pauses/resumes correctly |
| 11 | Scheduler & Cost Polish | Watchlists, delta detection, alert routing, free-tier cap | 4 days | Free-tier tenant respects budget; watchlist fires alert |
| 12 | GDPR, Audit, Onboarding | Compliance docs, audit chain, onboarding flow | 4 days | GDPR delete works; audit chain verifiable; new user completes first investigation |

Total: ~61 working days. Calendar: ~14 weeks with overhead.

## 2. Phase 0 — Bootstrap (Days 1–3)

**Goal:** A deployable "hello world" API + bot with full observability.

Tasks:

- [ ] Initialize monorepo: `git init`, `pyproject.toml`, `uv.lock`.
- [ ] Bootstrap `domain/`, `libs/argus_common`, `libs/argus_db`.
- [ ] Configure `ruff`, `mypy --strict`, `pre-commit`.
- [ ] Wire `import-linter` for boundary enforcement.
- [ ] Build `services/api` skeleton: `/health`, `/ready`, `/metrics`.
- [ ] Build `services/bot` skeleton: `/start` and `/help`.
- [ ] Wire `structlog` with correlation ID.
- [ ] Wire Sentry SDK.
- [ ] Build `ops/railway/railway.toml` + Dockerfile.api + Dockerfile.bot.
- [ ] Build GH Actions: lint, test, build, deploy-preview.
- [ ] Deploy to Railway preview env. Verify `/health` green.
- [ ] Author `scripts/termux-bootstrap.sh`, `scripts/tmux-dev.sh`.

Exit:

```bash
$ curl https://argus-api-preview.up.railway.app/health
{"status":"ok","version":"0.1.0","db":"up","redis":"up"}
```

References: [00-ARCHITECTURE.md](00-ARCHITECTURE.md), [14-TERMUX-WORKFLOW.md](14-TERMUX-WORKFLOW.md), [18-CICD.md](18-CICD.md).

## 3. Phase 1 — Identity & Auth (Days 4–7)

**Goal:** Bot can identify a Telegram user, issue a JWT, and the API trusts it.

Tasks:

- [ ] `users`, `tenants`, `api_keys`, `sessions` tables.
- [ ] `argus_common.auth.jwt` — RS256 signing, public key from env.
- [ ] `argus_common.auth.telegram` — Telegram Login Widget verification.
- [ ] `/v1/auth/telegram` — bot exchanges initData for JWT.
- [ ] `/v1/auth/refresh` — rotation.
- [ ] `/v1/auth/api-key` — for non-Telegram clients.
- [ ] FastAPI dependency `CurrentUser`, `CurrentTenant`.
- [ ] Rate limiter middleware (token bucket).
- [ ] Bot `/start` registers the user, issues JWT, stores in Redis FSM storage.
- [ ] Tests: JWT round-trip, expired token, bad signature, replay.

Exit: Bot `/start` followed by `me` command shows user ID, tenant ID, quota remaining.

References: [08-AUTHENTICATION.md](08-AUTHENTICATION.md).

## 4. Phase 2 — Investigation Core (Days 8–14)

**Goal:** A user can target a domain, watch the system collect evidence, see entities and relationships.

Tasks:

- [ ] `investigations`, `evidence`, `entities`, `relationships` tables.
- [ ] `Investigation` aggregate with `start/pause/resume/cancel`.
- [ ] Planner domain service (24) — given target + active plugins, produces a DAG.
- [ ] Celery chord: `plan → fan-out → reduce → extract`.
- [ ] Redis Streams event bus: `investigation.created`, `evidence.found`, etc.
- [ ] First plugin: `plugin_whois` (RDAP lookup).
- [ ] Second plugin: `plugin_dns` (subdomain brute via public lists).
- [ ] Entity extractor (regex + spaCy small_en model, optional).
- [ ] Relationship builder: co-occurrence graph.
- [ ] Bot: progress view, refresh button, view-evidence button.
- [ ] Tests: planner correctness, sandbox containment, idempotency.

Exit: Bot command "scan example.com" returns ≥ 10 evidence items and ≥ 5 entities in < 60 seconds.

References: [23-INVESTIGATION-GRAPH.md](23-INVESTIGATION-GRAPH.md), [24-PLANNER.md](24-PLANNER.md), [25-NORMALIZATION.md](25-NORMALIZATION.md).

## 5. Phase 3 — Plugin SDK & Runtime v1 (Days 15–19)

**Goal:** A third-party developer can write a plugin from docs alone.

Tasks:

- [ ] Define `PluginManifest` (TOML) — see [07 §2](07-PLUGIN-SDK.md).
- [ ] `PluginContract` Protocol — `setup(ctx)`, `run(input)`, `teardown(ctx)`.
- [ ] **Plugin runtime (33)**: subprocess model, IPC, rlimits, capabilities.
- [ ] RestrictedPython sandbox + subprocess.
- [ ] Plugin registry service — install, list, enable, disable.
- [ ] Plugin catalog endpoint: `/v1/plugins`.
- [ ] Admin bot commands: `/admin plugin install <name>`.
- [ ] Sample plugins: `plugin_email_hunt`, `plugin_social_x`.
- [ ] Plugin author docs in `docs/PLUGIN-AUTHOR.md`.

Exit: External author writes a plugin that passes `plugin_sdk.test` test suite and is approved in < 1 hour.

References: [07-PLUGIN-SDK.md](07-PLUGIN-SDK.md), [33-PLUGIN-RUNTIME.md](33-PLUGIN-RUNTIME.md).

## 6. Phase 4 — Bot UX (Days 20–24)

**Goal:** Every menu item works. Every investigation renders. Every export downloads.

Tasks:

- [ ] Main menu keyboard (inline).
- [ ] FSM flows: new investigation, settings, profile.
- [ ] Investigation screen with progress bar.
- [ ] Live progress — bot long-polls event bus, edits same message.
- [ ] View evidence: paginated inline list.
- [ ] View timeline: chronological list.
- [ ] View graph: image (Graphviz → PNG → Telegram).
- [ ] All callback data ≤ 64 bytes.
- [ ] i18n — English and Russian strings.
- [ ] Throttling middleware per user.
- [ ] Empty states and error states.
- [ ] `/help` and `/cancel` always work.

Exit: A new user with no prior interaction completes a full investigation using only menu buttons.

References: [05-TELEGRAM-BOT.md](05-TELEGRAM-BOT.md).

## 7. Phase 5 — Exports (Days 25–28)

**Goal:** Every investigation can be exported in JSON, CSV, PDF.

Tasks:

- [ ] Export formats: JSON (canonical), CSV (flat), PDF (paginated).
- [ ] Celery task `argus.export.render` reads investigation, builds blob, uploads to R2.
- [ ] Bot "Export JSON / CSV / PDF" buttons.
- [ ] Exports > 50 MB are split into parts.
- [ ] Watermark on PDF for free tier.
- [ ] Exports expire after 7 days.
- [ ] `exports` table tracks metadata.

Exit: User exports a 1k-evidence investigation and downloads all three formats.

References: [29-EXPORT-PIPELINE.md](29-EXPORT-PIPELINE.md), [27-ARTIFACT-STORAGE.md](27-ARTIFACT-STORAGE.md).

## 8. Phase 6 — Billing (Days 29–33)

Tasks:

- [ ] `plans`, `subscriptions`, `invoices`, `quotas` tables.
- [ ] Stripe integration: products, prices, webhooks.
- [ ] `/v1/billing/checkout`, `/v1/billing/webhook`.
- [ ] Bot `/billing` command → Stripe Checkout URL.
- [ ] Quota middleware.
- [ ] Free-tier limits: 20 inv/month, 1 concurrent, 25 MB export.
- [ ] Pro tier limits: 500 inv/month, 5 concurrent, 250 MB export.
- [ ] Trial: 14 days, no card, Pro limits.

Exit: User upgrades from Free to Pro via bot, immediately runs 100 investigations without 429.

References: [31-COST-CONTROLLER.md](31-COST-CONTROLLER.md).

## 9. Phase 7 — Hardening (Days 34–38)

Tasks:

- [ ] Load test with Locust: 100 concurrent investigations, sustained 10 min.
- [ ] Pool plugin runtimes: keep warm Python processes per plugin.
- [ ] SLOs: API p99 < 300 ms, bot edit < 2 s, worker p95 < 30 s.
- [ ] Chaos tests: kill Redis mid-task, kill Postgres connection.
- [ ] Document runbooks.
- [ ] Backups: nightly `pg_dump` to R2.
- [ ] Status page (free tier).
- [ ] `/v1/users/me/delete` schedules purge.

Exit: Sustained 100 concurrent investigations complete with p95 < 60s.

References: [17-TESTING.md](17-TESTING.md), [32-OBSERVABILITY.md](32-OBSERVABILITY.md).

## 10. Phase 8 — Intelligence Engine (Days 39–50)

**Goal:** Browser-based scraping, anti-bot, evidence scoring, full graph.

Tasks:

- [ ] **Scraping Engine (19)**: HTTPClient + BrowserClient + extraction.
- [ ] **Browser Manager (20)**: Chromium pool, context recycling.
- [ ] **Proxy Manager (21)**: rotation, scoring, geo, cooldowns.
- [ ] **Anti-Bot (22)**: fingerprinting, TLS profiles, risk scoring.
- [ ] **Investigation Graph (23)**: case table, timeline, graph queries.
- [ ] **Normalization (25)**: canonicalization, dedup.
- [ ] **Evidence Scoring (26)**: confidence, freshness, manual overrides.
- [ ] **Artifact Storage (27)**: object store abstraction, retention.
- [ ] **Scheduler (28)**: watchlists, delta detection.
- [ ] **Feature Flags (30)**: gradual rollout infrastructure.
- [ ] Wire metrics and dashboards.

Exit: Real-world target (e.g. a public company website) gets full investigation: WHOIS + DNS + CT + HTTP crawl + social, browser path, with confidence scoring.

References: [19-SCRAPING-ENGINE.md](19-SCRAPING-ENGINE.md), [20-BROWSER-MANAGER.md](20-BROWSER-MANAGER.md), [21-PROXY-MANAGER.md](21-PROXY-MANAGER.md), [22-ANTI-BOT.md](22-ANTI-BOT.md), [23-INVESTIGATION-GRAPH.md](23-INVESTIGATION-GRAPH.md), [25-NORMALIZATION.md](25-NORMALIZATION.md), [26-EVIDENCE-SCORING.md](26-EVIDENCE-SCORING.md), [27-ARTIFACT-STORAGE.md](27-ARTIFACT-STORAGE.md), [28-SCHEDULER.md](28-SCHEDULER.md), [30-FEATURE-FLAGS.md](30-FEATURE-FLAGS.md).

## 11. Phase 9 — Runtime Hardening (Days 51–55)

**Goal:** Plugin runtime isolation is robust; capability model enforced; secrets managed; upgrades atomic.

Tasks:

- [ ] Implement [33-PLUGIN-RUNTIME.md](33-PLUGIN-RUNTIME.md) capabilities:
  - Capability-based SDK facade.
  - nftables egress enforcement.
  - RestrictedPython wrapping.
  - Secrets manager integration.
  - Heartbeat protocol.
- [ ] Plugin upgrade/rollback flow (33 §13).
- [ ] Plugin signing key rotation (33 §12.4).
- [ ] Quarantine + restart cap (33 §11.4).
- [ ] Test: malicious plugin cannot exfiltrate, cannot OOM worker.

Exit: Third-party plugin runs with declared caps; quarantine works; secrets never logged.

References: [33-PLUGIN-RUNTIME.md](33-PLUGIN-RUNTIME.md).

## 12. Phase 10 — Source Registry & Workflow Engine (Days 56–60)

**Goal:** Central source metadata; DAG execution with resumption; strategies drive investigations.

Tasks:

- [ ] **Data Source Registry (34)**: `plugin.source_registry` table, capability taxonomy, reliability tracking.
- [ ] **Workflow Engine (35)**: DAG execution, checkpointing, resumption, cancellation.
- [ ] **Search Strategies (36)**: 18 built-in playbooks (email, username, domain, company, phone, ip, asn, crypto, image, social).
- [ ] Wire Planner (24) → Strategy (36) → Workflow (35) → Runtime (33) → Sources (34) pipeline.
- [ ] Test: pause investigation mid-flight, resume correctly.
- [ ] Test: cancel investigation cleans up subprocesses.

Exit: 5 strategies implemented; investigation pauses/resumes correctly; source registry auto-populates from plugin install.

References: [34-DATA-SOURCE-REGISTRY.md](34-DATA-SOURCE-REGISTRY.md), [35-WORKFLOW-ENGINE.md](35-WORKFLOW-ENGINE.md), [36-SEARCH-STRATEGIES.md](36-SEARCH-STRATEGIES.md).

## 13. Phase 11 — Scheduler & Cost Polish (Days 61–64)

Tasks:

- [ ] Watchlist UI in bot (FSM for create, list, alerts).
- [ ] Alert routing via Telegram / email / webhook.
- [ ] Free-tier cost cap enforcement (31 §13).
- [ ] Stripe webhook race fix (31 §12).
- [ ] Subscription gate middleware.

Exit: Free-tier tenant respects budget; watchlist fires alert; subscription downgrade cancels investigations.

References: [28-SCHEDULER.md](28-SCHEDULER.md), [31-COST-CONTROLLER.md](31-COST-CONTROLLER.md).

## 14. Phase 12 — GDPR, Audit, Onboarding (Days 65–68)

Tasks:

- [ ] Create `33-GDPR.md` content from REVIEW M1 spec.
- [ ] Implement audit chain verifier (37-AUDIT-INTEGRITY.md).
- [ ] Bot onboarding flow: tutorial, default watchlist offer.
- [ ] GDPR right-to-delete working.
- [ ] Audit chain break detection + recovery.

Exit: GDPR delete works end-to-end; audit chain verifiable; new user completes first investigation unaided.

References: [REVIEW.md](REVIEW.md) §11 corrections; docs/33-GDPR.md (TBD).

## 15. Anti-roadmap (things we will NOT do in V1)

- Custom plugin DSL (use plain Python).
- Real-time collaborative investigations.
- Mobile native apps.
- ML-based entity resolution.
- Voice / video evidence handling.
- Investigations targeting individuals under 18.
- Multi-region (V3).
- Web admin UI (V2).
- Plugin marketplace (V2).
- AI summarization (V2).

These are documented so future contributors know they were considered and rejected.

## 16. Daily cadence (suggested)

Solo dev on Termux + Android:

| Block | Time | Activity |
|-------|------|----------|
| Morning | 09:00–11:00 | Pick today's vertical slice, write failing test |
| Midday | 11:00–13:00 | Implement slice to green |
| Afternoon | 13:00–15:00 | Deploy preview, manual smoke test via Telegram |
| Late | 15:00–17:00 | Refactor, run lint, commit, push, deploy |
| Evening | — | (off) |

Avoid: 30-minute rabbit holes. Time-box. Commit small. Push daily.

## 17. Updated reading order

After all 36 specs are complete, the canonical reading order for
new engineers is:

1. README.md
2. 00-ARCHITECTURE.md
3. 01-PROJECT-STRUCTURE.md
4. 03-DATABASE-SCHEMA.md
5. 04-API-SPEC.md
6. 05-TELEGRAM-BOT.md
7. 06-WORKERS.md
8. 19-SCRAPING-ENGINE.md
9. 20-BROWSER-MANAGER.md
10. 21-PROXY-MANAGER.md
11. 22-ANTI-BOT.md
12. 23-INVESTIGATION-GRAPH.md
13. 24-PLANNER.md
14. 25-NORMALIZATION.md
15. 26-EVIDENCE-SCORING.md
16. 27-ARTIFACT-STORAGE.md
17. 28-SCHEDULER.md
18. 29-EXPORT-PIPELINE.md
19. 30-FEATURE-FLAGS.md
20. 31-COST-CONTROLLER.md
21. 32-OBSERVABILITY.md
22. 33-PLUGIN-RUNTIME.md
23. 34-DATA-SOURCE-REGISTRY.md
24. 35-WORKFLOW-ENGINE.md
25. 36-SEARCH-STRATEGIES.md
26. 13-DEPLOYMENT.md
27. 14-TERMUX-WORKFLOW.md
28. 18-CICD.md
29. 17-TESTING.md
30. ARCHITECTURE-AUDIT.md

This order respects dependency direction.
