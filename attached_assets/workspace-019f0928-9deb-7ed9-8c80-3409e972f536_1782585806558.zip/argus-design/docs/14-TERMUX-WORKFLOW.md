# 14 — Termux Development Workflow

## 0. Why Termux-first

The entire codebase, all scripts, all workflows must run on an
Android device with Termux. No assumption of Docker Desktop, VS Code,
WSL, or a desktop IDE. The reasoning:

- Single developer may not have a laptop at hand.
- Some markets are Android-first.
- Forces us to build lean, reproducible environments.
- The free PaaS targets are Linux; the only mismatch is local dev,
  which proot-distro solves.

## 1. Initial setup

### 1.1 Install Termux basics

```bash
# Update base
pkg update -y && pkg upgrade -y

# Core tools
pkg install -y python git tmux curl wget jq neovim graphviz \
                postgresql-client redis-tools ripgrep fd fzf \
                build-essential libffi libssl openssl

# Optional: proot-distro for full Debian userland
pkg install -y proot-distro
```

### 1.2 Install proot-distro Debian

```bash
proot-distro install debian
proot-distro login debian -- bash -c "echo 'ok'"
```

We use Debian inside proot for development because:

- Full Python ecosystem.
- `apt install` works.
- Postgres server can run locally (for tests).
- No `termux-chroot` limitations.

### 1.3 Bootstrap Argus in proot

```bash
# scripts/termux-bootstrap.sh
#!/usr/bin/env bash
set -euo pipefail

REPO="${1:-$HOME/argus}"

echo "==> Updating apt"
apt-get update -y
apt-get install -y --no-install-recommends \
    python3.12 python3.12-venv python3-pip \
    git tmux curl wget jq graphviz \
    postgresql-15 redis-server \
    build-essential libffi-dev libssl-dev pkg-config

echo "==> Installing uv"
pip install --break-system-packages uv==0.5.0 || pip install uv==0.5.0

echo "==> Cloning Argus"
if [ ! -d "$REPO" ]; then
    git clone https://github.com/argus-saas/argus.git "$REPO"
fi
cd "$REPO"

echo "==> Creating venv"
uv venv --python 3.12 .venv
source .venv/bin/activate
uv sync --all-extras

echo "==> Pre-commit"
uv run pre-commit install || true

echo "==> Copying .env.example"
[ -f .env ] || cp .env.example .env

echo "==> Done"
echo "Run: source .venv/bin/activate && ./scripts/dev.sh bootstrap"
```

Run once:

```bash
bash scripts/termux-bootstrap.sh
```

## 2. Directory convention

| Path | Purpose |
|------|---------|
| `~/argus` | Repo |
| `~/.config/argus/` | Secrets (chmod 600) |
| `~/argus/.venv` | Python venv |
| `~/argus/logs/` | Dev log files |
| `~/argus/run/` | PID files, sockets |

## 3. The daily flow

```bash
# 1. Enter proot (optional, mostly for Postgres/Redis locally)
proot-distro login debian

# 2. Activate venv
cd ~/argus && source .venv/bin/activate

# 3. Start dev stack in tmux
./scripts/tmux-dev.sh start

# 4. In tmux: switch windows to API logs, bot logs, worker logs.
# 5. Edit code in neovim (in another tmux pane).
# 6. Tests in another pane.
```

## 4. Running services locally

We run **API, Bot, Worker, Beat** as four processes. Postgres and
Redis can run locally inside proot, or be remote (recommended).

### 4.1 Local Postgres + Redis (inside proot)

```bash
# Inside proot Debian
service postgresql start
sudo -u postgres psql -c "CREATE DATABASE argus;"
sudo -u postgres psql -c "CREATE USER argus WITH PASSWORD 'argus';"
sudo -u postgres psql -c "GRANT ALL ON DATABASE argus TO argus;"

service redis-server start
redis-cli ping  # PONG
```

`~/.config/argus/secrets.env`:

```bash
DATABASE_URL=postgresql+asyncpg://argus:argus@localhost:5432/argus
ARGUS_REDIS_URL=redis://localhost:6379/0
```

### 4.2 Remote Postgres + Redis (recommended for testing prod)

- Provision free Postgres on Neon / Supabase.
- Provision free Redis on Upstash.
- Set the URLs in `secrets.env`.

This matches the prod environment and avoids "works on my machine"
issues.

### 4.3 Start everything

```bash
# Single tmux session with 4 panes per service
./scripts/tmux-dev.sh start
```

`tmux-dev.sh` runs:

- API: `uv run uvicorn argus_api.main:app --reload --port 8080`
- Bot: `uv run python -m argus_bot`
- Worker: `uv run celery -A argus_worker.celery_app worker -l INFO -c 4`
- Beat: `uv run celery -A argus_worker.celery_app beat -l INFO`

See [15-TMUX-LAYOUT.md](15-TMUX-LAYOUT.md) for the exact layout.

## 5. Iterating on code

Termux + neovim is the editing experience. Optional: Termux:API for
notifications, Termux:Widget for quick commands.

```bash
# In one tmux pane: edit code
nvim services/api/src/argus_api/routers/investigations.py

# In another: API auto-reloads (uvicorn --reload)
# In another: tail logs
tail -f logs/api.log | jq -C

# In another: tests
./scripts/test.sh tests/test_investigations.py
```

## 6. Testing from Telegram

Without leaving Termux:

```bash
# Open Telegram, send /start to bot, observe bot pane
# Or use a second Telegram account on a separate phone
# Or use the Telegram test API with a fake token
```

`scripts/dev-bot.sh` runs the bot pointed at the local API.

## 7. Network considerations

### 7.1 Android → Telegram

Telegram works on Android. The bot polls Telegram fine.

### 7.2 Android → local Postgres

If running Postgres inside proot, it's at `localhost:5432` inside
proot. Outside proot, Postgres is not reachable unless you use
Termux networking tricks. Workaround: run Postgres on a free hosted
service instead.

### 7.3 Android → local Redis

Same as Postgres. Either run inside proot (only reachable there) or
use Upstash.

### 7.4 Android → production deploy

Use SSH to a free VPS, or push via `git push railway main` over
mobile data. Works fine on Termux with `git` over HTTPS.

### 7.5 Telegram WebApp from Termux

Limited but possible. Most dev uses the polling path.

## 8. Termux-specific gotchas

- **PATH differences**: `~/.local/bin` is in PATH inside proot;
  outside, use `python3 -m pip install --user`.
- **No systemd**: use `tmux`, `nohup`, or `proot` to keep
  processes alive.
- **Battery**: tmux is light, but Postgres + Redis drain battery.
  Use hosted services for long sessions.
- **File watching**: `uvicorn --reload` uses inotify on Linux; on
  Termux/proot it works via polling fallback. Slow but works.
- **Graphviz binary**: `apt install graphviz` inside proot. Outside,
  no native build; use Python's `graphviz` package which expects
  the binary.

## 9. Scripts inventory

| Script | Purpose |
|--------|---------|
| `scripts/termux-bootstrap.sh` | One-time Termux + proot setup |
| `scripts/dev.sh` | Activate venv, install deps, generate .env |
| `scripts/serve.sh` | Run API locally |
| `scripts/bot.sh` | Run bot locally |
| `scripts/worker.sh` | Run Celery worker locally |
| `scripts/beat.sh` | Run Celery beat locally |
| `scripts/migrate.sh` | Run Alembic |
| `scripts/test.sh` | pytest |
| `scripts/lint.sh` | ruff + mypy |
| `scripts/format.sh` | ruff format |
| `scripts/tmux-dev.sh` | Start all four services in tmux |
| `scripts/check-bot-boundaries.sh` | CI guard |
| `scripts/seed.sh` | Insert plan + plugin catalog |
| `scripts/tail-logs.sh` | Tail a service log |
| `scripts/drain-dlq.sh` | Manual DLQ drain |

## 10. Make-equivalents

We don't use Make. Instead, each script wraps the underlying tool:

```bash
# scripts/dev.sh
#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."

case "${1:-help}" in
  bootstrap)
    uv sync --all-extras
    uv run pre-commit install
    [ -f .env ] || cp .env.example .env
    ;;
  api)    shift; uv run uvicorn argus_api.main:app --reload "$@" ;;
  bot)    shift; uv run python -m argus_bot "$@" ;;
  worker) shift; uv run celery -A argus_worker.celery_app worker -l INFO "$@" ;;
  beat)   shift; uv run celery -A argus_worker.celery_app beat -l INFO "$@" ;;
  shell)  uv run python ;;
  ipython) uv run ipython ;;
  help|--help|-h)
    cat <<EOF
Usage: dev.sh <command>

Commands:
  bootstrap   install deps, generate .env
  api         run API server (uvicorn --reload)
  bot         run bot
  worker      run celery worker
  beat        run celery beat
  shell       open python repl
EOF
    ;;
  *) echo "Unknown: $1"; exit 1 ;;
esac
```

Usage:

```bash
./scripts/dev.sh bootstrap
./scripts/dev.sh api --port 8080
./scripts/dev.sh worker -c 4
```

## 11. Termux notifications

`scripts/notify.sh` sends a Termux:API notification (e.g. on test
failure):

```bash
#!/usr/bin/env bash
# Requires Termux:API app
termux-notification \
    --title "Argus tests" \
    --content "$*" \
    --id "argus-tests"
```

Used in CI hooks:

```bash
./scripts/test.sh || ./scripts/notify.sh "Tests failed"
```

## 12. CI from Termux

GitHub Actions are the canonical CI, but you can also run them
locally with [`act`](https://github.com/nektos/act):

```bash
# Inside proot Debian
curl -s https://raw.githubusercontent.com/nektos/act/master/install.sh | sudo bash
act -j lint
act -j test
```

## 13. SSH and remote work

```bash
# Generate key
ssh-keygen -t ed25519 -f ~/.ssh/argus_deploy

# Add to GitHub
gh ssh-key add ~/.ssh/argus_deploy.pub --title "termux"

# SSH to free VPS for prod-like testing
ssh -i ~/.ssh/argus_deploy ubuntu@<vps-ip>
```

Termux has `ssh` and `mosh`. Both work fine over mobile data.

## 14. Battery / data tips

- Use `--loglevel=WARNING` to halve log volume.
- Use `tail -f` not `less +F` to avoid keeping the file open.
- Sleep tmux between edits: `Ctrl-b s` then resume with `Ctrl-b r`.
- When idle for hours, kill tmux and only restart when needed.

## 15. Why proot-distro over Termux-native

| Concern | Termux-native | proot Debian |
|---------|---------------|---------------|
| Postgres | works | works |
| Redis | works | works |
| Python 3.12 | `python` package | `apt install python3.12` |
| uvicorn reload | slow polling | normal |
| systemd | no | no (still no init) |
| Resource overhead | minimal | ~50 MB |
| Developer ergonomics | OK | Better (apt + familiar paths) |

We use **proot for active dev**, **Termux-native for quick edits and
tmux control**. The repo lives at `~/argus` so both see the same
files.

## 16. Quick reference card

```bash
# ── first time ───────────────────────────────────────────────
bash scripts/termux-bootstrap.sh

# ── every day ────────────────────────────────────────────────
proot-distro login debian         # if you want apt
cd ~/argus && source .venv/bin/activate
./scripts/tmux-dev.sh start       # API + Bot + Worker + Beat

# attach: tmux attach -t argus
# detach: Ctrl-b d

# ── testing ──────────────────────────────────────────────────
./scripts/test.sh                 # full suite
./scripts/test.sh tests/test_investigations.py::test_create  # one
./scripts/lint.sh                 # ruff + mypy
./scripts/format.sh               # auto-fix

# ── migrations ───────────────────────────────────────────────
./scripts/migrate.sh upgrade
./scripts/migrate.sh downgrade -1
./scripts/migrate.sh current

# ── deployment ───────────────────────────────────────────────
./scripts/deploy.sh staging
./scripts/deploy.sh production
```

## 17. When Termux is not enough

If you outgrow Termux (rare), the same scripts run unchanged on:

- Linux laptop.
- Free Oracle Cloud VM (4 ARM cores, 24 GB RAM, always free).
- Free Google Cloud shell.

We do not lock-in to Termux.
