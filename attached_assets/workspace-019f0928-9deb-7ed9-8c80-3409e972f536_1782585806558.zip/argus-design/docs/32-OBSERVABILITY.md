# 32 — Observability

> Metrics, tracing, distributed correlation IDs, performance
> dashboards, worker / queue / browser / plugin monitoring, alerting,
> and capacity planning. Extends the logging strategy in
> 12-LOGGING.

---

## 0. Goals

1. Every component exports Prometheus metrics.
2. Every request / task / scrape has a correlation ID that flows
   through logs, metrics, and traces.
3. Dashboards for ops, engineering, and finance (cost).
4. Alerting with sensible defaults; routes to Telegram ops chat
   and PagerDuty (V2).
5. Capacity planning based on real numbers.

## 1. Layer position

```
   App code (api / bot / worker / domain)
       │
       ▼
   OpenTelemetry SDK
       │
       ├──► Prometheus /metrics (every 15s scrape)
       ├──► OTLP HTTP → collector → Tempo (traces)
       └──► structlog → stdout → Loki (logs)

   Grafana unifies all three.
```

## 2. Correlation IDs

Already designed in [12-LOGGING.md](12-LOGGING.md). We add
**cross-process correlation**:

- `request_id` (UUID): one per HTTP request or Celery task.
- `trace_id` (W3C): OTel trace, propagated via headers.
- `span_id` (W3C): per-operation.
- `tenant_id`, `user_id`, `investigation_id`, `plugin_run_id`,
  `evidence_id` — business correlation, attached to every span.

Propagation:

```python
# Outgoing HTTPX request
async with trace.start_as_current_span("http.fetch") as span:
    span.set_attribute("argus.tenant_id", str(tenant_id))
    span.set_attribute("argus.investigation_id", str(inv_id))
    response = await client.get(url, headers={
        "traceparent": f"00-{trace_id}-{span_id}-01",
    })

# Incoming HTTPX response (server side)
@app.middleware("http")
async def extract_trace(request, call_next):
    ctx = extract_context_from_headers(request.headers)
    token = context.attach(ctx)
    try:
        return await call_next(request)
    finally:
        context.detach(token)
```

Worker tasks:

```python
@shared_task(bind=True)
def my_task(self):
    from opentelemetry import trace
    tracer = trace.get_tracer("argus.worker")
    with tracer.start_as_current_span("task.argus.investigation.plan",
                                       attributes={
                                           "argus.task_id": self.request.id,
                                           "argus.investigation_id": self.kwargs["id"],
                                       }):
        ...
```

## 3. Metrics catalog

### 3.1 API metrics

```
# request
argus_api_requests_total{method,path,status}            counter
argus_api_request_duration_seconds{method,path}        histogram
argus_api_request_in_flight                              gauge

# business
argus_investigations_created_total{plan}                counter
argus_investigations_completed_total{plan}              counter
argus_investigations_failed_total{reason}               counter
argus_investigations_cancelled_total{reason}            counter
argus_evidence_collected_total{plugin}                  counter
argus_entities_discovered_total{type}                   counter
argus_relationships_discovered_total{kind}              counter
argus_exports_rendered_total{format,result}             counter

# auth
argus_auth_logins_total{method}                         counter
argus_auth_failures_total{reason}                       counter
argus_auth_refresh_total{result}                        counter
```

### 3.2 Bot metrics

```
argus_bot_updates_total{handler,result}                 counter
argus_bot_handler_duration_seconds{handler}             histogram
argus_bot_updates_in_flight                              gauge
argus_bot_api_errors_total{code}                        counter
argus_bot_throttled_total{reason}                       counter
argus_bot_messages_edited_total{type}                   counter
argus_bot_export_uploads_total{format,result}           counter
```

### 3.3 Worker metrics

```
argus_tasks_total{name,status}                          counter
argus_task_duration_seconds{name}                       histogram
argus_tasks_in_flight{name}                             gauge
argus_task_retries_total{name,reason}                   counter
argus_task_dlq_total{name,reason}                       counter
argus_worker_up                                         gauge
```

### 3.4 Scraping engine (19)

```
argus_scrape_requests_total{mode,result}                counter
argus_scrape_request_duration_seconds{mode}             histogram
argus_scrape_bytes_total{mode,direction}                counter
argus_scrape_failures_total{class,mode}                 counter
argus_scrape_cache_hits_total                           counter
argus_scrape_risk_score{tenant,domain}                  gauge
```

### 3.5 Browser manager (20)

```
argus_browser_pool_size                                 gauge
argus_browser_pool_active                               gauge
argus_browser_pool_idle                                 gauge
argus_browser_pool_unhealthy                            gauge
argus_browser_pool_crashes_total                        counter
argus_browser_context_active                            gauge
argus_browser_context_lifetime_seconds                  histogram
argus_browser_memory_rss_bytes                          gauge
argus_browser_pulse_failures_total                      counter
```

### 3.6 Proxy manager (21)

```
argus_proxy_pool_size{type,geo}                         gauge
argus_proxy_active{type,geo}                            gauge
argus_proxy_score{proxy_id}                             gauge
argus_proxy_outcomes_total{result,type}                 counter
argus_proxy_cooldowns_total{type}                       counter
argus_proxy_bytes_total{direction,type}                 counter
```

### 3.7 Anti-bot (22)

```
argus_antibot_risk_score{tenant,domain}                 gauge
argus_antibot_profile_uses_total{profile_id,mode}       counter
argus_antibot_policy_changes_total{from,to}             counter
argus_antibot_backoffs_total{tenant}                    counter
```

### 3.8 Cost controller (31)

```
argus_cost_charged_total{op,plan}                       counter
argus_cost_refunded_total{op,reason}                    counter
argus_cost_credits_remaining{tenant}                    gauge
argus_cost_provider_spend_cents{provider,month}         gauge
argus_cost_quota_exceeded_total{type,plan}              counter
```

### 3.9 Scheduler (28)

```
argus_watchlist_runs_total{result}                      counter
argus_watchlist_run_duration_seconds                    histogram
argus_watchlist_consecutive_failures                    gauge
argus_watchlist_deltas_total{kind}                      counter
argus_watchlist_alerts_sent_total{channel,result}       counter
```

### 3.10 Feature flags (30)

```
argus_flag_evaluations_total{key,result}                counter
argus_flag_cache_refresh_total{result}                  counter
argus_flag_value{key}                                   gauge (text-encoded)
```

### 3.11 Queue depth

Already in 10-QUEUE-DESIGN §6.

### 3.12 Database

```
sqlalchemy_pool_size                                    gauge
sqlalchemy_pool_checked_out                             gauge
sqlalchemy_query_duration_seconds{op}                   histogram
```

## 4. Distributed tracing

OpenTelemetry SDK with:

- `OTLPSpanExporter` (HTTP) → Tempo.
- `BatchSpanProcessor`.
- Sampling: 1 in 10 by default (`OTEL_SAMPLING_RATIO=0.1`).
  Errors are always sampled (`AlwaysOnSampler` for spans with
  `status=ERROR`).

Span hierarchy (typical investigation):

```
HTTP POST /v1/investigations
└── argus.api.start_investigation
    ├── argus.planner.plan
    │   └── argus.domain.plan_investigation
    ├── argus.cost.pre_check
    └── argus.celery.enqueue
        └── argus.celery.task: argus.investigation.plan
            ├── argus.db.read
            ├── argus.domain.plan
            └── argus.celery.enqueue
                └── argus.celery.task: argus.plugin.run (×N)
                    ├── argus.worker.plugin_subprocess
                    ├── argus.antibot.preflight
                    ├── argus.proxy.acquire
                    ├── argus.scrape.http_or_browser
                    │   └── argus.browser.navigate (if browser)
                    ├── argus.evidence.persist
                    └── argus.artifact.upload
                        └── argus.r2.put
```

Every span has attributes: `argus.tenant_id`,
`argus.investigation_id`, `argus.plugin_name`,
`argus.plugin_run_id`.

## 5. Dashboards

### 5.1 Operator dashboard

- API request rate by status (timeseries).
- p50 / p95 / p99 latency.
- Worker queue depth per queue.
- Browser pool state.
- Recent errors (top 20).
- Active investigations (count + list).

### 5.2 Engineering dashboard

- Per-route latency heatmap.
- Plugin success rate (top 10, bottom 10).
- Browser crash rate.
- Proxy score distribution.
- Cost burn rate per provider.
- Database slow query log.

### 5.3 Finance dashboard

- Monthly provider spend by provider.
- Cost per investigation by plan.
- Refund rate.
- Most expensive plugins.
- Free-tier cohort cost.

### 5.4 Bot UX dashboard

- Update handler latency.
- API error rate by code.
- Telegram 429 rate.
- Message edit success rate.

All dashboards are JSON for Grafana, stored in
`ops/grafana/dashboards/`.

## 6. Alerting

### 6.1 Alert rules (Prometheus-format)

```yaml
groups:
  - name: argus.api
    rules:
      - alert: ArgusAPI5xxHigh
        expr: sum(rate(argus_api_requests_total{status=~"5.."}[5m])) /
              sum(rate(argus_api_requests_total[5m])) > 0.01
        for: 10m
        labels:
          severity: critical
          team: backend
        annotations:
          summary: "API 5xx rate above 1% for 10 minutes"

      - alert: ArgusAPIHighLatency
        expr: histogram_quantile(0.99,
          sum by (le,path)(rate(argus_api_request_duration_seconds_bucket[5m]))) > 1.0
        for: 5m
        labels:
          severity: warning

  - name: argus.worker
    rules:
      - alert: ArgusDLQGrowing
        expr: argus_task_dlq_total > 50
        for: 5m
        labels:
          severity: critical

      - alert: ArgusBrowserPoolEmpty
        expr: argus_browser_pool_idle == 0 AND
              argus_browser_pool_active > 0
        for: 2m
        labels:
          severity: warning

  - name: argus.cost
    rules:
      - alert: ArgusCostProviderOverrun
        expr: argus_cost_provider_spend_cents{provider="brightdata"} > 50000
        for: 1m
        labels:
          severity: critical
          team: finance

  - name: argus.antibot
    rules:
      - alert: ArgusAntiBotBackoffs
        expr: increase(argus_antibot_backoffs_total[1h]) > 100
        for: 5m
        labels:
          severity: warning
```

### 6.2 Alert routing

- `severity=critical` → Telegram ops chat + on-call (PagerDuty V2).
- `severity=warning` → Telegram dev chat.
- `severity=info` → Slack #ops-info.

Routing implemented by `argus-common/observability/alerts.py`.

## 7. Component monitoring recipes

### 7.1 Worker monitoring

```python
# Always export: worker count, queue depth, last heartbeat
from celery.signals import heartbeat_sent
@heartbeat_sent.connect
def on_heartbeat(**_):
    WORKER_UP.set(1)
    for q in QUEUES:
        QUEUE_DEPTH.labels(queue=q).set(redis.llen(f"celery:{q}"))
```

### 7.2 Queue monitoring

Already covered.

### 7.3 Browser monitoring

```python
async def browser_pool_monitor():
    while True:
        status = browser_manager.status()
        BROWSER_POOL_SIZE.set(status.total_browsers)
        BROWSER_POOL_ACTIVE.set(status.active_contexts)
        BROWSER_POOL_IDLE.set(status.idle_contexts)
        BROWSER_POOL_UNHEALTHY.set(status.unhealthy_contexts)
        await asyncio.sleep(10)
```

### 7.4 Plugin monitoring

Each plugin has a wrapper that emits metrics:

```python
@with_plugin_metrics("whois")
def run_whois(ctx, input):
    ...
```

## 8. Capacity planning

Inputs:

- Investigation rate (per hour).
- Average scrapes per investigation.
- Average duration per scrape.
- Tenant count.

Outputs:

- Required API replicas.
- Required worker concurrency.
- Required browser pool size.
- Required Redis ops/sec.
- Required Postgres IOPS.

### 8.1 Capacity calculator

```python
def capacity_for(target_investigations_per_day: int) -> Capacity:
    scrapes_per_day = target_investigations_per_day * 20  # avg
    scrapes_per_sec_peak = scrapes_per_day / 86400 * 3    # 3x peak
    http_scrapes = scrapes_per_sec_peak * 0.85
    browser_scrapes = scrapes_per_sec_peak * 0.15
    api_capacity_per_replica = 100   # req/sec
    worker_concurrency_total = max(
        http_scrapes / 30,            # 30 http/sec per worker slot
        browser_scrapes / 2,          # 2 browser/sec per worker slot
    )
    worker_replicas = ceil(worker_concurrency_total / 4)  # 4 slots/replica
    return Capacity(
        api_replicas=ceil(scrapes_per_sec_peak / api_capacity_per_replica),
        worker_replicas=worker_replicas,
        browser_pool_size=ceil(browser_scrapes * 4),
        redis_ops_per_sec=scrapes_per_sec_peak * 8,
        postgres_iops=scrapes_per_sec_peak * 3,
    )
```

### 8.2 Headroom rules

- API: provision 2x peak.
- Worker: provision 1.5x peak.
- Browser pool: provision 2x peak.
- DB: provision 3x peak IOPS.

We re-run the calculator monthly with rolling 30-day numbers.

### 8.3 Capacity report

Generated monthly:

```python
@shared_task(name="argus.observability.capacity_report")
def capacity_report():
    actual = scrape_30d_actual()
    projected = capacity_for(target=actual * 1.5)
    if projected.worker_replicas > settings.worker_replicas:
        alert_ops("scale_up_needed", actual=actual, projected=projected)
```

## 9. Failure modes

| Failure | Detection | Recovery |
|---------|-----------|----------|
| Metrics endpoint down | Prometheus scrape fails | alert |
| Trace exporter fails | OTLP 5xx | switch to stdout exporter |
| Loki down | log push fails | spool to disk; retry |
| Dashboard fails to load | Grafana 500 | fall back to plain metrics endpoint |
| Alert rule false positive | complaint | tune threshold |

## 10. Security

- `/metrics` is unauthenticated but limited to internal network
  (Cloudflare Access on PaaS).
- Trace exports redact `Authorization`, `Cookie`, `initData`.
- Cost metrics do not expose per-tenant data to non-admin viewers.
- Alert routing uses HMAC-signed webhooks.

## 11. Scalability

- Metric cardinality: 50k unique series worst-case. Prometheus
  handles this comfortably.
- Trace volume: ~100k spans/sec at peak; sampled at 10% = 10k/sec.
- Loki: 50 GB/mo free tier. Volume metered per `argus_log_bytes_total`.

## 12. Configuration

```bash
ARGUS_OTEL_EXPORTER_OTLP_ENDPOINT=https://tempo.example.com
ARGUS_OTEL_SAMPLING_RATIO=0.1
ARGUS_PROMETHEUS_PORT=9090
ARGUS_ALERT_WEBHOOK_TELEGRAM=https://api.telegram.org/bot.../sendMessage
ARGUS_ALERT_WEBHOOK_PAGERDUTY=
```

## 13. Trade-offs and rationale

| Decision | Rationale | Trade-off |
|----------|-----------|-----------|
| 1-in-10 sampling by default | Cost control | Less detail on rare errors |
| Always-sample errors | Visibility when things break | Higher cardinality |
| Metrics in Prometheus | Standard, free tooling | One more service |
| Traces to Tempo | Open source | Storage cost |
| Cost dashboard separate | Different audience | More dashboards |

## 14. References

- [12-LOGGING.md](12-LOGGING.md) — Logging baseline
- [10-QUEUE-DESIGN.md](10-QUEUE-DESIGN.md) — Queue metrics
- [06-WORKERS.md](06-WORKERS.md) — Worker metrics
- [13-DEPLOYMENT.md](13-DEPLOYMENT.md) — Where metrics live
- [31-COST-CONTROLLER.md](31-COST-CONTROLLER.md) — Cost dashboard
