# 18 — CI/CD Pipeline (GitHub Actions)

## 0. Goals

- Lint, type-check, test on every PR.
- Build Docker images on every push to `main`.
- Auto-deploy to **staging** on push to `main`.
- Manual deploy to **production** via workflow_dispatch.
- Slack / Telegram notifications on failure.

## 1. Secrets

Set in repo settings → Secrets and variables → Actions:

| Secret | Purpose |
|--------|---------|
| `DATABASE_URL_STAGING` | Neon branch DB |
| `REDIS_URL_STAGING` | Upstash staging |
| `R2_ACCESS_KEY` / `R2_SECRET_KEY` | Object store |
| `JWT_PRIVATE_KEY_STAGING` | RS256 signing |
| `STRIPE_SECRET_KEY` | Billing |
| `STRIPE_WEBHOOK_SECRET` | Webhook verify |
| `SENTRY_DSN` | Error reporting |
| `ARGUS_BOT_TOKEN` | Telegram bot |
| `ARGUS_BOT_TOKEN_ENCRYPTION_KEY` | Fernet for FSM |
| `RAILWAY_TOKEN` | Railway deploy |
| `KOYEB_TOKEN` | Koyeb deploy (alternative) |
| `NORTHFLANK_TOKEN` | Northflank deploy |
| `SLACK_WEBHOOK` | Notifications |

We use **GitHub OIDC** for Railway / Koyeb / Northflank so we don't
ship long-lived deploy tokens.

## 2. Workflows

```
.github/workflows/
├── lint.yml
├── test.yml
├── build.yml
├── deploy-staging.yml
├── deploy-production.yml
├── release.yml
└── scorecard.yml
```

## 3. `lint.yml`

```yaml
name: Lint
on:
  push:
    branches: [main, develop]
  pull_request:
    branches: [main]

jobs:
  ruff:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with: { python-version: "3.12" }
      - run: pip install uv==0.5.0
      - run: uv sync --all-extras
      - run: uv run ruff check .
      - run: uv run ruff format --check .

  mypy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with: { python-version: "3.12" }
      - run: pip install uv==0.5.0
      - run: uv sync --all-extras
      - run: uv run mypy --strict libs/argus_common libs/argus_db domain
      - run: uv run mypy services/api/src services/bot/src services/worker/src

  bot-boundary:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - run: chmod +x scripts/*.sh
      - run: ./scripts/check-bot-boundaries.sh
```

## 4. `test.yml`

```yaml
name: Test
on:
  push:
    branches: [main, develop]
  pull_request:
    branches: [main]

jobs:
  unit:
    runs-on: ubuntu-latest
    services:
      postgres:
        image: postgres:16
        env:
          POSTGRES_DB: argus_test
          POSTGRES_USER: argus
          POSTGRES_PASSWORD: argus
        ports: ["5432:5432"]
        options: >-
          --health-cmd="pg_isready -U argus"
          --health-interval=10s --health-timeout=5s --health-retries=5
      redis:
        image: redis:7
        ports: ["6379:6379"]
        options: --health-cmd="redis-cli ping" --health-interval=10s
    env:
      TEST_DATABASE_URL: postgresql+asyncpg://argus:argus@localhost:5432/argus_test
      TEST_REDIS_URL: redis://localhost:6379/0
      JWT_PRIVATE_KEY: ${{ secrets.JWT_PRIVATE_KEY_TEST }}
      JWT_PUBLIC_KEY: ${{ secrets.JWT_PUBLIC_KEY_TEST }}
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with: { python-version: "3.12" }
      - run: pip install uv==0.5.0
      - run: uv sync --all-extras
      - run: ./scripts/migrate.sh upgrade
      - run: pytest -m "unit or integration or contract" -q
      - run: pytest --cov --cov-report=xml --cov-fail-under=70
      - uses: actions/upload-artifact@v4
        with:
          name: coverage
          path: coverage.xml

  contract:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with: { python-version: "3.12" }
      - run: pip install uv==0.5.0
      - run: uv sync --all-extras
      - run: pytest -m "contract" -q
```

## 5. `build.yml`

```yaml
name: Build
on:
  push:
    branches: [main]
    tags: ["v*"]

jobs:
  docker:
    runs-on: ubuntu-latest
    permissions:
      contents: read
      packages: write
      id-token: write       # OIDC for signing
    steps:
      - uses: actions/checkout@v4
      - uses: docker/setup-buildx-action@v3
      - uses: docker/login-action@v3
        with:
          registry: ghcr.io
          username: ${{ github.actor }}
          password: ${{ secrets.GITHUB_TOKEN }}

      - name: Build & push api
        uses: docker/build-push-action@v6
        with:
          context: .
          file: ops/docker/Dockerfile
          build-args: SERVICE=api
          push: true
          tags: |
            ghcr.io/${{ github.repository_owner }}/argus:api-${{ github.sha }}
            ghcr.io/${{ github.repository_owner }}/argus:api-latest
          provenance: true
          sbom: true

      - name: Build & push bot
        uses: docker/build-push-action@v6
        with:
          context: .
          file: ops/docker/Dockerfile
          build-args: SERVICE=bot
          push: true
          tags: |
            ghcr.io/${{ github.repository_owner }}/argus:bot-${{ github.sha }}
            ghcr.io/${{ github.repository_owner }}/argus:bot-latest

      - name: Build & push worker
        uses: docker/build-push-action@v6
        with:
          context: .
          file: ops/docker/Dockerfile
          build-args: SERVICE=worker
          push: true
          tags: |
            ghcr.io/${{ github.repository_owner }}/argus:worker-${{ github.sha }}
            ghcr.io/${{ github.repository_owner }}/argus:worker-latest
```

## 6. `deploy-staging.yml`

```yaml
name: Deploy staging
on:
  push:
    branches: [main]
  workflow_dispatch:

concurrency:
  group: deploy-staging
  cancel-in-progress: false

jobs:
  test:
    uses: ./.github/workflows/test.yml

  migrate:
    runs-on: ubuntu-latest
    needs: test
    environment: staging
    steps:
      - uses: actions/checkout@v4
      - uses: aws-actions/configure-aws-credentials@v4
        with:
          role-to-assume: ${{ secrets.AWS_ROLE_ARN }}
          aws-region: us-east-1
      - run: ./scripts/migrate.sh upgrade
        env:
          DATABASE_URL: ${{ secrets.DATABASE_URL_STAGING }}

  deploy-api:
    runs-on: ubuntu-latest
    needs: migrate
    environment: staging
    permissions:
      id-token: write
    steps:
      - uses: actions/checkout@v4
      - name: Deploy to Railway (api)
        uses: bervProject/railway-deploy@v3
        with:
          railway_token: ${{ secrets.RAILWAY_TOKEN }}
          service: argus-api-staging
          environment: staging
          healthcheck_path: /health

  deploy-bot:
    runs-on: ubuntu-latest
    needs: deploy-api
    environment: staging
    steps:
      - uses: actions/checkout@v4
      - name: Deploy bot
        uses: bervProject/railway-deploy@v3
        with:
          railway_token: ${{ secrets.RAILWAY_TOKEN }}
          service: argus-bot-staging
          environment: staging

  deploy-worker:
    runs-on: ubuntu-latest
    needs: deploy-api
    environment: staging
    steps:
      - uses: actions/checkout@v4
      - name: Deploy worker
        uses: bervProject/railway-deploy@v3
        with:
          railway_token: ${{ secrets.RAILWAY_TOKEN }}
          service: argus-worker-staging
          environment: staging

  smoke:
    runs-on: ubuntu-latest
    needs: [deploy-api, deploy-bot, deploy-worker]
    steps:
      - uses: actions/checkout@v4
      - run: ./scripts/wait-for.sh https://api-staging.argus.saas/health 60
      - run: ./scripts/smoke.sh staging
        env:
          API_URL: https://api-staging.argus.saas
          BOT_TOKEN: ${{ secrets.ARGUS_BOT_TOKEN_STAGING }}
```

## 7. `deploy-production.yml`

Manual approval gated by GitHub Environment "production" with
required reviewers.

```yaml
name: Deploy production
on:
  workflow_dispatch:
    inputs:
      ref:
        description: "git ref to deploy (tag, sha, or branch)"
        required: true
        default: main
  release:
    types: [published]

jobs:
  build:
    if: github.event_name == 'workflow_dispatch'
    uses: ./.github/workflows/build.yml

  deploy:
    runs-on: ubuntu-latest
    environment:
      name: production
      url: https://api.argus.saas
    steps:
      - uses: actions/checkout@v4
        with:
          ref: ${{ inputs.ref || github.ref }}

      - name: Migrate database
        run: ./scripts/migrate.sh upgrade
        env:
          DATABASE_URL: ${{ secrets.DATABASE_URL_PROD }}

      - name: Deploy API (canary 10%)
        uses: bervProject/railway-deploy@v3
        with:
          railway_token: ${{ secrets.RAILWAY_TOKEN }}
          service: argus-api-prod-canary

      - name: Wait & verify
        run: ./scripts/smoke.sh production-canary

      - name: Promote to 100%
        uses: bervProject/railway-deploy@v3
        with:
          railway_token: ${{ secrets.RAILWAY_TOKEN }}
          service: argus-api-prod

      - name: Deploy bot
        uses: bervProject/railway-deploy@v3
        with:
          railway_token: ${{ secrets.RAILWAY_TOKEN }}
          service: argus-bot-prod

      - name: Deploy worker
        uses: bervProject/railway-deploy@v3
        with:
          railway_token: ${{ secrets.RAILWAY_TOKEN }}
          service: argus-worker-prod

      - name: Notify Telegram
        if: always()
        uses: actyx/marketplace-actions-telegram@v1
        with:
          telegram_bot_token: ${{ secrets.NOTIFY_BOT_TOKEN }}
          telegram_chat_id: ${{ secrets.OPS_CHAT_ID }}
          message: |
            ${{ job.status == 'success' && '✅' || '❌' }} Production deploy ${{ github.ref }}
            commit: ${{ github.sha }}
            actor: ${{ github.actor }}
```

## 8. `release.yml`

```yaml
name: Release
on:
  push:
    tags: ["v*.*.*"]

permissions:
  contents: write

jobs:
  release:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
        with: { fetch-depth: 0 }

      - name: Generate changelog
        run: |
          uv run python scripts/changelog.py \
              --from-ref v${{ github.event.inputs.prev }} \
              --to-ref ${{ github.ref_name }} \
              > CHANGELOG.md

      - name: Create GitHub release
        uses: softprops/action-gh-release@v2
        with:
          body_path: CHANGELOG.md
          files: |
            coverage.xml
          generate_release_notes: true
```

## 9. Branch protection

`main` branch requires:

- 1 approving review.
- All checks green.
- Up-to-date with `main`.
- Linear history.

`develop` is integration; `main` is release. Tags `v*.*.*` are
immutable.

## 10. Environments

GitHub Environments configured:

- `staging` — auto-deploy on `main`, no approval.
- `production` — manual approval, requires 2 reviewers from
  `CODEOWNERS`.

`CODEOWNERS`:

```
/services/api/        @argus/backend
/services/bot/        @argus/bot
/services/worker/     @argus/backend
/libs/argus_common/   @argus/backend
/libs/argus_db/       @argus/backend
/domain/              @argus/architects
/plugins/             @argus/plugins
/ops/                 @argus/sre
/.github/workflows/   @argus/sre
```

## 11. Caching

`uv` cache shared across jobs:

```yaml
- uses: actions/setup-python@v5
  with:
    python-version: "3.12"
- uses: actions/cache@v4
  with:
    path: ~/.cache/uv
    key: uv-${{ runner.os }}-${{ hashFiles('uv.lock') }}
    restore-keys: uv-${{ runner.os }}-
```

Docker layers cached via Buildx GHA cache:

```yaml
- uses: docker/build-push-action@v6
  with:
    cache-from: type=gha
    cache-to: type=gha,mode=max
```

## 12. Notifications

- **Failure on PR**: GitHub comment via `gh pr comment`.
- **Failure on main**: Telegram alert to ops chat.
- **Success on main**: Telegram alert to dev chat.
- **Production deploy**: Telegram + Slack.
- **SLO breach** (added in V2): PagerDuty.

## 13. Scorecard (`scorecard.yml`)

OpenSSF Scorecard weekly:

```yaml
name: Scorecard
on:
  schedule:
    - cron: "0 6 * * 1"
  workflow_dispatch:

jobs:
  analysis:
    runs-on: ubuntu-latest
    permissions:
      security-events: write
      id-token: write
    steps:
      - uses: actions/checkout@v4
      - uses: ossf/scorecard-action@v2
        with:
          results_file: results.sarif
          results_format: sarif
          publish_results: true
```

## 14. Dependency updates

Dependabot config:

```yaml
# .github/dependabot.yml
version: 2
updates:
  - package-ecosystem: "pip"
    directory: "/"
    schedule:
      interval: "weekly"
    groups:
      python-deps:
        patterns: ["*"]
    commit-message:
      prefix: "deps"
  - package-ecosystem: "docker"
    directory: "/ops/docker"
    schedule:
      interval: "weekly"
  - package-ecosystem: "github-actions"
    directory: "/.github/workflows"
    schedule:
      interval: "weekly"
```

PRs auto-created weekly. CI runs on each. Mergify auto-merges if
green and labeled `auto`.

## 15. Required checks

Branch protection on `main` requires:

- `lint / ruff`
- `lint / mypy`
- `lint / bot-boundary`
- `test / unit`
- `test / contract`
- `build / docker`
- `deploy-staging / smoke`

## 16. Deployment strategy

- **Staging**: auto on push to `main`, smoke tested.
- **Production**: manual workflow with canary (10% → 100% over 30
  min) and one-click rollback via Railway revert.
- **Hotfix**: tag `v*.*.*-hotfix.N`, run `deploy-production` with
  the tag.

## 17. Failure handling

- Failed CI on PR → comment + label `needs-fix`.
- Failed deploy → auto-rollback to last green.
- Smoke test fails → page on-call via Telegram.

## 18. CI minutes budget

GitHub free tier: 2,000 min/mo. Our usage:

| Job | Avg minutes | Monthly runs | Total |
|-----|-------------|--------------|-------|
| Lint | 1 | 200 | 200 |
| Test | 4 | 200 | 800 |
| Build | 6 | 50 | 300 |
| Deploy staging | 8 | 50 | 400 |
| Deploy prod | 12 | 4 | 48 |
| Total | | | ~1,750 |

We stay just under 2,000. If we exceed, we move to GitHub Team
($4/user/mo) or self-hosted runners on the free Oracle VM.

## 19. Self-hosted runner (V2)

For load tests and longer integration suites, we run a self-hosted
runner on the free Oracle VM:

```yaml
runs-on: [self-hosted, oracle-free, linux]
```

Adds ~3,000 min/mo free.

## 20. Pipeline overview diagram

```
PR opened
   │
   ▼
┌──────┐  ┌──────┐  ┌────────┐
│ lint │  │ test │  │contract│
└──┬───┘  └──┬───┘  └───┬────┘
   └────┬────┘──────────┘
        ▼
   status check
        │
        ▼
   merge to main
        │
        ▼
┌─────────────┐    ┌──────────┐    ┌────────────┐    ┌──────────┐
│ build image │ →  │ migrate  │ →  │ deploy api │ →  │ deploy   │
│             │    │ staging  │    │ staging    │    │ bot+work │
└─────────────┘    └──────────┘    └────────────┘    └─────┬────┘
                                                            │
                                                            ▼
                                                       smoke test
                                                            │
                                                            ▼
                                                       notify dev chat

Tag v*.*.*
   │
   ▼
┌─────────────┐
│ deploy prod │
│ canary 10%  │
└──────┬──────┘
       ▼
   smoke 30 min
       ▼
   promote 100%
       ▼
   notify ops chat
```

This is the complete CI/CD pipeline. It runs on GitHub free tier
until ~$20/mo revenue, at which point we add the Team plan and a
self-hosted runner.
