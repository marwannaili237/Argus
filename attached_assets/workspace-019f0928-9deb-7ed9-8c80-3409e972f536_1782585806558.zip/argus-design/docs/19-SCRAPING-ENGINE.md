# 19 — Universal Scraping Engine

> Layer above existing infrastructure (FastAPI / Celery / Redis). Worker-only.
> Provides first-party plugins and built-in investigation capabilities with
> a unified scraping interface that abstracts HTTP, browser, proxy,
> anti-bot, and artifact capture.

---

## 0. Position in the architecture

```
                        ┌──────────────────────────────────────┐
                        │  Plugin SDK  (07-PLUGIN-SDK)         │
                        │  argus_plugin_sdk.http (thin)        │
                        └────────────────┬─────────────────────┘
                                         │ wraps
                        ┌────────────────▼─────────────────────┐
                        │  Scraping Engine  (THIS DOCUMENT)    │
                        │  - HTTPClient                       │
                        │  - BrowserClient                    │
                        │  - SessionManager                   │
                        │  - ExtractionPipeline               │
                        │  - ArtifactCapture                  │
                        └─┬────────────┬────────────┬─────────┘
                          │            │            │
                ┌─────────▼──┐  ┌──────▼─────┐  ┌──▼────────────┐
                │ 20-BROWSER │  │ 21-PROXY   │  │ 22-ANTI-BOT   │
                │ MANAGER    │  │ MANAGER    │  │               │
                └────────────┘  └────────────┘  └───────────────┘
                          │
                          ▼
                ┌─────────────────────┐
                │  Domain Core        │
                │  ScrapingOutcome    │
                │  (framework-free)   │
                └─────────────────────┘
```

The Scraping Engine **lives in the worker process only**. It MUST
NOT be imported by `services/api` (HTTP-bound synchronous waits
would block the API event loop) or `services/bot` (boundary
violation).

First-party plugins (`plugins/plugin_http_crawl/`,
`plugins/plugin_social_x/`) call into the engine via an internal
function surface — they never instantiate Chromium or HTTP clients
directly.

Third-party plugins (per [07-PLUGIN-SDK.md](07-PLUGIN-SDK.md)) use
the thin `argus_plugin_sdk.http` facade which is a **subset** of
this engine's contract.

## 1. Goals and non-goals

**Goals**

- Single interface for any URL fetch (HTTP, browser, API).
- Predictable performance under load.
- Anti-bot awareness without leaking through to plugin authors.
- Always produce an artifact (HTML, screenshot, PDF) on success.
- Play nicely with existing plugins, planner, scorer, normalizer.

**Non-goals**

- A new full browser-automation DSL — we expose a small primitive
  surface, not "Puppeteer in Python".
- Bypassing paywalls, CAPTCHAs, or login walls that require human
  interaction (those go to 28-SCHEDULER as manual tasks).
- A scraping-as-a-service marketplace — V2 only.

## 2. Public interface contract

The engine is invoked from worker tasks. Plugin authors do not
import it; they import `argus_plugin_sdk.http`. Internal callers
use the contract below.

```python
# libs/argus_intelligence/scraping/contract.py
from typing import Protocol, Literal
from dataclasses import dataclass

class ScrapingEngine(Protocol):
    async def fetch(self, request: "ScrapeRequest") -> "ScrapeResult": ...
    async def fetch_many(self, requests: list["ScrapeRequest"]) -> list["ScrapeResult"]: ...
    async def close(self) -> None: ...
```

### 2.1 `ScrapeRequest`

```python
@dataclass(slots=True)
class ScrapeRequest:
    url: str
    method: Literal["GET","POST","HEAD","PUT","DELETE"] = "GET"
    mode: Literal["http","browser","auto"] = "auto"
    headers: dict[str, str] = field(default_factory=dict)
    cookies: dict[str, str] = field(default_factory=dict)
    body: bytes | None = None
    timeout_s: float = 30.0
    proxy_profile: str | None = None        # name from 21-PROXY
    geo: str | None = None                  # e.g. "us", "de", "auto"
    fingerprint_profile: str | None = None  # name from 22-ANTI-BOT
    wait_for: str | None = None             # browser selector
    screenshot: bool = False
    capture_html: bool = True
    extract_rules: list["ExtractRule"] = field(default_factory=list)
    risk_tolerance: Literal["low","medium","high"] = "medium"
    tenant_id: UUID
    plugin_run_id: UUID
    cost_estimate_max_credits: int = 1
```

### 2.2 `ScrapeResult`

```python
@dataclass(slots=True)
class ScrapeResult:
    request: ScrapeRequest
    status_code: int | None
    final_url: str | None
    headers: dict[str, str]
    cookies: dict[str, str]
    html: str | None
    artifacts: list[ArtifactRef]            # 27-ARTIFACT-STORAGE
    extracted: list[ExtractedField]
    timing_ms: int
    bytes_received: int
    proxy_used: ProxyRef | None
    fingerprint_used: str | None
    risk_signals: list[RiskSignal]
    success: bool
    error: str | None
    error_class: str | None                 # e.g. "BotDetected"
```

### 2.3 Versioning

The contract version is `1.x`. Breaking changes bump major. Additive
fields (new optional fields on `ScrapeRequest`) bump minor. The
contract is registered in
`libs/argus_intelligence/scraping/__init__.py` and loaded by plugin
loaders via `importlib.metadata.version("argus-scraping")`.

## 3. State machine — fetch lifecycle

```
                  ┌─────────┐
                  │ pending │
                  └────┬────┘
                       │
        ┌──────────────▼──────────────┐
        │     plan_request            │   decides http|browser|skip
        └──────┬──────────┬──────────┘
               │          │
        ┌──────▼──┐   ┌───▼─────┐
        │  http   │   │ browser │
        └──┬──────┘   └──┬──────┘
           │             │
       ┌───▼─────┐   ┌───▼─────────┐
       │  fetch  │   │  launch ctx │
       └────┬────┘   └────┬────────┘
            │             │
       ┌────▼────────┐    │
       │ validate    │    │
       │ response    │    │
       └────┬────────┘    │
            │             │
       ┌────▼─────────────▼──────┐
       │   extract + artifacts   │
       └────┬────────────────────┘
            │
       ┌────▼─────────┐
       │  outcome     │
       └──────┬───────┘
              │
   ┌──────────┼──────────┐
   │          │          │
┌──▼──┐   ┌───▼───┐   ┌───▼───┐
│ ok  │   │retry  │   │ fail  │
└─────┘   └───┬───┘   └───┬───┘
              │           │
              └─────┬─────┘
                    │
            ┌───────▼────────┐
            │  backoff/jitter │
            │  swap proxy     │
            │  swap fp        │
            │  escalate mode  │
            └───────┬────────┘
                    │
            retry ≤ max → return
            retry > max → fail with reason
```

Terminal outcomes: `ok`, `fail`. Retries happen on
`RetryableError` subclasses only.

## 4. Mode selection (`auto`)

When `mode="auto"`:

1. Apply 21-PROXY preflight → pick proxy.
2. Apply 22-ANTI-BOT preflight → pick fingerprint profile.
3. Probe target with a cheap HTTP HEAD.
4. If HEAD returns 200 and `Content-Type` is HTML → prefer browser
   (because dynamic content).
5. Else if `Content-Type` is JSON or `text/*` → prefer HTTP.
6. Else if HEAD 403/429/challenge → prefer browser.
7. Else if risk score (22) is `high` → prefer browser with
   `slow_timing`.
8. If both viable → HTTP first (10x cheaper).

The decision is recorded on `ScrapeResult.fingerprint_used` and
`proxy_used` for audit.

## 5. HTTP engine

### 5.1 Client

```python
# libs/argus_intelligence/scraping/http.py
class HttpClient:
    def __init__(self, settings, proxy_router, fingerprint_router):
        self._client = httpx.AsyncClient(
            http2=True,
            limits=httpx.Limits(
                max_keepalive_connections=settings.scrape_max_keepalive,
                max_connections=settings.scrape_max_connections,
                keepalive_expiry=30,
            ),
            timeout=httpx.Timeout(30.0, connect=5.0),
            follow_redirects=True,
            headers={"Accept":"*/*","Accept-Language":"en"},
        )
        self._proxy_router = proxy_router
        self._fingerprint = fingerprint_router

    async def fetch(self, req: ScrapeRequest) -> ScrapeResult:
        ...
```

### 5.2 Connection pool sizing

- `max_connections = worker_concurrency × 4`
- `max_keepalive_connections = max_connections / 2`
- DNS resolver: `aiodns` with custom resolver to avoid glibc DNS
  leaks (anti-bot, see 22).
- TLS: default. We do NOT use `curl_cffi` for HTTP mode; that is
  reserved for browser mode.

### 5.3 Headers

`HttpClient.fetch` merges in this order (later wins):

1. Engine defaults (Accept, Accept-Language, User-Agent baseline).
2. Fingerprint profile headers (from 22).
3. Caller-supplied `request.headers`.

Sec-CH-UA, Sec-Fetch-* headers come from the fingerprint profile,
not from caller. Caller is **not** allowed to set them directly
(use a fingerprint profile).

### 5.4 Body and form handling

- `body` is bytes. Caller is responsible for serialization.
- For multipart, caller passes `multipart=httpx._multipart.MultipartStream(...)`.
  We do not auto-construct.
- For application/x-www-form-urlencoded, caller uses
  `httpx.URL("...",params=...)`.

### 5.5 Streaming responses

For large pages (>5 MB raw HTML), we stream into a `BytesIO`
bounded to `settings.scrape_max_body_bytes` (default 50 MB). Beyond
that we abort and emit `BodyTooLarge`.

## 6. Browser engine

### 6.1 Why Playwright

- Best Python bindings for Chromium.
- Built-in CDP support for fingerprint tweaks.
- Easier multiprocess isolation than Selenium.

### 6.2 Lifecycle

Browser instances are managed by `BrowserManager` (see
[20-BROWSER-MANAGER.md](20-BROWSER-MANAGER.md)). The Scraping
Engine **never** spawns Chromium directly.

```python
async def fetch_via_browser(self, req: ScrapeRequest) -> ScrapeResult:
    async with self._browser.acquire(
        tenant_id=req.tenant_id,
        geo=req.geo,
        fingerprint=req.fingerprint_profile,
    ) as lease:
        ctx = await lease.new_context(headers=req.headers, cookies=req.cookies)
        page = await ctx.new_page()
        try:
            resp = await page.goto(req.url, timeout=req.timeout_s*1000,
                                   wait_until="domcontentloaded")
            if req.wait_for:
                await page.wait_for_selector(req.wait_for, timeout=req.timeout_s*1000)
            html = await page.content()
            screenshot = await page.screenshot(full_page=True) if req.screenshot else None
            cookies = {c["name"]: c["value"] for c in await ctx.cookies()}
            ...
        finally:
            await ctx.close()
```

### 6.3 Hard limits

Per task:

- `max_pages = 1` by default. Multi-page is a separate API
  (`browser.crawl`) — V2.
- `max_runtime_s = 60` default.
- `max_actions = 0` — clicking is opt-in via
  `request.actions: list[Action]` and is gated by risk tolerance.

### 6.4 Fingerprint overrides

When 22-ANTI-BOT emits a fingerprint profile, we apply via CDP:

- `Page.addScriptToEvaluateOnNewDocument` to override
  `navigator.webdriver`, `navigator.languages`, `navigator.plugins`,
  `navigator.platform`, `screen`, etc.
- `Network.setUserAgentOverride`.
- Locale and timezone via `Emulation.setLocaleOverride` and
  `Emulation.setTimezoneOverride`.

## 7. Session management

A session is a named container of cookies + headers + history.

```python
@dataclass(slots=True)
class Session:
    session_id: str
    tenant_id: UUID
    domain: str                          # primary host
    cookies: dict[str, str]
    headers: dict[str, str]
    last_used: datetime
    ttl_s: int = 1800
    fingerprint_profile: str | None = None
    proxy_profile: str | None = None
```

Sessions are **domain-scoped** — they are NOT shared across
domains. They are stored in Redis under `argus:session:{tenant}:{domain}:{sid}` with TTL `ttl_s`.

### 7.1 Lifecycle

```
   created ──► active ──► idle ──► expired
                 │           │
                 │           └──► resume (TTL refreshed)
                 │
                 └──► revoked (manual, GDPR purge)
```

### 7.2 Sticky sessions

When a `ScrapeRequest.cookies` is non-empty and matches a session
key, we resume that session. Otherwise we create a new one.

### 7.3 Cross-session reuse

A plugin can opt into session reuse via `request.session_id`. The
engine refuses to resume a session whose domain does not match
`request.url`'s effective top-level domain + 1 (eTLD+1). This
prevents cookie leakage.

## 8. Cookie management

- Per-domain jar stored in Redis.
- SameSite / Secure / HttpOnly preserved.
- Cookies are **never** logged in plain text; only names are
  logged.
- On session end, cookies are kept for `ttl_s` so subsequent
  investigations can resume.
- GDPR: when user deletes account, session keys are deleted
  immediately.

## 9. Request lifecycle — full sequence

```
worker task       ScrapingEngine    Http/Browser   ProxyMgr    FingerprintMgr   ArtifactStore
    │                  │                │              │              │               │
    │ fetch(req)       │                │              │              │               │
    ├─────────────────►│                │              │              │               │
    │                  │ select mode    │              │              │               │
    │                  │ pick proxy     │              │              │               │
    │                  ├───────────────►│              │              │               │
    │                  │ pick fingerprint              │              │               │
    │                  ├─────────────────────────────────────────────►│               │
    │                  │ build headers + payload       │              │               │
    │                  ├───────────────►│              │              │               │
    │                  │                │ CONNECT      │              │               │
    │                  │                ├─────────────►│              │               │
    │                  │                │ TLS handshake│              │               │
    │                  │                │ GET /…       │              │               │
    │                  │                │ response     │              │               │
    │                  │                ├──────────────┤              │               │
    │                  │ validate response (status, ct, body)         │               │
    │                  │ detect bot challenge?                         │               │
    │                  │ extract (rules)              │              │               │
    │                  │ upload artifacts             │              │               │
    │                  ├───────────────────────────────────────────────────────────────►│
    │                  │ build ScrapeResult           │              │               │
    │ ◄────────────────┤                │              │              │               │
```

Browser path inserts `BrowserManager.acquire()` between steps 4
and 5.

## 10. Retry strategy

| Failure class | Retry? | Backoff | Escalation |
|---------------|--------|---------|------------|
| `ConnectError` (network) | yes | 2^n + jitter, max 60s | swap proxy |
| `TimeoutException` | yes | 2^n + jitter, max 60s | swap proxy |
| `RemoteProtocolError` | yes | linear 5s | swap proxy |
| HTTP 5xx | yes | 2^n + jitter, max 120s | swap proxy |
| HTTP 429 | yes | per `Retry-After` | swap proxy + cooldown proxy |
| HTTP 403 | yes (1) | 30s | swap fingerprint + slow_timing |
| HTTP 401 | no | — | return as `AuthRequired` |
| `BotDetected` | yes (2) | 60s + jitter | escalate to browser mode |
| `BodyTooLarge` | no | — | return with truncation flag |
| `MalformedResponse` | no | — | return with raw bytes |
| `BrowserLaunchFailed` | yes (3) | 30s | ask BrowserManager to recover |

Default max retries: **3** per request. Caller may override via
`request.max_retries` (bounded to 5).

## 11. Failure recovery

- Connection pool error → circuit-breaker opens for 30s; requests
  fast-fail with `UpstreamCircuitOpen`.
- Browser pool exhausted → fall back to HTTP mode automatically if
  risk tolerance is `low` or `medium`. If `high`, fail with
  `BrowserPoolExhausted`.
- Proxy pool exhausted → fail with `ProxyPoolExhausted` (caller
  must decide whether to abort investigation).
- Fingerprint detection (22 emits `confidence > 0.8`) → switch
  fingerprint profile, then retry.

All failures write to `audit.event` and increment
`argus_scrape_failures_total{class,mode}` metric.

## 12. Extraction pipeline

Three extractors run in parallel; results merged.

### 12.1 CSS/XPath selectors

```python
@dataclass(slots=True)
class ExtractRule:
    name: str
    selector: str                  # CSS or "xpath=..."
    attr: str | None = None        # default text
    many: bool = False
    transform: Literal["none","trim","lowercase","int","url","date"] = "none"
```

### 12.2 JSON-LD / Schema.org

We parse `<script type="application/ld+json">` blocks and map
`@type` to our entity schema. Top-level types: `Person`,
`Organization`, `Product`, `Article`, `WebSite`, `BreadcrumbList`.

### 12.3 Microdata / OpenGraph

Backup extractor when JSON-LD is absent. Maps `og:title`,
`og:image`, `og:description`, `twitter:*`.

### 12.4 Merge rules

Extracted values are merged into `ScrapeResult.extracted` as
`ExtractedField(name, value, source, confidence)`. Confidence per
source:

| Source | Default confidence |
|--------|--------------------|
| JSON-LD | 0.9 |
| Microdata | 0.7 |
| OpenGraph | 0.6 |
| CSS rule | 0.5 (raise to 0.8 if selector name matches entity attribute) |
| Regex | 0.4 |

Confidence is later combined with source reliability (26) and
freshness (26) into final evidence confidence.

## 13. Screenshot generation

- Full-page by default; viewport-only if `request.screenshot = "viewport"`.
- Format: PNG for fidelity; WebP for size.
- Compression: quality 85 by default.
- Stored in 27-ARTIFACT-STORAGE under `artifacts/screenshots/`.
- Capped at 10 MB; over that, downscaled.
- Watermark for free-tier investigations: timestamp + tenant_id
  (subtle, lower-right, 12px).

## 14. HTML snapshots

- Full DOM, serialized via `page.content()` (browser) or response
  text (HTTP).
- gzipped (level 6) before upload.
- Includes a sidecar metadata file with: final URL, headers,
  cookies (names only), captured_at, plugin_run_id.
- SHA256 of uncompressed content stored; duplicate content
  detected → referenced instead of re-stored.

## 15. Performance optimizations

- **Connection pooling**: shared HTTPX pool per worker.
- **HTTP/2 multiplexing**: enabled by default.
- **Browser warm pool**: see 20-BROWSER-MANAGER.
- **Cache by URL hash** (when `request.cache_key` set):
  - Redis cache, TTL `request.cache_ttl_s`, default 300s.
  - Used for re-rendering the same URL in the same investigation.
- **Parallel fetch_many**: up to 16 concurrent per task via
  `asyncio.Semaphore`. Caller controls via `request.concurrency`.
- **Speculative parsing**: while waiting for full HTML, start
  extracting `<head>` partials immediately.
- **DNS pre-resolve**: maintain a small LRU of resolved hosts to
  skip DNS on hot domains.

## 16. Resource limits

Per worker:

| Resource | Limit | Overflow action |
|----------|-------|-----------------|
| HTTP connections | 200 | queue (max 1000) |
| Browser contexts | 16 | queue (max 64) |
| Browser pages | 64 (4 per context) | reject with `BrowserPoolExhausted` |
| Memory per worker | 2 GB | OOM killer kicks in |
| CPU seconds per request | 60 | cancel with `BudgetExceeded` |
| Network bytes per request | 50 MB | truncate with `BodyTooLarge` |
| Artifacts per request | 20 | reject excess |
| Cookie jar size per session | 8 KB | evict oldest |

Per request (overrides):

- `timeout_s` (default 30, max 300)
- `max_actions` (browser only; default 0)

## 17. Worker integration

Scraping happens inside Celery tasks. We never call it from the API
process because:

- Browser launches are slow (2-5s); blocking the API is unacceptable.
- Memory pressure (Chromium RSS 200-500 MB) would OOM the API.
- Liveness: API needs to answer `/health` even if the scraper is
  stuck.

### 17.1 Task surface

```python
# services/worker/src/argus_worker/tasks/scraping.py
@shared_task(name="argus.scraping.fetch", bind=True, max_retries=3)
def fetch(self, request_dict: dict) -> dict:
    """Engine entry point. request_dict is JSON-serialized ScrapeRequest."""
    request = ScrapeRequest.from_dict(request_dict)
    result = await engine.fetch(request)
    return result.to_dict()
```

Plugins call this task via `fetch.delay(scrape_request_dict)` or
synchronously via `engine.fetch` when already inside a worker
context.

### 17.2 Streaming events

Each fetch emits:

- `scrape.requested` (start)
- `scrape.attempt` (per attempt; includes mode, proxy, fingerprint)
- `scrape.succeeded` or `scrape.failed`
- `artifact.stored` (per artifact)

The event bus consumers (analytics, scoring, alert generation)
handle these.

## 18. Failure modes — full table

| Failure | Detection | Recovery | Caller impact |
|---------|-----------|----------|---------------|
| Proxy auth failure | 407 from upstream | mark proxy dead; swap | retry with new proxy |
| Proxy timeout | connect > 5s | swap | retry |
| TLS handshake fail | exception | swap; downgrade TLS profile | retry |
| DNS leak (resolved by glibc) | compare with DoH | mark fingerprint risk high | retry with DoH |
| Bot challenge (Cloudflare, etc.) | 403 + known marker | escalate to browser | retry in browser mode |
| Browser crash | worker task raises | BrowserManager restarts | retry with fresh browser |
| Memory pressure | RSS > 80% of limit | drain pool; restart worker | fast-fail new requests |
| Disk full (artifacts) | upload fails | reject upload; keep result | `ArtifactStoreError` returned |
| Plugin code requests unsafe URL | manifest mismatch | reject before launch | `ManifestViolation` |

## 19. Security

- All fetched URLs are checked against plugin manifest's
  `[plugin.capabilities.http]` allowlist. URLs outside the
  allowlist are rejected before any network call.
- Proxy credentials are kept in Redis under
  `argus:proxy:credential:{proxy_id}` with restrictive ACLs.
- Cookie names only are logged (not values).
- Authentication headers (Authorization, Cookie) are scrubbed from
  any logs and from artifacts.
- TLS verification is enforced; we do **not** allow
  `verify=False`. Exception: explicit `dangerously_skip_tls`
  flag for V2 only, gated behind tenant-level flag.

## 20. Abuse prevention

- Per-tenant scrape rate limit (31): default 60 req/min, 1000/hour.
- Per-domain rate limit (Redis token bucket): 10 req/min default.
  Many sites have stricter limits; we honor `Retry-After`.
- Cost cap per scrape via 31-COST-CONTROLLER.
- "Scrape war" detection: if a tenant hits > 50 distinct domains in
  60s, raise risk score and slow down.
- Domains under court order or DMCA: hard blocklist at engine
  level (configurable).
- We DO NOT target login-protected resources without explicit
  `auth_via_session` flag and user consent log.

## 21. Scalability — millions of investigations

Design supports:

- **1 investigation = avg 20 scrapes**, so 1M investigations/day =
  20M scrapes/day = 230 scrapes/sec avg, 1500 peak.
- Per-worker throughput target: 30 scrapes/sec (HTTP) or 2
  scrapes/sec (browser).
- 16 workers handle peak load at 50% utilization.
- Browser pool target: 32 contexts idle, 4 active = 8 scrapes/sec
  browser throughput.
- Connection pool: 200 conns/worker × 16 workers = 3,200 conns.
- State (sessions, cookies) in Redis: estimated 10k active sessions
  × 4 KB = 40 MB. Trivial.

Bottlenecks and mitigations:

- Browser pool memory (Chromium 200 MB each × 16 = 3.2 GB): run
  worker on a 8 GB VM. Cap contexts at 16.
- Network egress: budget $20/mo per worker. 100 GB/mo at AWS
  egress rates. Mitigation: cache aggressively, gzip everything.
- CPU on browser: each context = 1 vCPU equivalent. 16 contexts =
  16 vCPU. Workers scale vertically.

## 22. Free-tier compatibility

- HTTP path runs on the smallest PaaS instances (256 MB RAM).
- Browser path needs ≥ 1 GB RAM per worker. We **do not** enable
  browser mode on free tier; HTTP only. Documented.
- Local dev (Termux + proot): browser mode disabled by default
  (`ARGUS_SCRAPING_BROWSER=0`). Use HTTP only.
- Object store: writes are conditional; if R2 free quota exceeded,
  artifacts fall back to local disk in `~/.local/share/argus/artifacts/`.

## 23. Configuration

```bash
# .env additions
ARGUS_SCRAPING_BROWSER=1                # 0|1
ARGUS_SCRAPING_MAX_CONNECTIONS=200
ARGUS_SCRAPING_MAX_KEEPALIVE=100
ARGUS_SCRAPING_MAX_BODY_BYTES=52428800  # 50 MB
ARGUS_SCRAPING_DEFAULT_TIMEOUT_S=30
ARGUS_SCRAPING_DEFAULT_RETRIES=3
ARGUS_SCRAPING_REQUEST_CACHE_TTL_S=300
ARGUS_SCRAPING_ARTIFACT_DIR=/var/lib/argus/artifacts
```

## 24. Trade-offs and rationale

| Decision | Rationale | Trade-off |
|----------|-----------|-----------|
| Engine lives in worker only | Avoid blocking API | Slight latency for inter-process calls |
| Single HTTP+Browser interface | Simpler plugin code | Some requests need browser-specific options |
| Auto mode selection | Less work for plugin authors | May pick HTTP for a JS site; we re-probe |
| Session cookies in Redis | Cheap, TTL friendly | Cookies serialized across processes |
| Fingerprint via Playwright CDP | Most reliable | Tied to Chromium; Firefox/Safari harder |
| Artifacts as separate objects | Cheap dedup, audit | Storage cost; small investigations ok |
| Retry with proxy swap | Resilient | May appear aggressive to target site |

## 25. References

- [07-PLUGIN-SDK.md](07-PLUGIN-SDK.md) — Plugin SDK surface
- [20-BROWSER-MANAGER.md](20-BROWSER-MANAGER.md) — Browser pool
- [21-PROXY-MANAGER.md](21-PROXY-MANAGER.md) — Proxy rotation
- [22-ANTI-BOT.md](22-ANTI-BOT.md) — Fingerprinting
- [27-ARTIFACT-STORAGE.md](27-ARTIFACT-STORAGE.md) — Storage
- [31-COST-CONTROLLER.md](31-COST-CONTROLLER.md) — Budgets
- [06-WORKERS.md](06-WORKERS.md) — Worker integration
- [32-OBSERVABILITY.md](32-OBSERVABILITY.md) — Metrics
