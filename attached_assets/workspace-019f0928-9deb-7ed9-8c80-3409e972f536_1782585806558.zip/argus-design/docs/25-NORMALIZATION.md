# 25 — Normalization

> Canonical entity model, normalization rules, deduplication,
> cross-plugin reconciliation, metadata preservation, schema
> versioning, validation pipeline. Pure domain logic.

---

## 0. Goals

1. Every entity has exactly one canonical form per type.
2. Two plugins observing the same entity produce one row, not two.
3. Schema changes are versioned and backward compatible.
4. Metadata (provenance, raw value, plugin source) is preserved
   through normalization.

## 1. Canonical entity model

```python
# domain/entities/canonical.py
class EntityType(str, Enum):
    PERSON         = "person"
    ORGANIZATION   = "organization"
    DOMAIN         = "domain"
    SUBDOMAIN      = "subdomain"
    EMAIL          = "email"
    PHONE          = "phone"
    IP             = "ip"
    USERNAME       = "username"
    ADDRESS        = "address"
    DOCUMENT       = "document"
    ACCOUNT        = "account"
    OTHER          = "other"

@dataclass(slots=True, frozen=True)
class CanonicalEntity:
    entity_type: EntityType
    canonical_value: str
    attributes: Mapping[str, str]
    aliases: tuple[str, ...]
    schema_version: int = 1

    def stable_key(self) -> str:
        return f"{self.entity_type.value}:{self.canonical_value}"
```

Every domain row goes through `CanonicalEntity` before being
written to `investigation.entity`. Raw input is preserved on the
evidence row (see `Evidence.raw`).

## 2. Normalization rules per type

### 2.1 email

```python
def normalize_email(value: str) -> str:
    v = value.strip().lower()
    local, _, domain = v.partition("@")
    if not local or not domain:
        raise InvalidEntityValue("email", value)
    # strip +tag
    local = local.split("+", 1)[0]
    # gmail dots
    if domain in ("gmail.com", "googlemail.com"):
        local = local.replace(".", "")
        domain = "gmail.com"
    # punycode domain
    domain = domain.encode("idna").decode("ascii")
    return f"{local}@{domain}"
```

### 2.2 domain / subdomain

```python
def normalize_domain(value: str, kind: EntityType) -> str:
    v = value.strip().rstrip(".").lower()
    # IDN → punycode
    v = v.encode("idna").decode("ascii")
    # reject IP-shaped values
    try:
        ipaddress.ip_address(v)
        raise InvalidEntityValue("domain", value)
    except ValueError:
        pass
    # hostname syntax check (RFC 1035)
    if not re.fullmatch(r"[a-z0-9.\-]{1,253}", v):
        raise InvalidEntityValue("domain", value)
    return v
```

Subdomain rule is the same plus the constraint that it has at
least 3 labels.

### 2.3 phone

```python
def normalize_phone(value: str, default_region: str | None = None) -> str:
    import phonenumbers
    try:
        pn = phonenumbers.parse(value, default_region)
    except phonenumbers.NumberParseException as e:
        raise InvalidEntityValue("phone", value) from e
    if not phonenumbers.is_valid_number(pn):
        raise InvalidEntityValue("phone", value)
    return phonenumbers.format_number(pn, phonenumbers.PhoneNumberFormat.E164)
```

### 2.4 ip

```python
def normalize_ip(value: str) -> str:
    try:
        ip = ipaddress.ip_address(value)
    except ValueError:
        raise InvalidEntityValue("ip", value)
    return str(ip)  # canonical form (e.g. ::1 for IPv6)
```

### 2.5 username

```python
def normalize_username(value: str) -> str:
    v = value.strip().lstrip("@").lower()
    if not re.fullmatch(r"[a-z0-9._\-]{1,64}", v):
        raise InvalidEntityValue("username", value)
    return v
```

### 2.6 person

```python
def normalize_person(value: str) -> tuple[str, dict]:
    v = re.sub(r"\s+", " ", value.strip())
    parts = v.split(" ", 1)
    given = parts[0].lower()
    family = parts[1].lower() if len(parts) > 1 else ""
    canon = f"{given} {family}".strip()
    return canon, {"given_name": given, "family_name": family}
```

### 2.7 organization

```python
LEGAL_SUFFIXES = {
    "llc","inc","ltd","gmbh","co","corp","corporation",
    "company","srl","sa","ag","oy","ab","as","plc","bv",
    "limited","incorporated",
}

def normalize_organization(value: str) -> str:
    v = re.sub(r"[^\w\s&]", "", value.strip().lower())
    v = re.sub(r"\s+", " ", v)
    tokens = [t for t in v.split() if t not in LEGAL_SUFFIXES]
    return " ".join(tokens)
```

### 2.8 url

```python
def normalize_url(value: str) -> str:
    p = urlparse(value.strip())
    if p.scheme not in ("http","https"):
        raise InvalidEntityValue("url", value)
    host = p.hostname or ""
    host = host.rstrip(".").lower()
    host = host.encode("idna").decode("ascii")
    query = parse_qsl(p.query, keep_blank_values=True)
    query.sort()
    return urlunparse((p.scheme.lower(), host, p.path or "/",
                       p.params, urlencode(query), ""))
```

### 2.9 address

Address normalization is lossy and case-specific. We provide:

- Lowercase.
- Collapse whitespace.
- Standardize country names via `pycountry`.
- Return `dict` rather than string.

## 3. Validation pipeline

For every value arriving from a plugin:

```
raw value
   │
   ▼
detect_type(value)            # heuristics (e.g. @ → email)
   │
   ▼
normalize(value, detected_type)  # raises InvalidEntityValue
   │
   ▼
validate(canonical)            # type-specific rules
   │
   ▼
emit CanonicalEntity
```

`detect_type` returns a confidence. If confidence < 0.6, the value
is routed to manual classification (timeline event
`entity.classification_needed`).

## 4. Entity deduplication

### 4.1 Exact match

Within an investigation:

```sql
CREATE UNIQUE INDEX entity_unique_idx
    ON investigation.entity (investigation_id, type, value);
```

This is already in the schema. Two inserts with the same `(inv_id,
type, value)` raise `IntegrityError`; we treat as same entity.

### 4.2 Fuzzy match

For person / organization (where typos are common), we apply
**fuzzy match** before insert:

```python
def fuzzy_match(existing: list[CanonicalEntity],
                candidate: CanonicalEntity) -> CanonicalEntity | None:
    for ent in existing:
        if ent.entity_type != candidate.entity_type:
            continue
        if ent.entity_type in EXACT_TYPES:
            if ent.canonical_value == candidate.canonical_value:
                return ent
        elif ent.entity_type == EntityType.PERSON:
            if person_similarity(ent, candidate) >= 0.85:
                return ent
        elif ent.entity_type == EntityType.ORGANIZATION:
            if org_similarity(ent, candidate) >= 0.85:
                return ent
        elif ent.entity_type == EntityType.USERNAME:
            if levenshtein(ent.canonical_value, candidate.canonical_value) <= 2:
                return ent
    return None

def person_similarity(a, b) -> float:
    a_parts = a.attributes.get("given_name",""), a.attributes.get("family_name","")
    b_parts = b.attributes.get("given_name",""), b.attributes.get("family_name","")
    return max(
        levenshtein_ratio(a.canonical_value, b.canonical_value),
        levenshtein_ratio(a_parts[0], b_parts[0]) * 0.6
        + levenshtein_ratio(a_parts[1], b_parts[1]) * 0.4,
    )
```

### 4.3 Performance

Fuzzy match is **O(n × len(query))**. For investigations with
> 1000 entities we use a BK-tree or a SimHash index built
in-memory per investigation.

## 5. Cross-plugin reconciliation

Same investigation, two plugins report the same entity with
different attributes:

```python
def reconcile(existing: Entity, candidate: Entity) -> Entity:
    merged = existing.copy()
    for k, v in candidate.attributes.items():
        if k not in merged.attributes:
            merged.attributes[k] = v
        elif merged.attributes[k] != v:
            # conflict
            merged.attributes[k] = merged.attributes[k]  # keep first
            merged.conflicts.append({"field": k, "values": [merged.attributes[k], v]})
    merged.aliases = tuple(set(existing.aliases + candidate.aliases))
    merged.confidence = (existing.confidence + candidate.confidence) / 2
    return merged
```

Conflicts are surfaced via `timeline_event.entity.disputed` and
the entity's `conflicts` JSONB column.

## 6. Metadata preservation

Every normalization step records metadata. We never lose raw
input:

```python
@dataclass(slots=True)
class EntityWithProvenance:
    canonical: CanonicalEntity
    raw_inputs: list[RawInput]   # preserved
    plugin_sources: list[str]
    normalized_at: datetime
    normalizer_version: str

@dataclass(slots=True)
class RawInput:
    raw_value: str
    plugin_name: str
    plugin_run_id: UUID
    observed_at: datetime
    confidence: float
```

`EntityWithProvenance` is what's persisted. The raw input list is
stored on the **evidence** row, not the entity row (entity rows
are deduplicated; evidence is per-observation).

## 7. Schema versioning

### 7.1 Entity schema

```python
ENTITY_SCHEMA_VERSION = 1
```

Stored in `investigation.entity.attributes["_schema_version"]`.

When normalizer changes canonical form (e.g. we add country-code
stripping for phones), we bump to version 2. Old entities keep
their version; new ones use the new version.

### 7.2 Backward compatibility

When reading old entities:

- If reader expects v2 but row is v1, re-normalize in-memory and
  upgrade.
- If reader expects v1 but row is v2, downgrade attributes.

We never mutate the row on read; only on explicit
`upgrade_entity_schema` task.

### 7.3 Bumping the version

A normalizer change triggers:

1. Update `ENTITY_SCHEMA_VERSION`.
2. Add migration to re-normalize existing entities (Celery beat
   task, batched).
3. Update tests.

## 8. Cross-investigation canonical (Case-level)

For tenants using **cases** (see 23), entities are merged across
investigations within the case via `tenant_entity_id`:

```python
def upsert_canonical(tenant_id, entity, case_id):
    existing = repo.find_canonical(tenant_id, entity.stable_key(), case_id)
    if existing is None:
        return repo.create_canonical(tenant_id, entity, case_id)
    return existing  # caller merges attributes
```

Canonical rows are stored in `investigation.canonical_entity` (new
table):

```sql
CREATE TABLE investigation.canonical_entity (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id       UUID NOT NULL REFERENCES identity.tenant(id),
    case_id         UUID REFERENCES investigation.case(id) ON DELETE SET NULL,
    type            TEXT NOT NULL,
    canonical_value TEXT NOT NULL,
    first_seen_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    last_seen_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (tenant_id, COALESCE(case_id::text,'_'), type, canonical_value)
);
```

## 9. Failure modes

| Failure | Detection | Recovery |
|---------|-----------|----------|
| Normalizer raises InvalidEntityValue | caught | emit `evidence.invalid_entity` event; evidence row still stored |
| IDNA encoding fails | `idna` raises | log; treat as plain domain |
| Phonenumbers parser fails | `NumberParseException` | store as `other` entity with raw value |
| Fuzzy match returns false positive | manual dispute | split into two entities; admin action |
| Schema version mismatch | check on read | re-normalize |

## 10. Security

- We do not allow user-supplied raw values to bypass validation.
  All evidence flows through normalizer.
- `query_string` in URLs is stripped of `token`, `key`, `auth`
  before normalization (avoid leaking secrets in stored data).
- Phone numbers stored in E.164 only (no formatting that could be
  considered PII leakage).

## 11. Scalability

- Normalization is sync, O(value length). < 100 µs per call.
- BK-tree build for fuzzy match: O(n log n) at investigation start.
- Cross-investigation merge: O(case size) per case; runs as Celery
  task per case write.
- Re-normalization migration: batched by 1000 entities per Celery
  task.

## 12. Configuration

```bash
ARGUS_NORMALIZER_VERSION=1
ARGUS_NORMALIZER_FUZZY_THRESHOLD=0.85
ARGUS_NORMALIZER_STRIP_URL_KEYS=token,key,auth,sig
ARGUS_NORMALIZER_GMAIL_DOTS=1
ARGUS_NORMALIZER_PHONE_DEFAULT_REGION=
```

## 13. Trade-offs and rationale

| Decision | Rationale | Trade-off |
|----------|-----------|-----------|
| Canonical form per type | Consistent merge | Some info loss (case in person) |
| Fuzzy match in-memory | Simple, fast for small N | Doesn't scale past 5k |
| Schema versioning | Forward compatibility | More code |
| E.164 phones only | Less PII leakage | Display requires formatting |
| Strip URL secrets | Avoid token leak | Less debug info |

## 14. References

- [23-INVESTIGATION-GRAPH.md](23-INVESTIGATION-GRAPH.md) — Where entities live
- [24-PLANNER.md](24-PLANNER.md) — Produces evidence
- [26-EVIDENCE-SCORING.md](26-EVIDENCE-SCORING.md) — Confidence
- [03-DATABASE-SCHEMA.md](03-DATABASE-SCHEMA.md) — Storage
