# 35 — Workflow Engine

> Investigation orchestration: task graph (DAG) execution, dependency
> resolution, scheduling, parallel execution, retry, checkpointing,
> resumable investigations, result aggregation, cancellation, progress
> reporting, event integration. Distinct from [24-PLANNER.md](24-PLANNER.md)
> (which designs what to do) — the workflow engine executes the DAG.

---

## 0. Position

```
   Planner (24)        Workflow Engine (35)        Plugin Runtime (33)
       │                       │                          │
       │ Plan (DAG)            │                          │
       ├──────────────────────►│                          │
                               │ resolve dependencies    │
                               │ schedule tasks          │
                               │ execute in parallel     │
                               ├─────────────────────────►│
                               │                          │ run plugin
                               │ ◄─────────────────────────┤
                               │ collect results          │
                               │ aggregate, checkpoint    │
                               │ emit progress events     │
                               ▼
                          Investigation state
```

The workflow engine is **executor**, not **designer**. It receives
a `Plan` from the Planner and runs it to completion. Pure domain
logic with a Celery adapter.

## 1. Goals

1. Execute any DAG with deterministic ordering.
2. Maximize parallelism within tenant concurrency limits.
3. Provide resumable runs (interrupted mid-flight).
4. Stream progress to subscribers (bot SSE).
5. Support cancellation at any step.
6. Aggregate heterogeneous plugin outputs into a unified
   investigation state.

## 2. Public interface

```python
class WorkflowEngine(Protocol):
    async def execute(self, plan: Plan, investigation_id: UUID) -> WorkflowRun: ...
    async def resume(self, investigation_id: UUID) -> WorkflowRun: ...
    async def cancel(self, investigation_id: UUID, reason: str) -> None: ...
    async def status(self, investigation_id: UUID) -> WorkflowStatus: ...
    async def pause(self, investigation_id: UUID) -> None: ...
```

```python
@dataclass(slots=True)
class WorkflowRun:
    run_id: UUID
    investigation_id: UUID
    plan: Plan
    state: WorkflowState
    started_at: datetime
    finished_at: datetime | None
    step_results: dict[UUID, StepResult]
    checkpoint: Checkpoint | None
    metrics: WorkflowMetrics

class WorkflowState(str, Enum):
    PENDING = "pending"
    RUNNING = "running"
    PAUSED = "paused"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"

@dataclass(slots=True)
class Checkpoint:
    version: int
    completed_steps: tuple[UUID, ...]
    in_flight_steps: tuple[UUID, ...]
    pending_steps: tuple[UUID, ...]
    saved_at: datetime
    state_data: dict[str, Any]           # arbitrary serializable
```

### 2.1 Versioning

```python
WORKFLOW_SCHEMA_VERSION = "1.0"
```

Plans carry `schema_version` (see 24-PLANNER §16). Workflow engine
rejects plans with `schema_version` older than the engine's
minimum supported. Bumping major = breaking change.

## 3. Workflow lifecycle

```
   submitted ──► validated ──► scheduled ──► running ──► completed
        │           │             │            │            │
        │           │             │            └──► failed (with retry)
        │           │             │                      │
        │           │             └──► paused ──────────┘
        │           │                  │
        │           └──► rejected (invalid plan)
        └──► rejected (cost exceeded)
```

### 3.1 Step lifecycle

```
   pending ──► scheduled ──► dispatched ──► running ──► completed
       │           │             │            │           │
       │           │             │            │           └──► retried
       │           │             │            └──► failed (terminal)
       │           │             └──► rejected (quota/cap)
       │           └──► skipped (cache valid)
       └──► pruned (dependency failed)
```

## 4. DAG model

The Plan is a DAG:

```python
@dataclass(slots=True, frozen=True)
class Plan:                                # from 24-PLANNER §3
    plan_id: UUID
    investigation_id: UUID
    steps: tuple[PlanStep, ...]
    edges: tuple[Edge, ...]

@dataclass(slots=True, frozen=True)
class Edge:
    from_step: UUID
    to_step: UUID
    kind: Literal["data","control","trigger"]

@dataclass(slots=True, frozen=True)
class PlanStep:
    step_id: UUID
    plugin: PluginRef
    inputs: dict[str, Any]
    depends_on: tuple[UUID, ...]
    timeout_s: float
    retry_policy: RetryPolicy
    cost_estimate: int
    skip_reason: str | None
```

Edges:

- **data**: downstream consumes upstream's outputs as inputs.
- **control**: downstream waits for upstream's status only.
- **trigger**: downstream runs only on upstream's specific outcome.

## 5. Dependency resolution

```python
def topological_levels(plan: Plan) -> list[list[UUID]]:
    levels = []
    remaining = set(s.step_id for s in plan.steps)
    while remaining:
        # steps whose deps are all satisfied
        ready = [s.step_id for s in plan.steps
                 if s.step_id in remaining
                 and all(d in {x for level in levels for x in level}
                         for d in s.depends_on)]
        if not ready:
            raise CycleError(plan)
        levels.append(ready)
        remaining -= set(ready)
    return levels
```

Cycles → `CycleError`. The Planner (24) prevents cycles but the
engine double-checks.

## 6. Scheduling

Each level is a "wave" of steps that can run in parallel. Within
a level, the engine dispatches respecting:

- Tenant concurrency limit (from 31-COST-CONTROLLER).
- Plugin queue priority.
- Plugin capability limits (e.g. browser count).

```python
async def dispatch_wave(engine, plan, level_step_ids):
    sem = asyncio.Semaphore(plan.tenant_concurrency)
    async def dispatch_one(step_id):
        async with sem:
            step = next(s for s in plan.steps if s.step_id == step_id)
            if step.skip_reason:
                return StepResult(step_id, skipped=True, reason=step.skip_reason)
            await engine.dispatch_step(step)
    await asyncio.gather(*[dispatch_one(s) for s in level_step_ids])
```

## 7. Parallel execution

### 7.1 Concurrency model

- Tenant-level concurrency cap (from plan options).
- Plugin-level cap (max N concurrent runs of same plugin).
- Worker-level cap (Celery worker concurrency).
- Browser pool cap (20-BROWSER-MANAGER §5).

These compose. The engine picks the minimum.

### 7.2 Step dispatch

Each step is a Celery task:

```python
@shared_task(name="argus.workflow.step", bind=True, max_retries=3)
def run_step(self, step_id_str: str, plan_id_str: str):
    step, plan = workflow_repo.load_step_and_plan(step_id_str, plan_id_str)
    try:
        result = await plugin_runtime.run(
            PluginRunRequest(
                plugin_name=step.plugin.name,
                plugin_version=step.plugin.version,
                investigation_id=plan.investigation_id,
                plugin_run_id=step.plugin_run_id,
                tenant_id=plan.tenant_id,
                inputs=resolve_inputs(step, plan),
                capabilities=step.plugin.capabilities,
                timeout_s=step.timeout_s,
                ...
            )
        )
        workflow_repo.record_step_result(step_id_str, result)
        evidence_persist(result.evidence)
    except RetryableError as e:
        raise self.retry(exc=e, countdown=backoff(self.request.retries))
```

## 8. Retry policies

Per-step retry policies are declared by the Planner (24).
The engine enforces them.

| Error class | Default retry | Backoff |
|-------------|---------------|---------|
| `PluginTransientError` | 3 | exp, max 60s |
| `PluginTimeoutError` | 1 | linear 30s |
| `UpstreamUnavailableError` | 3 | exp, max 60s |
| `PluginInputError` | 0 | none |
| `PluginPermanentError` | 0 | none |
| `CostQuotaExceeded` | 0 | none (re-plan) |

Retry budget is per-step and per-investigation. A step may retry
3 times; the investigation may retry steps 9 times total.

After all retries exhausted → step marked `failed` and downstream
steps pruned.

## 9. Failure recovery

### 9.1 Step failure

When a step fails terminally:

- Mark step `failed`.
- Prune downstream steps (they depend on missing outputs).
- Continue with unaffected branches.
- Mark investigation `completed` if all branches finished or were
  pruned; `failed` if all branches failed.

### 9.2 Worker crash

Celery's `acks_late=True` requeues the task. The step re-runs from
scratch (idempotent via `plugin_run_id` dedup in evidence).

### 9.3 Investigation crash

If the worker dies during orchestration, the next worker that
picks up the parent task sees `investigation.status='running'` and
reconstructs the workflow state from checkpoints (see §10).

## 10. Checkpointing

### 10.1 What is checkpointed

After each step completes:

- Step result (success/skipped/failed).
- Aggregated outputs available to downstream steps.
- Investigation counters (evidence_count, entity_count, etc.).

### 10.2 Where

```sql
CREATE TABLE investigation.checkpoint (
    investigation_id UUID PRIMARY KEY REFERENCES investigation.investigation(id) ON DELETE CASCADE,
    version          INT NOT NULL,
    state_data       JSONB NOT NULL,        -- WorkflowRun.state_data
    step_results     JSONB NOT NULL,        -- {step_id: StepResult}
    saved_at         TIMESTAMPTZ NOT NULL DEFAULT now()
);
```

Checkpoints are saved after every step.

### 10.3 Frequency

- Every step completion.
- Every 30 s during long-running steps (heartbeat-style).
- On graceful shutdown signal.

## 11. Resumable investigations

`WorkflowEngine.resume(investigation_id)`:

1. Load checkpoint.
2. Mark investigation `running`.
3. Reconstruct DAG from plan (re-loaded by investigation_id).
4. For each step:
   - If completed in checkpoint → skip.
   - If in-flight → re-dispatch (idempotency key prevents
     duplicate evidence).
   - If pending → schedule.
5. Emit `investigation.resumed` event.

Resume respects tenant concurrency cap. Resume is denied if
investigation is older than 30 days (configurable) — staleness
cap.

## 12. Result aggregation

Each step produces a `StepResult`. The engine merges into the
investigation:

```python
def aggregate(results: list[StepResult], inv: Investigation) -> Investigation:
    for r in results:
        for ev in r.evidence:
            inv.add_evidence(ev, source_plugin=r.plugin_name)
        for ent in r.entities:
            inv.add_entity(ent, source_plugin=r.plugin_name)
        for rel in r.relationships:
            inv.add_relationship(rel, source_plugin=r.plugin_name)
        inv.error_count += r.error_count
    inv.recompute_progress()
    return inv
```

Aggregation also triggers:

- Normalization (25-NORMALIZATION).
- Scoring (26-EVIDENCE-SCORING).
- Graph update (23-INVESTIGATION-GRAPH).

## 13. Cancellation

`WorkflowEngine.cancel(investigation_id, reason)`:

1. Set investigation status to `cancelling`.
2. For each in-flight step:
   - `celery_app.control.revoke(task_id, terminate=True)`.
   - Plugin subprocess receives SIGTERM (33 §11).
3. Wait up to 10 s for graceful shutdown.
4. Mark investigation `cancelled`.
5. Emit `investigation.cancelled` event with reason.

Cancellation is idempotent: repeated calls are no-ops.

## 14. Progress reporting

### 14.1 Per-step progress

Each step emits events:

- `workflow.step.scheduled`
- `workflow.step.dispatched`
- `workflow.step.started`
- `workflow.step.progress` (with percent)
- `workflow.step.completed` / `workflow.step.failed`

### 14.2 Aggregate progress

Investigation progress = (completed steps / total steps) weighted
by step cost.

```python
def progress(inv, plan):
    total = sum(s.cost_estimate for s in plan.steps)
    done = sum(s.cost_estimate for s in plan.steps
               if s.step_id in inv.completed_steps)
    return min(100, int(done * 100 / max(total, 1)))
```

### 14.3 Streaming to subscribers

The bot (05) opens SSE on `/v1/investigations/{id}/events`.
The workflow engine publishes events to Redis Streams; the API
forwards to SSE.

## 15. Event integration

Topics consumed by the engine:

- `workflow.resume_requested` (admin bot)
- `workflow.pause_requested` (admin bot)
- `plugin.upgraded` — re-plan if pinned version changes

Topics emitted by the engine:

- `workflow.started`
- `workflow.step.completed`
- `workflow.step.failed`
- `workflow.progress`
- `workflow.completed`
- `workflow.failed`
- `workflow.cancelled`

Schema versioning per topic (09-EVENT-SYSTEM §7).

## 16. State diagram

```
   submitted ─► validated ─► scheduled ─► running ─► completed
       │           │            │           │           │
       │           │            │           │           └──► failed
       │           │            │           └──► paused ──► resumed
       │           │            │                          │
       │           │            │                          ▼
       │           │            └──► cancelled ◄────────────┘
       │           └──► rejected
       └──► rejected
```

## 17. Sequence diagram

```
Planner       Workflow        Celery        Plugin         PluginRuntime
   │           Engine                         │
   │ plan       │                             │
   ├───────────►│                             │
   │            │ validate DAG                │
   │            │ topo levels                  │
   │            │ dispatch wave 1              │
   │            ├──────────────►  step A       │
   │            │              ├─────────────►│
   │            │              │ run          │
   │            │              │ ◄─────────────┤
   │            │ checkpoint   │              │
   │            │ dispatch wave 2              │
   │            ├──────────────►  step B,C     │
   │            │              ├─────────────►│
   │            │              ├─────────────►│
   │            │              │ both run     │
   │            │              │ both done    │
   │            │ ◄────────────┤              │
   │            │ reduce       │              │
   │            │ complete     │              │
   │            │              │              │
```

## 18. Data model additions to 03

```sql
CREATE TABLE investigation.workflow_run (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    investigation_id    UUID NOT NULL REFERENCES investigation.investigation(id) ON DELETE CASCADE,
    plan_id             UUID NOT NULL,
    state               TEXT NOT NULL DEFAULT 'pending',
    started_at          TIMESTAMPTZ,
    finished_at         TIMESTAMPTZ,
    pause_count         INT NOT NULL DEFAULT 0,
    resume_count        INT NOT NULL DEFAULT 0,
    cancel_reason       TEXT,
    CONSTRAINT workflow_run_state_chk CHECK (
        state IN ('pending','validated','scheduled','running',
                  'paused','completed','failed','cancelled')
    )
);
CREATE INDEX workflow_run_investigation_idx
    ON investigation.workflow_run (investigation_id);

CREATE TABLE investigation.step_result (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    workflow_run_id     UUID NOT NULL REFERENCES investigation.workflow_run(id) ON DELETE CASCADE,
    step_id             UUID NOT NULL,
    state               TEXT NOT NULL,
    started_at          TIMESTAMPTZ,
    finished_at         TIMESTAMPTZ,
    duration_ms         INT,
    attempts            INT NOT NULL DEFAULT 0,
    evidence_count      INT NOT NULL DEFAULT 0,
    entity_count        INT NOT NULL DEFAULT 0,
    relationship_count  INT NOT NULL DEFAULT 0,
    error_class         TEXT,
    error_message       TEXT,
    metrics             JSONB NOT NULL DEFAULT '{}',
    CONSTRAINT step_result_state_chk CHECK (
        state IN ('pending','scheduled','dispatched','running',
                  'completed','failed','skipped','pruned')
    )
);
CREATE INDEX step_result_run_idx ON investigation.step_result (workflow_run_id);
CREATE INDEX step_result_state_idx ON investigation.step_result (state);
```

## 19. Failure modes

| Failure | Detection | Recovery |
|---------|-----------|----------|
| Plan has cycle | topo sort raises | reject plan |
| Plan schema too old | version check | reject |
| Step exceeds budget | cost controller | abort investigation |
| Worker dies mid-investigation | Celery requeue | resume from checkpoint |
| All retries exhausted | step state | mark failed, prune downstream |
| Plugin upgraded mid-investigation | version mismatch | finish on old version |
| Tenant concurrency exceeded | semaphore | queue |

## 20. Security

- Resume requires `investigation:write` scope + ownership check.
- Cancellation requires `investigation:cancel`.
- Plan contains no secrets (verified by validator).
- Step results may contain PII (retained per data retention rules).

## 21. Scalability

- Topo sort: O(V+E) per plan; < 10 ms.
- Checkpoint write: O(state_data size); < 50 ms typical.
- Wave dispatch: limited by tenant concurrency (1-5 typical).
- Resume: O(state_data size); < 200 ms.
- 1M investigations/day × ~6 steps = 6M step_results rows/day.
  Partitioned monthly.

## 22. Free-tier / Termux compatibility

- Free tier: 1 concurrent wave (no parallelism).
- Termux dev: engine works (no special deps).

## 23. Configuration

```bash
ARGUS_WORKFLOW_SCHEMA_VERSION=1.0
ARGUS_WORKFLOW_MIN_PLAN_VERSION=1.0
ARGUS_WORKFLOW_RESUME_MAX_AGE_D=30
ARGUS_WORKFLOW_CHECKPOINT_INTERVAL_S=30
ARGUS_WORKFLOW_MAX_PARALLEL_WAVE_DEFAULT=4
ARGUS_WORKFLOW_BOT_DEFAULT_PARALLEL=1
ARGUS_WORKFLOW_PRO_DEFAULT_PARALLEL=4
ARGUS_WORKFLOW_TEAM_DEFAULT_PARALLEL=8
```

## 24. Trade-offs and rationale

| Decision | Rationale | Trade-off |
|----------|-----------|-----------|
| Workflow separate from Planner | Single responsibility | Two layers to test |
| Checkpoint per step | Resumability | More DB writes |
| Per-step retry vs per-investigation | Granular control | More config |
| Wave parallelism | Easy to reason about | Not optimal DAG |

## 25. References

- [06-WORKERS.md](06-WORKERS.md) — Worker / Celery
- [24-PLANNER.md](24-PLANNER.md) — Plan generation
- [33-PLUGIN-RUNTIME.md](33-PLUGIN-RUNTIME.md) — Plugin execution
- [23-INVESTIGATION-GRAPH.md](23-INVESTIGATION-GRAPH.md) — Result destination
- [28-SCHEDULER.md](28-SCHEDULER.md) — Re-runs use workflow engine
- [09-EVENT-SYSTEM.md](09-EVENT-SYSTEM.md) — Event topics
- [32-OBSERVABILITY.md](32-OBSERVABILITY.md) — Metrics
- [36-SEARCH-STRATEGIES.md](36-SEARCH-STRATEGIES.md) — Strategy → workflow
