-- /home/user/argus-design/examples/db/initial_schema.sql
-- Reference: this is the SQL the first Alembic migration produces.
-- All schemas, tables, indexes, constraints from 03-DATABASE-SCHEMA.md.

BEGIN;

CREATE EXTENSION IF NOT EXISTS pgcrypto;        -- gen_random_uuid
CREATE EXTENSION IF NOT EXISTS citext;          -- case-insensitive text
CREATE EXTENSION IF NOT EXISTS pg_trgm;         -- fuzzy text search (V2)
CREATE EXTENSION IF NOT EXISTS btree_gin;       -- GIN on scalar columns

-- =====================================================================
-- Schemas
-- =====================================================================
CREATE SCHEMA IF NOT EXISTS identity;
CREATE SCHEMA IF NOT EXISTS investigation;
CREATE SCHEMA IF NOT EXISTS plugin;
CREATE SCHEMA IF NOT EXISTS billing;
CREATE SCHEMA IF NOT EXISTS audit;

-- =====================================================================
-- Identity
-- =====================================================================
CREATE TABLE identity.tenant (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    slug        CITEXT UNIQUE NOT NULL,
    name        TEXT NOT NULL,
    plan_id     UUID,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    deleted_at  TIMESTAMPTZ
);

CREATE TABLE identity."user" (
    id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id    UUID NOT NULL REFERENCES identity.tenant(id) ON DELETE RESTRICT,
    telegram_id  BIGINT UNIQUE,
    email        CITEXT UNIQUE,
    username     CITEXT,
    full_name    TEXT,
    locale       TEXT NOT NULL DEFAULT 'en',
    role         TEXT NOT NULL DEFAULT 'member',
    is_active    BOOLEAN NOT NULL DEFAULT TRUE,
    last_seen_at TIMESTAMPTZ,
    created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    deleted_at   TIMESTAMPTZ,
    CONSTRAINT user_role_chk CHECK (role IN ('member','admin','owner'))
);
CREATE INDEX user_tenant_idx ON identity."user" (tenant_id) WHERE deleted_at IS NULL;

CREATE TABLE identity.api_key (
    id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id    UUID NOT NULL REFERENCES identity.tenant(id) ON DELETE RESTRICT,
    user_id      UUID NOT NULL REFERENCES identity."user"(id) ON DELETE CASCADE,
    name         TEXT NOT NULL,
    key_hash     BYTEA NOT NULL,
    key_prefix   TEXT NOT NULL,
    scopes       TEXT[] NOT NULL DEFAULT '{}',
    last_used_at TIMESTAMPTZ,
    expires_at   TIMESTAMPTZ,
    revoked_at   TIMESTAMPTZ,
    created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX api_key_lookup_idx ON identity.api_key (key_prefix) WHERE revoked_at IS NULL;

CREATE TABLE identity.session (
    id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id      UUID NOT NULL REFERENCES identity."user"(id) ON DELETE CASCADE,
    refresh_jti  UUID UNIQUE NOT NULL,
    user_agent   TEXT,
    ip           INET,
    issued_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    expires_at   TIMESTAMPTZ NOT NULL,
    revoked_at   TIMESTAMPTZ
);

CREATE TABLE identity.password_reset (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id     UUID NOT NULL REFERENCES identity."user"(id) ON DELETE CASCADE,
    token_hash  BYTEA NOT NULL,
    expires_at  TIMESTAMPTZ NOT NULL,
    used_at     TIMESTAMPTZ
);

-- =====================================================================
-- Investigation
-- =====================================================================
CREATE TABLE investigation.investigation (
    id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id         UUID NOT NULL REFERENCES identity.tenant(id),
    owner_id          UUID NOT NULL REFERENCES identity."user"(id),
    title             TEXT NOT NULL,
    target_kind       TEXT NOT NULL,
    target_value      TEXT NOT NULL,
    target_meta       JSONB NOT NULL DEFAULT '{}',
    status            TEXT NOT NULL DEFAULT 'pending',
    progress_pct      SMALLINT NOT NULL DEFAULT 0 CHECK (progress_pct BETWEEN 0 AND 100),
    current_step      TEXT,
    evidence_count    INTEGER NOT NULL DEFAULT 0,
    entity_count      INTEGER NOT NULL DEFAULT 0,
    relationship_count INTEGER NOT NULL DEFAULT 0,
    error_count       INTEGER NOT NULL DEFAULT 0,
    started_at        TIMESTAMPTZ,
    completed_at      TIMESTAMPTZ,
    paused_at         TIMESTAMPTZ,
    cancelled_at      TIMESTAMPTZ,
    created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT investigation_status_chk CHECK (
        status IN ('pending','planned','running','paused','completed','failed','cancelled')
    )
);
CREATE INDEX investigation_tenant_status_idx
    ON investigation.investigation (tenant_id, status, created_at DESC);
CREATE INDEX investigation_owner_idx
    ON investigation.investigation (owner_id, created_at DESC);

CREATE TABLE investigation.plugin_run (
    id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    investigation_id UUID NOT NULL REFERENCES investigation.investigation(id) ON DELETE CASCADE,
    plugin_name      TEXT NOT NULL,
    plugin_version   TEXT NOT NULL,
    status           TEXT NOT NULL DEFAULT 'pending',
    input            JSONB NOT NULL,
    output_summary   JSONB,
    error            TEXT,
    attempts         SMALLINT NOT NULL DEFAULT 0,
    started_at       TIMESTAMPTZ,
    finished_at      TIMESTAMPTZ,
    duration_ms      INTEGER,
    CONSTRAINT plugin_run_status_chk CHECK (
        status IN ('pending','running','succeeded','failed','skipped','timed_out')
    )
);
CREATE INDEX plugin_run_investigation_idx
    ON investigation.plugin_run (investigation_id, status);

CREATE TABLE investigation.evidence (
    id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    investigation_id UUID NOT NULL REFERENCES investigation.investigation(id) ON DELETE CASCADE,
    plugin_run_id    UUID NOT NULL REFERENCES investigation.plugin_run(id) ON DELETE CASCADE,
    kind             TEXT NOT NULL,
    source_url       TEXT,
    content_sha256   BYTEA NOT NULL,
    content_size     BIGINT NOT NULL,
    storage_key      TEXT,
    summary          JSONB NOT NULL DEFAULT '{}',
    raw              JSONB,
    confidence       REAL NOT NULL DEFAULT 1.0 CHECK (confidence BETWEEN 0 AND 1),
    observed_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    created_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT evidence_kind_chk CHECK (kind IN (
        'whois_record','dns_record','http_page','http_headers',
        'social_profile','email_artifact','certificate','image_meta',
        'document','geolocation','phone','breach_entry','other'
    ))
);
CREATE INDEX evidence_investigation_idx
    ON investigation.evidence (investigation_id, kind);
CREATE INDEX evidence_sha256_idx ON investigation.evidence (content_sha256);

CREATE TABLE investigation.entity (
    id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id        UUID NOT NULL REFERENCES identity.tenant(id),
    investigation_id UUID NOT NULL REFERENCES investigation.investigation(id) ON DELETE CASCADE,
    type             TEXT NOT NULL,
    value            TEXT NOT NULL,
    aliases          TEXT[] NOT NULL DEFAULT '{}',
    attributes       JSONB NOT NULL DEFAULT '{}',
    first_seen_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    last_seen_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT entity_type_chk CHECK (type IN (
        'person','domain','subdomain','email','ip','organization',
        'username','phone','address','document','account','other'
    ))
);
CREATE UNIQUE INDEX entity_unique_idx
    ON investigation.entity (investigation_id, type, value);
CREATE INDEX entity_tenant_type_idx ON investigation.entity (tenant_id, type);

CREATE TABLE investigation.relationship (
    id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    investigation_id UUID NOT NULL REFERENCES investigation.investigation(id) ON DELETE CASCADE,
    from_entity_id   UUID NOT NULL REFERENCES investigation.entity(id) ON DELETE CASCADE,
    to_entity_id     UUID NOT NULL REFERENCES investigation.entity(id) ON DELETE CASCADE,
    kind             TEXT NOT NULL,
    weight           REAL NOT NULL DEFAULT 1.0,
    evidence_ids     UUID[] NOT NULL DEFAULT '{}',
    attributes       JSONB NOT NULL DEFAULT '{}',
    created_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT relationship_no_self CHECK (from_entity_id <> to_entity_id)
);
CREATE INDEX relationship_investigation_idx ON investigation.relationship (investigation_id);
CREATE INDEX relationship_from_idx ON investigation.relationship (from_entity_id);
CREATE INDEX relationship_to_idx ON investigation.relationship (to_entity_id);

CREATE TABLE investigation.export (
    id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    investigation_id UUID NOT NULL REFERENCES investigation.investigation(id) ON DELETE CASCADE,
    tenant_id        UUID NOT NULL REFERENCES identity.tenant(id),
    format           TEXT NOT NULL,
    status           TEXT NOT NULL DEFAULT 'pending',
    size_bytes       BIGINT,
    storage_key      TEXT,
    download_url     TEXT,
    expires_at       TIMESTAMPTZ,
    error            TEXT,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
    finished_at      TIMESTAMPTZ,
    CONSTRAINT export_format_chk CHECK (format IN ('json','csv','pdf')),
    CONSTRAINT export_status_chk CHECK (status IN ('pending','running','ready','failed'))
);
CREATE INDEX export_investigation_idx ON investigation.export (investigation_id, created_at DESC);

-- =====================================================================
-- Plugin
-- =====================================================================
CREATE TABLE plugin.plugin (
    name            TEXT PRIMARY KEY,
    description     TEXT NOT NULL,
    homepage        TEXT,
    author          TEXT NOT NULL,
    latest_version  TEXT NOT NULL,
    target_kinds    TEXT[] NOT NULL,
    required_caps   TEXT[] NOT NULL DEFAULT '{}',
    icon_url        TEXT,
    is_official     BOOLEAN NOT NULL DEFAULT FALSE,
    is_enabled      BOOLEAN NOT NULL DEFAULT TRUE,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE plugin.installation (
    id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id     UUID NOT NULL REFERENCES identity.tenant(id) ON DELETE CASCADE,
    plugin_name   TEXT NOT NULL REFERENCES plugin.plugin(name) ON DELETE CASCADE,
    version       TEXT NOT NULL,
    config        JSONB NOT NULL DEFAULT '{}',
    enabled       BOOLEAN NOT NULL DEFAULT TRUE,
    installed_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (tenant_id, plugin_name)
);

CREATE TABLE plugin.manifest (
    plugin_name    TEXT NOT NULL REFERENCES plugin.plugin(name) ON DELETE CASCADE,
    version        TEXT NOT NULL,
    manifest_toml  TEXT NOT NULL,
    signature      BYTEA,
    signed_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (plugin_name, version)
);

-- =====================================================================
-- Billing
-- =====================================================================
CREATE TABLE billing.plan (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    code                TEXT UNIQUE NOT NULL,
    name                TEXT NOT NULL,
    stripe_price_id     TEXT,
    monthly_price_cents BIGINT NOT NULL,
    currency            TEXT NOT NULL DEFAULT 'USD',
    limits              JSONB NOT NULL,
    is_default          BOOLEAN NOT NULL DEFAULT FALSE,
    is_active           BOOLEAN NOT NULL DEFAULT TRUE,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE billing.subscription (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id           UUID NOT NULL UNIQUE REFERENCES identity.tenant(id) ON DELETE CASCADE,
    plan_id             UUID NOT NULL REFERENCES billing.plan(id),
    stripe_sub_id       TEXT UNIQUE,
    status              TEXT NOT NULL,
    current_period_end  TIMESTAMPTZ,
    cancel_at           TIMESTAMPTZ,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT subscription_status_chk CHECK (
        status IN ('active','past_due','canceled','trialing','incomplete','unpaid')
    )
);

CREATE TABLE billing.invoice (
    id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id         UUID NOT NULL REFERENCES identity.tenant(id),
    stripe_invoice_id TEXT UNIQUE,
    amount_cents      BIGINT NOT NULL,
    currency          TEXT NOT NULL,
    status            TEXT NOT NULL,
    pdf_url           TEXT,
    created_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE billing.usage_counter (
    id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id     UUID NOT NULL REFERENCES identity.tenant(id) ON DELETE CASCADE,
    metric        TEXT NOT NULL,
    period_start  TIMESTAMPTZ NOT NULL,
    period_end    TIMESTAMPTZ NOT NULL,
    count         BIGINT NOT NULL DEFAULT 0,
    UNIQUE (tenant_id, metric, period_start)
);
CREATE INDEX usage_counter_lookup_idx
    ON billing.usage_counter (tenant_id, metric, period_start);

-- =====================================================================
-- Audit (append-only)
-- =====================================================================
CREATE TABLE audit.event (
    id           BIGSERIAL PRIMARY KEY,
    occurred_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    actor_kind   TEXT NOT NULL,
    actor_id     UUID,
    tenant_id    UUID,
    action       TEXT NOT NULL,
    target_kind  TEXT,
    target_id    UUID,
    request_id   UUID,
    ip           INET,
    user_agent   TEXT,
    payload      JSONB NOT NULL DEFAULT '{}',
    prev_hash    BYTEA,
    row_hash     BYTEA NOT NULL
);
CREATE INDEX audit_tenant_time_idx ON audit.event (tenant_id, occurred_at DESC);
CREATE INDEX audit_actor_time_idx ON audit.event (actor_id, occurred_at DESC);
CREATE INDEX audit_action_time_idx ON audit.event (action, occurred_at DESC);

CREATE EXTENSION IF NOT EXISTS pgcrypto; -- for digest()

CREATE OR REPLACE FUNCTION audit.event_hash() RETURNS trigger AS $$
DECLARE
    prev BYTEA;
BEGIN
    SELECT row_hash INTO prev FROM audit.event ORDER BY id DESC LIMIT 1;
    NEW.prev_hash := prev;
    NEW.row_hash := digest(
        COALESCE(prev, '\x'::bytea)::text ||
        NEW.occurred_at::text ||
        NEW.actor_kind ||
        COALESCE(NEW.actor_id::text,'') ||
        NEW.action ||
        COALESCE(NEW.payload::text,'{}'),
        'sha256'
    );
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER audit_event_hash_trg
    BEFORE INSERT ON audit.event
    FOR EACH ROW EXECUTE FUNCTION audit.event_hash();

COMMIT;
