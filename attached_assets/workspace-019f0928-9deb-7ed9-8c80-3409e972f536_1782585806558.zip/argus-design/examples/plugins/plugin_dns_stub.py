# /home/user/argus-design/examples/plugins/plugin_dns_stub.py
# Reference skeleton of a real plugin, stripped of heavy logic.
# Use this as the starting point for new first-party plugins.

# plugins/plugin_dns/pyproject.toml
# ─────────────────────────────────────────────────────────────────────
# [build-system]
# requires = ["setuptools>=68", "wheel"]
# build-backend = "setuptools.build_meta"
#
# [project]
# name = "argus-dns"
# version = "1.0.0"
# description = "Subdomain discovery and DNS enumeration for Argus"
# requires-python = ">=3.12,<3.13"
# dependencies = [
#     "argus-plugin-sdk>=1.0.0",
#     "dnspython>=2.5",
# ]
#
# [project.scripts]
# argus-dns = "argus_dns.__main__:main"

# plugins/plugin_dns/argus.toml
# ─────────────────────────────────────────────────────────────────────
# [plugin]
# name        = "dns"
# version     = "1.0.0"
# description = "Subdomain discovery via curated wordlist"
# author      = "Argus Team"
# license     = "Apache-2.0"
# entrypoint  = "argus_dns.__main__:main"
#
# [plugin.target]
# kinds = ["domain"]
#
# [plugin.capabilities]
# dns       = ["8.8.8.8", "1.1.1.1", "9.9.9.9"]
# storage   = "rw"
#
# [plugin.runtime]
# python          = ">=3.12,<3.13"
# memory_mb       = 256
# cpu_seconds     = 120
# network_egress_mb = 10
#
# [plugin.dependencies]
# dnspython = ">=2.5"
#
# [plugin.outputs]
# evidence_kinds = ["subdomain", "dns_record"]
#
# [plugin.config_schema]
# max_subdomains = { type = "integer", default = 500, minimum = 1, maximum = 5000 }
# wordlist       = { type = "string",  default = "default",
#                    enum = ["default", "small", "large"] }

# plugins/plugin_dns/src/argus_dns/__main__.py
# ─────────────────────────────────────────────────────────────────────
import argparse
import asyncio
from argus_plugin_sdk.runner import run_plugin_cli
from argus_dns.runner import DnsPlugin

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--in",   dest="input",  required=True)
    p.add_argument("--out",  dest="output", required=True)
    p.add_argument("--log",  dest="log",    required=True)
    p.add_argument("--ctx",  dest="ctx",    required=True)
    args = p.parse_args()
    run_plugin_cli(DnsPlugin(), args)

if __name__ == "__main__":
    main()

# plugins/plugin_dns/src/argus_dns/runner.py
# ─────────────────────────────────────────────────────────────────────
import asyncio
from pathlib import Path
from argus_plugin_sdk import (
    ctx, dns, emit_evidence, emit_log,
    PluginTransientError, ratelimit,
)

WORDLISTS = {
    "default": "/usr/lib/argus/dns/wordlists/default.txt",
    "small":   "/usr/lib/argus/dns/wordlists/small.txt",
    "large":   "/usr/lib/argus/dns/wordlists/large.txt",
}

class DnsPlugin:
    def setup(self):
        wordlist_name = ctx.config.get("wordlist", "default")
        path = Path(WORDLISTS[wordlist_name])
        with path.open() as f:
            self.wordlist = [w.strip() for w in f if w.strip() and not w.startswith("#")]
        self.max_subdomains = int(ctx.config.get("max_subdomains", 500))
        emit_log("dns.setup", wordlist=wordlist_name, size=len(self.wordlist))

    @ratelimit(calls=200, period=1.0)
    async def lookup(self, host: str) -> list[str]:
        try:
            answers = await dns.resolve_async(host, kind="A")
            return answers
        except TimeoutError:
            return []
        except Exception as e:
            emit_log("dns.lookup_error", host=host, error=str(e))
            return []

    async def run(self):
        target = ctx.target.value
        sem = asyncio.Semaphore(20)

        async def check(word: str):
            host = f"{word}.{target}"
            async with sem:
                ips = await self.lookup(host)
            if ips:
                emit_evidence(
                    kind="subdomain",
                    summary={"host": host, "ips": ips, "parent": target},
                )
                emit_evidence(
                    kind="dns_record",
                    summary={"host": host, "type": "A", "value": ips},
                    raw={"responses": [{"name": host, "type": "A", "value": ip} for ip in ips]},
                )

        await asyncio.gather(*[check(w) for w in self.wordlist[: self.max_subdomains]])

    def teardown(self):
        emit_log("dns.teardown")
