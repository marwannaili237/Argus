# /home/user/argus-design/examples/telegram/handler_examples.py
# Reference aiogram 3.x handler implementations. Copy into services/bot/src/argus_bot/handlers/.
# These are production-shape handlers, not pseudocode.

# ─────────────────────────────────────────────────────────────────────
# handlers/start.py
# ─────────────────────────────────────────────────────────────────────
from aiogram import Router, F
from aiogram.types import Message, CallbackQuery
from aiogram.filters import Command, CommandStart
from aiogram.fsm.context import FSMContext

from argus_bot.api_client import ArgusApiClient
from argus_bot.fsm.storage import token_store
from argus_bot.keyboards.inline import main_menu_kb
from argus_bot.middlewares.auth import UnauthenticatedError

router = Router(name="start")


@router.message(CommandStart())
async def on_start(message: Message, state: FSMContext,
                   api: ArgusApiClient, bot):
    """User taps /start. We authenticate via Telegram Mini App initData
    OR via an OAuth-style flow if Mini App is not available.
    For pure bot flow, we use the bot's secret token + user id as
    proof, exchanging for a backend JWT.
    """
    try:
        record = await token_store.get(message.from_user.id)
        if record is None:
            raise UnauthenticatedError()
    except UnauthenticatedError:
        # Ask user to authenticate via Mini App (preferred) or
        # /login command.
        await message.answer(
            "Welcome to Argus! Open the login page to continue.",
            reply_markup=login_url_kb(bot),
        )
        return

    user = record.user
    await state.clear()
    text, kb = await render_main_menu(user)
    await message.answer(text, reply_markup=kb)


@router.message(Command("help"))
async def on_help(message: Message):
    await message.answer(HTML(
        "<b>Argus Help</b>\n\n"
        "Commands:\n"
        "/start — Main menu\n"
        "/new — New investigation\n"
        "/running — Active investigations\n"
        "/completed — Finished investigations\n"
        "/profile — Your profile\n"
        "/cancel — Cancel current operation\n\n"
        "Or just tap a button."
    ))


@router.message(Command("cancel"))
async def on_cancel(message: Message, state: FSMContext):
    current = await state.get_state()
    if current is None:
        await message.answer("Nothing to cancel.")
        return
    await state.clear()
    await message.answer("Cancelled. Use /start to return to the menu.")


# ─────────────────────────────────────────────────────────────────────
# handlers/menu.py — main menu rendering
# ─────────────────────────────────────────────────────────────────────
from aiogram import Router, F
from aiogram.types import CallbackQuery
from aiogram.fsm.context import FSMContext

from argus_bot.api_client import ArgusApiClient
from argus_bot.callbacks import MenuAction
from argus_bot.renderers.investigation import render_main_menu

router = Router(name="menu")


@router.callback_query(MenuAction.filter())
async def on_menu(cb: CallbackQuery, state: FSMContext,
                  callback_data: MenuAction, api: ArgusApiClient):
    action = callback_data.action

    if action == "new":
        from argus_bot.handlers.investigation_new import InvestigationNew
        await state.set_state(InvestigationNew.choosing_kind)
        text, kb = await render_choose_target_kind(user)
        await cb.message.edit_text(text, reply_markup=kb)

    elif action == "running":
        investigations = await api.list_investigations(
            user, status="running", limit=20)
        text, kb = await render_investigation_list(investigations, "running", user)
        await cb.message.edit_text(text, reply_markup=kb)

    elif action == "completed":
        investigations = await api.list_investigations(
            user, status="completed", limit=20)
        text, kb = await render_investigation_list(investigations, "completed", user)
        await cb.message.edit_text(text, reply_markup=kb)

    elif action == "profile":
        user_dto = await api.me(user)
        text, kb = await render_profile(user_dto)
        await cb.message.edit_text(text, reply_markup=kb)

    elif action == "settings":
        from argus_bot.handlers.settings import render_settings
        text, kb = await render_settings(user)
        await cb.message.edit_text(text, reply_markup=kb)

    elif action == "exports":
        # Show recent exports
        exports = await api.list_exports(user, limit=20)
        text, kb = await render_exports(exports, user)
        await cb.message.edit_text(text, reply_markup=kb)

    await cb.answer()


# ─────────────────────────────────────────────────────────────────────
# handlers/investigation_new.py — FSM flow
# ─────────────────────────────────────────────────────────────────────
from aiogram import Router, F
from aiogram.types import CallbackQuery, Message
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup

from argus_bot.api_client import ArgusApiClient
from argus_bot.callbacks import (
    TargetKindCB, PluginToggleCB, ConfirmCB,
)
from argus_bot.renderers.investigation import (
    render_choose_target_kind, render_choose_plugins, render_confirm,
)

router = Router(name="investigation_new")


class InvestigationNew(StatesGroup):
    choosing_kind = State()
    entering_target = State()
    choosing_plugins = State()
    confirming = State()


@router.callback_query(MenuAction.filter(F.action == "new"))
async def on_new(cb: CallbackQuery, state: FSMContext, user):
    await state.set_state(InvestigationNew.choosing_kind)
    text, kb = await render_choose_target_kind(user)
    await cb.message.edit_text(text, reply_markup=kb)
    await cb.answer()


@router.callback_query(InvestigationNew.choosing_kind, TargetKindCB.filter())
async def on_kind(cb, state, callback_data: TargetKindCB, user):
    await state.update_data(kind=callback_data.kind)
    await state.set_state(InvestigationNew.entering_target)
    await cb.message.edit_text(
        await i18n.get(user.locale, "investigation.new.enter_target",
                       kind=callback_data.kind),
        reply_markup=cancel_kb(),
    )
    await cb.answer()


@router.message(InvestigationNew.entering_target)
async def on_target(message: Message, state: FSMContext, user,
                    api: ArgusApiClient):
    data = await state.get_data()
    value = (message.text or "").strip()
    if not value:
        await message.answer("Empty input. Try again.")
        return

    try:
        normalized = await api.validate_target(
            user, data["kind"], value)
    except ArgusApiError as e:
        await message.answer(format_error(e))
        return

    await state.update_data(value=normalized["value"],
                            target_meta=normalized.get("meta", {}))
    await state.set_state(InvestigationNew.choosing_plugins)

    plugins = await api.list_plugins(user)
    text, kb = await render_choose_plugins(plugins, user)
    await message.answer(text, reply_markup=kb)


@router.callback_query(InvestigationNew.choosing_plugins, PluginToggleCB.filter())
async def on_plugin_toggle(cb, state, callback_data: PluginToggleCB, user):
    data = await state.get_data()
    selected = set(data.get("selected_plugins", []))
    if callback_data.plugin in selected:
        selected.remove(callback_data.plugin)
    else:
        selected.add(callback_data.plugin)
    await state.update_data(selected_plugins=list(selected))

    plugins = await api.list_plugins(user)
    text, kb = await render_choose_plugins(plugins, user, selected)
    await cb.message.edit_text(text, reply_markup=kb)
    await cb.answer()


@router.callback_query(InvestigationNew.choosing_plugins, F.data == "confirm_plugins")
async def on_confirm_plugins(cb, state, user, api: ArgusApiClient):
    data = await state.get_data()
    selected = data.get("selected_plugins", [])
    if not selected:
        await cb.answer("Pick at least one plugin.", show_alert=True)
        return

    await state.set_state(InvestigationNew.confirming)
    text, kb = await render_confirm(data, user)
    await cb.message.edit_text(text, reply_markup=kb)
    await cb.answer()


@router.callback_query(InvestigationNew.confirming, ConfirmCB.filter(F.action == "create"))
async def on_create(cb, state, user, api: ArgusApiClient):
    data = await state.get_data()
    try:
        inv = await api.create_investigation(user, {
            "title": f"Scan {data['value']}",
            "target": {
                "kind": data["kind"],
                "value": data["value"],
                "meta": data.get("target_meta", {}),
            },
            "plugins": data["selected_plugins"],
        })
    except ArgusApiError as e:
        text = format_error(e)
        await cb.message.edit_text(text, reply_markup=back_to_menu_kb())
        await state.clear()
        await cb.answer()
        return

    await state.clear()

    # Edit current message into investigation screen.
    from argus_bot.renderers.investigation import render_investigation_screen
    text, kb = await render_investigation_screen(inv, user)
    await cb.message.edit_text(text, reply_markup=kb)

    # Start progress watcher.
    asyncio.create_task(
        watch_investigation(user, cb.message.chat.id, cb.message.message_id,
                            inv.id, bot=cb.bot))

    await cb.answer("Investigation started")


# ─────────────────────────────────────────────────────────────────────
# progress.py — long-poll watcher that edits the same message
# ─────────────────────────────────────────────────────────────────────
import asyncio
from aiogram import Bot
from argus_bot.api_client import ArgusApiClient
from argus_bot.renderers.investigation import render_investigation_screen

# Registry of active watchers, keyed by message_id.
_watchers: dict[int, asyncio.Task] = {}


async def watch_investigation(user, chat_id: int, message_id: int,
                              investigation_id: str, bot: Bot,
                              api: ArgusApiClient):
    """Long-running task that subscribes to SSE and edits the same
    Telegram message as the investigation progresses.
    """
    if message_id in _watchers:
        _watchers[message_id].cancel()

    async def _run():
        backoff = 1.0
        while True:
            try:
                async for event in api.stream_events(user, investigation_id):
                    if event["type"] in (
                        "investigation.progress",
                        "investigation.completed",
                        "investigation.failed",
                        "evidence.found",
                        "entity.found",
                    ):
                        inv = await api.get_investigation(user, investigation_id)
                        text, kb = await render_investigation_screen(inv, user)
                        try:
                            await bot.edit_message_text(
                                text=text,
                                chat_id=chat_id,
                                message_id=message_id,
                                reply_markup=kb,
                            )
                        except TelegramBadRequest:
                            pass  # message not modified
                        if inv.status in ("completed", "failed", "cancelled"):
                            return
                backoff = 1.0
            except asyncio.CancelledError:
                return
            except Exception as e:
                log.warning("watcher.error", error=str(e), backoff=backoff)
                await asyncio.sleep(backoff)
                backoff = min(backoff * 2, 30.0)

    task = asyncio.create_task(_run())
    _watchers[message_id] = task
    try:
        await task
    finally:
        _watchers.pop(message_id, None)


def cancel_watcher(message_id: int) -> None:
    """Cancel the active progress watcher for a given message."""
    task = _watchers.pop(message_id, None)
    if task is not None:
        task.cancel()
