# Argus — Production OSINT SaaS Architecture

> Telegram-first OSINT platform. Bot is a thin UI. All logic lives in the
> FastAPI backend. Built to be developed entirely from an Android device
> running Termux, deployable to free-tier PaaS (Railway / Koyeb / Northflank).

---

## 0. Why this design exists

- **One operator, one Android phone.** Everything below must run from Termux
  or a free Linux VPS. No Docker Desktop, no VS Code, no WSL.
- **Telegram is a client, not a backend.** The bot must never scrape, never
  touch Postgres, never run business logic. It edits messages instead of
  sending new ones.
- **Free-tier deployable.** Postgres, Redis, app server, and bot worker
  must fit Railway's $5 trial / Koyeb free / Northflank free without
  sustained card billing.
- **Commercial from day one.** Rate limits, quotas, audit logs, billing
  hooks, abuse prevention, data retention — not afterthoughts.

---

## 1. Document Index — 36 deliverables

### Foundation (00–18)

| # | File | Purpose |
|---|------|---------|
| 00 | [docs/00-ARCHITECTURE.md](docs/00-ARCHITECTURE.md) | Layered architecture, dependency rules, request lifecycle |
| 01 | [docs/01-PROJECT-STRUCTURE.md](docs/01-PROJECT-STRUCTURE.md) | Complete monorepo directory tree |
| 02 | [docs/02-ROADMAP.md](docs/02-ROADMAP.md) | 8-phase delivery plan from MVP to GA |
| 03 | [docs/03-DATABASE-SCHEMA.md](docs/03-DATABASE-SCHEMA.md) | Postgres DDL, Alembic layout, partitioning |
| 04 | [docs/04-API-SPEC.md](docs/04-API-SPEC.md) | REST API v1, OpenAPI 3.1, error model |
| 05 | [docs/05-TELEGRAM-BOT.md](docs/05-TELEGRAM-BOT.md) | aiogram 3 router map, FSM, middleware, message editing |
| 06 | [docs/06-WORKERS.md](docs/06-WORKERS.md) | Celery topology, retry, DLQ, beat schedule |
| 07 | [docs/07-PLUGIN-SDK.md](docs/07-PLUGIN-SDK.md) | Plugin protocol, manifest, sandbox, sample plugin |
| 08 | [docs/08-AUTHENTICATION.md](docs/08-AUTHENTICATION.md) | JWT + Telegram Login + API keys |
| 09 | [docs/09-EVENT-SYSTEM.md](docs/09-EVENT-SYSTEM.md) | Redis Streams event bus, schemas |
| 10 | [docs/10-QUEUE-DESIGN.md](docs/10-QUEUE-DESIGN.md) | Queue topology, priorities, SLA, backpressure |
| 11 | [docs/11-ERROR-HANDLING.md](docs/11-ERROR-HANDLING.md) | Exception hierarchy, RFC 7807, client mapping |
| 12 | [docs/12-LOGGING.md](docs/12-LOGGING.md) | structlog, correlation IDs, sampling, retention |
| 13 | [docs/13-DEPLOYMENT.md](docs/13-DEPLOYMENT.md) | Railway / Koyeb / Northflank deploy runbooks |
| 14 | [docs/14-TERMUX-WORKFLOW.md](docs/14-TERMUX-WORKFLOW.md) | proot-distro bootstrap, day-to-day commands |
| 15 | [docs/15-TMUX-LAYOUT.md](docs/15-TMUX-LAYOUT.md) | tmux session.conf, panes, status bar |
| 16 | [docs/16-BASH-SCRIPTS.md](docs/16-BASH-SCRIPTS.md) | `scripts/` — runnable helpers (no Makefile required) |
| 17 | [docs/17-TESTING.md](docs/17-TESTING.md) | pytest layout, fixtures, contract tests, load tests |
| 18 | [docs/18-CICD.md](docs/18-CICD.md) | GitHub Actions workflows, OIDC to PaaS |

### Intelligence engine (19–32)

| # | File | Purpose |
|---|------|---------|
| 19 | [docs/19-SCRAPING-ENGINE.md](docs/19-SCRAPING-ENGINE.md) | Universal scraping: HTTP + browser, sessions, extraction |
| 20 | [docs/20-BROWSER-MANAGER.md](docs/20-BROWSER-MANAGER.md) | Chromium pool, context recycling, health monitoring |
| 21 | [docs/21-PROXY-MANAGER.md](docs/21-PROXY-MANAGER.md) | Proxy rotation, scoring, geo, cooldowns, cost-aware |
| 22 | [docs/22-ANTI-BOT.md](docs/22-ANTI-BOT.md) | Fingerprinting, TLS profiles, risk scoring, adaptive execution |
| 23 | [docs/23-INVESTIGATION-GRAPH.md](docs/23-INVESTIGATION-GRAPH.md) | Cases, entities, evidence, relationships, timelines, graph queries |
| 24 | [docs/24-PLANNER.md](docs/24-PLANNER.md) | Query / investigation planner, DAGs, cost estimation |
| 25 | [docs/25-NORMALIZATION.md](docs/25-NORMALIZATION.md) | Canonical entities, dedup, cross-plugin reconciliation, schema versioning |
| 26 | [docs/26-EVIDENCE-SCORING.md](docs/26-EVIDENCE-SCORING.md) | Confidence, source reliability, freshness, manual overrides |
| 27 | [docs/27-ARTIFACT-STORAGE.md](docs/27-ARTIFACT-STORAGE.md) | Object store: HTML, screenshots, PDFs, versioning, retention |
| 28 | [docs/28-SCHEDULER.md](docs/28-SCHEDULER.md) | Watchlists, delta detection, alerts, scheduled investigations |
| 29 | [docs/29-EXPORT-PIPELINE.md](docs/29-EXPORT-PIPELINE.md) | JSON/CSV/HTML/Markdown/PDF/graph exports, streaming |
| 30 | [docs/30-FEATURE-FLAGS.md](docs/30-FEATURE-FLAGS.md) | Gradual rollout, plugin enablement, kill switches |
| 31 | [docs/31-COST-CONTROLLER.md](docs/31-COST-CONTROLLER.md) | Credits, budgets, paid providers, free-tier optimization |
| 32 | [docs/32-OBSERVABILITY.md](docs/32-OBSERVABILITY.md) | Metrics, traces, dashboards, alerting, capacity planning |

### Runtime & orchestration (33–36)

| # | File | Purpose |
|---|------|---------|
| 33 | [docs/33-PLUGIN-RUNTIME.md](docs/33-PLUGIN-RUNTIME.md) | Plugin subprocess lifecycle, IPC, rlimits, capabilities, secrets, upgrades |
| 34 | [docs/34-DATA-SOURCE-REGISTRY.md](docs/34-DATA-SOURCE-REGISTRY.md) | Central source catalog: capabilities, auth, rate limits, cost, reliability, deprecation |
| 35 | [docs/35-WORKFLOW-ENGINE.md](docs/35-WORKFLOW-ENGINE.md) | DAG execution: dependency resolution, parallelism, checkpointing, resumption, cancellation |
| 36 | [docs/36-SEARCH-STRATEGIES.md](docs/36-SEARCH-STRATEGIES.md) | Playbooks per target kind: email, username, domain, company, phone, IP, ASN, crypto, image, social |

### Audits

| # | File | Purpose |
|---|------|---------|
| REVIEW | [docs/REVIEW.md](docs/REVIEW.md) | Architecture review after 32 docs (P0–P3 findings) |
| AUDIT | [docs/ARCHITECTURE-AUDIT.md](docs/ARCHITECTURE-AUDIT.md) | Final audit across 36 docs with readiness score |

Supporting artifacts:

- [`scripts/`](scripts/) — runnable bash helpers
- [`configs/`](configs/) — tmux.conf, .env.example, pyproject.toml, etc.
- [`examples/db/initial_schema.sql`](examples/db/initial_schema.sql)
- [`examples/plugins/plugin_dns_stub.py`](examples/plugins/plugin_dns_stub.py)
- [`examples/telegram/handler_examples.py`](examples/telegram/handler_examples.py)
- [`TREE.txt`](TREE.txt) — one-glance inventory

---

## 2. High-level architecture

```
┌─────────────────────────────────────────────────────────────────────┐
│                          Telegram (MTProto)                          │
└────────────────────────────────┬────────────────────────────────────┘
                                 │ HTTPS / Bot API
                                 ▼
┌─────────────────────────────────────────────────────────────────────┐
│ aiogram 3.x Bot Worker (THIN UI)                                    │
└────────────────────────────────┬────────────────────────────────────┘
                                 │ REST + JWT
                                 ▼
┌─────────────────────────────────────────────────────────────────────┐
│ FastAPI / Uvicorn (API)                                             │
│  - Auth, Investigations, Exports, Billing, Watchlists, Flags       │
└─────┬───────────────────┬──────────────────┬───────────────────┬────┘
      │                   │                  │                   │
      ▼                   ▼                  ▼                   ▼
┌──────────────┐  ┌────────────────┐  ┌─────────────────────┐  ┌────────────┐
│ PostgreSQL   │  │ Redis Streams  │  │ Celery Worker       │  │ Redis      │
│              │  │ + Event Bus    │  │ ┌─────────────────┐ │  │ broker     │
└──────────────┘  └────────────────┘  │ │ WorkflowEngine  │ │  └────────────┘
                                     │ │  ├ Planner(24)  │ │
                                     │ │  ├ Strategy(36)│ │
                                     │ │  ├ Runtime(33) │ │
                                     │ │  ├ Source(34)  │ │
                                     │ │  ├ Scraper(19) │ │
                                     │ │  ├ Browser(20) │ │
                                     │ │  ├ Proxy(21)   │ │
                                     │ │  ├ AntiBot(22) │ │
                                     │ │  ├ Normalize(25│ │
                                     │ │  ├ Score(26)   │ │
                                     │ │  ├ Graph(23)   │ │
                                     │ │  ├ Artifact(27)│ │
                                     │ │  ├ Export(29)  │ │
                                     │ │  ├ Scheduler(28│ │
                                     │ │  ├ Cost(31)    │ │
                                     │ │  └ Flags(30)   │ │
                                     │ └─────────────────┘ │
                                     └─────────────────────┘
                                     │
                                     └─► Object store (R2/S3)
```

---

## 3. Hard rules (enforced)

1. Bot NEVER imports SQLAlchemy / asyncpg / celery / redis / plugins.
2. Domain NEVER imports FastAPI / SQLAlchemy / Celery / redis / httpx / playwright.
3. All cross-process calls go through the API or the event bus.
4. All time is UTC. All money is integer credits.
5. Browser / proxy / scraping code lives in worker only.
6. All secrets come from env / secrets manager.
7. No `print()`. Only structured logs via structlog.
8. Every public contract has a `schema_version`.

---

## 4. Quick start

```bash
bash scripts/termux-bootstrap.sh        # Termux + proot
./scripts/dev.sh bootstrap              # deps + .env
./scripts/migrate.sh upgrade            # schema
./scripts/seed.sh                       # plans + plugins + sources
./scripts/tmux-dev.sh start             # API+Bot+Worker+Beat
./scripts/test.sh                       # pytest
```

Deploy:

```bash
git push railway main                   # or koyeb / northflank
```

---

## 5. Reading order

- **30 min** (overview): 00, 01, 03, 04, 05, 06, 13, 14.
- **Half day** (intelligence + runtime): 19 → 36 in order.
- **Full day** (all 36 + audits): linear 00 → 36 → REVIEW → AUDIT.

---

## 6. Status

36 production-grade specification documents plus two independent
audits. With AUDIT findings applied, the spec is
**internally consistent and production-ready** for V1 launch on
free-tier infrastructure.

See `TREE.txt`, [REVIEW.md](docs/REVIEW.md), and
[ARCHITECTURE-AUDIT.md](docs/ARCHITECTURE-AUDIT.md) for details.
